package org.xtext.example.mydsl.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.example.mydsl.services.MyDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
@SuppressWarnings("all")
public class InternalMyDslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_INT", "RULE_DOUBLE", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'CreateInteger'", "'('", "')'", "'CreateFloat'", "'CreateString'", "'CreateBoolean'", "'CreateList'", "'CreatePermutation'", "'=='", "'!='", "'<'", "'>'", "'<='", "'>='", "'not'", "'and'", "'or'", "'+'", "'-'", "'['", "']'", "'.'", "'size'", "'*'", "'/'", "'%'"
    };
    public static final int RULE_STRING=7;
    public static final int RULE_SL_COMMENT=9;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__37=37;
    public static final int RULE_DOUBLE=6;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__33=33;
    public static final int T__12=12;
    public static final int T__34=34;
    public static final int T__13=13;
    public static final int T__35=35;
    public static final int T__14=14;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_ID=4;
    public static final int RULE_WS=10;
    public static final int RULE_ANY_OTHER=11;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=5;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=8;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalMyDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMyDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMyDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMyDsl.g"; }



    /*
      This grammar contains a lot of empty actions to work around a bug in ANTLR.
      Otherwise the ANTLR tool will create synpreds that cannot be compiled in some rare cases.
    */

     	private MyDslGrammarAccess grammarAccess;

        public InternalMyDslParser(TokenStream input, MyDslGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Model";
       	}

       	@Override
       	protected MyDslGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleModel"
    // InternalMyDsl.g:70:1: entryRuleModel returns [EObject current=null] : iv_ruleModel= ruleModel EOF ;
    public final EObject entryRuleModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModel = null;


        try {
            // InternalMyDsl.g:70:46: (iv_ruleModel= ruleModel EOF )
            // InternalMyDsl.g:71:2: iv_ruleModel= ruleModel EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getModelRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleModel=ruleModel();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleModel; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalMyDsl.g:77:1: ruleModel returns [EObject current=null] : ( (lv_staments_0_0= ruleStatement ) )* ;
    public final EObject ruleModel() throws RecognitionException {
        EObject current = null;

        EObject lv_staments_0_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:83:2: ( ( (lv_staments_0_0= ruleStatement ) )* )
            // InternalMyDsl.g:84:2: ( (lv_staments_0_0= ruleStatement ) )*
            {
            // InternalMyDsl.g:84:2: ( (lv_staments_0_0= ruleStatement ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==12||(LA1_0>=15 && LA1_0<=19)) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalMyDsl.g:85:3: (lv_staments_0_0= ruleStatement )
            	    {
            	    // InternalMyDsl.g:85:3: (lv_staments_0_0= ruleStatement )
            	    // InternalMyDsl.g:86:4: lv_staments_0_0= ruleStatement
            	    {
            	    if ( state.backtracking==0 ) {

            	      				newCompositeNode(grammarAccess.getModelAccess().getStamentsStatementParserRuleCall_0());
            	      			
            	    }
            	    pushFollow(FOLLOW_3);
            	    lv_staments_0_0=ruleStatement();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      				if (current==null) {
            	      					current = createModelElementForParent(grammarAccess.getModelRule());
            	      				}
            	      				add(
            	      					current,
            	      					"staments",
            	      					lv_staments_0_0,
            	      					"org.xtext.example.mydsl.MyDsl.Statement");
            	      				afterParserOrEnumRuleCall();
            	      			
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleStatement"
    // InternalMyDsl.g:106:1: entryRuleStatement returns [EObject current=null] : iv_ruleStatement= ruleStatement EOF ;
    public final EObject entryRuleStatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStatement = null;


        try {
            // InternalMyDsl.g:106:50: (iv_ruleStatement= ruleStatement EOF )
            // InternalMyDsl.g:107:2: iv_ruleStatement= ruleStatement EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getStatementRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleStatement=ruleStatement();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleStatement; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStatement"


    // $ANTLR start "ruleStatement"
    // InternalMyDsl.g:113:1: ruleStatement returns [EObject current=null] : ( (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' ) | (otherlv_4= 'CreateFloat' otherlv_5= '(' ( (lv_statementFloat_6_0= ruleparametersFloat ) ) otherlv_7= ')' ) | (otherlv_8= 'CreateString' otherlv_9= '(' ( (lv_statementString_10_0= ruleparametersString ) ) otherlv_11= ')' ) | (otherlv_12= 'CreateBoolean' otherlv_13= '(' ( (lv_statementBoolean_14_0= ruleparametersBoolean ) ) otherlv_15= ')' ) | (otherlv_16= 'CreateList' otherlv_17= '(' ( (lv_statementList_18_0= ruleparametersList ) ) otherlv_19= ')' ) | (otherlv_20= 'CreatePermutation' otherlv_21= '(' ( (lv_statementPermutation_22_0= ruleparametersPermutation ) ) otherlv_23= ')' ) ) ;
    public final EObject ruleStatement() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        Token otherlv_13=null;
        Token otherlv_15=null;
        Token otherlv_16=null;
        Token otherlv_17=null;
        Token otherlv_19=null;
        Token otherlv_20=null;
        Token otherlv_21=null;
        Token otherlv_23=null;
        EObject lv_statementInteger_2_0 = null;

        EObject lv_statementFloat_6_0 = null;

        EObject lv_statementString_10_0 = null;

        EObject lv_statementBoolean_14_0 = null;

        EObject lv_statementList_18_0 = null;

        EObject lv_statementPermutation_22_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:119:2: ( ( (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' ) | (otherlv_4= 'CreateFloat' otherlv_5= '(' ( (lv_statementFloat_6_0= ruleparametersFloat ) ) otherlv_7= ')' ) | (otherlv_8= 'CreateString' otherlv_9= '(' ( (lv_statementString_10_0= ruleparametersString ) ) otherlv_11= ')' ) | (otherlv_12= 'CreateBoolean' otherlv_13= '(' ( (lv_statementBoolean_14_0= ruleparametersBoolean ) ) otherlv_15= ')' ) | (otherlv_16= 'CreateList' otherlv_17= '(' ( (lv_statementList_18_0= ruleparametersList ) ) otherlv_19= ')' ) | (otherlv_20= 'CreatePermutation' otherlv_21= '(' ( (lv_statementPermutation_22_0= ruleparametersPermutation ) ) otherlv_23= ')' ) ) )
            // InternalMyDsl.g:120:2: ( (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' ) | (otherlv_4= 'CreateFloat' otherlv_5= '(' ( (lv_statementFloat_6_0= ruleparametersFloat ) ) otherlv_7= ')' ) | (otherlv_8= 'CreateString' otherlv_9= '(' ( (lv_statementString_10_0= ruleparametersString ) ) otherlv_11= ')' ) | (otherlv_12= 'CreateBoolean' otherlv_13= '(' ( (lv_statementBoolean_14_0= ruleparametersBoolean ) ) otherlv_15= ')' ) | (otherlv_16= 'CreateList' otherlv_17= '(' ( (lv_statementList_18_0= ruleparametersList ) ) otherlv_19= ')' ) | (otherlv_20= 'CreatePermutation' otherlv_21= '(' ( (lv_statementPermutation_22_0= ruleparametersPermutation ) ) otherlv_23= ')' ) )
            {
            // InternalMyDsl.g:120:2: ( (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' ) | (otherlv_4= 'CreateFloat' otherlv_5= '(' ( (lv_statementFloat_6_0= ruleparametersFloat ) ) otherlv_7= ')' ) | (otherlv_8= 'CreateString' otherlv_9= '(' ( (lv_statementString_10_0= ruleparametersString ) ) otherlv_11= ')' ) | (otherlv_12= 'CreateBoolean' otherlv_13= '(' ( (lv_statementBoolean_14_0= ruleparametersBoolean ) ) otherlv_15= ')' ) | (otherlv_16= 'CreateList' otherlv_17= '(' ( (lv_statementList_18_0= ruleparametersList ) ) otherlv_19= ')' ) | (otherlv_20= 'CreatePermutation' otherlv_21= '(' ( (lv_statementPermutation_22_0= ruleparametersPermutation ) ) otherlv_23= ')' ) )
            int alt2=6;
            switch ( input.LA(1) ) {
            case 12:
                {
                alt2=1;
                }
                break;
            case 15:
                {
                alt2=2;
                }
                break;
            case 16:
                {
                alt2=3;
                }
                break;
            case 17:
                {
                alt2=4;
                }
                break;
            case 18:
                {
                alt2=5;
                }
                break;
            case 19:
                {
                alt2=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // InternalMyDsl.g:121:3: (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' )
                    {
                    // InternalMyDsl.g:121:3: (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' )
                    // InternalMyDsl.g:122:4: otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')'
                    {
                    otherlv_0=(Token)match(input,12,FOLLOW_4); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_0, grammarAccess.getStatementAccess().getCreateIntegerKeyword_0_0());
                      			
                    }
                    otherlv_1=(Token)match(input,13,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_1, grammarAccess.getStatementAccess().getLeftParenthesisKeyword_0_1());
                      			
                    }
                    // InternalMyDsl.g:130:4: ( (lv_statementInteger_2_0= ruleparametersInteger ) )
                    // InternalMyDsl.g:131:5: (lv_statementInteger_2_0= ruleparametersInteger )
                    {
                    // InternalMyDsl.g:131:5: (lv_statementInteger_2_0= ruleparametersInteger )
                    // InternalMyDsl.g:132:6: lv_statementInteger_2_0= ruleparametersInteger
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getStatementAccess().getStatementIntegerParametersIntegerParserRuleCall_0_2_0());
                      					
                    }
                    pushFollow(FOLLOW_6);
                    lv_statementInteger_2_0=ruleparametersInteger();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getStatementRule());
                      						}
                      						set(
                      							current,
                      							"statementInteger",
                      							lv_statementInteger_2_0,
                      							"org.xtext.example.mydsl.MyDsl.parametersInteger");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    otherlv_3=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_3, grammarAccess.getStatementAccess().getRightParenthesisKeyword_0_3());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:155:3: (otherlv_4= 'CreateFloat' otherlv_5= '(' ( (lv_statementFloat_6_0= ruleparametersFloat ) ) otherlv_7= ')' )
                    {
                    // InternalMyDsl.g:155:3: (otherlv_4= 'CreateFloat' otherlv_5= '(' ( (lv_statementFloat_6_0= ruleparametersFloat ) ) otherlv_7= ')' )
                    // InternalMyDsl.g:156:4: otherlv_4= 'CreateFloat' otherlv_5= '(' ( (lv_statementFloat_6_0= ruleparametersFloat ) ) otherlv_7= ')'
                    {
                    otherlv_4=(Token)match(input,15,FOLLOW_4); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_4, grammarAccess.getStatementAccess().getCreateFloatKeyword_1_0());
                      			
                    }
                    otherlv_5=(Token)match(input,13,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_5, grammarAccess.getStatementAccess().getLeftParenthesisKeyword_1_1());
                      			
                    }
                    // InternalMyDsl.g:164:4: ( (lv_statementFloat_6_0= ruleparametersFloat ) )
                    // InternalMyDsl.g:165:5: (lv_statementFloat_6_0= ruleparametersFloat )
                    {
                    // InternalMyDsl.g:165:5: (lv_statementFloat_6_0= ruleparametersFloat )
                    // InternalMyDsl.g:166:6: lv_statementFloat_6_0= ruleparametersFloat
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getStatementAccess().getStatementFloatParametersFloatParserRuleCall_1_2_0());
                      					
                    }
                    pushFollow(FOLLOW_6);
                    lv_statementFloat_6_0=ruleparametersFloat();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getStatementRule());
                      						}
                      						set(
                      							current,
                      							"statementFloat",
                      							lv_statementFloat_6_0,
                      							"org.xtext.example.mydsl.MyDsl.parametersFloat");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    otherlv_7=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_7, grammarAccess.getStatementAccess().getRightParenthesisKeyword_1_3());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:189:3: (otherlv_8= 'CreateString' otherlv_9= '(' ( (lv_statementString_10_0= ruleparametersString ) ) otherlv_11= ')' )
                    {
                    // InternalMyDsl.g:189:3: (otherlv_8= 'CreateString' otherlv_9= '(' ( (lv_statementString_10_0= ruleparametersString ) ) otherlv_11= ')' )
                    // InternalMyDsl.g:190:4: otherlv_8= 'CreateString' otherlv_9= '(' ( (lv_statementString_10_0= ruleparametersString ) ) otherlv_11= ')'
                    {
                    otherlv_8=(Token)match(input,16,FOLLOW_4); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_8, grammarAccess.getStatementAccess().getCreateStringKeyword_2_0());
                      			
                    }
                    otherlv_9=(Token)match(input,13,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_9, grammarAccess.getStatementAccess().getLeftParenthesisKeyword_2_1());
                      			
                    }
                    // InternalMyDsl.g:198:4: ( (lv_statementString_10_0= ruleparametersString ) )
                    // InternalMyDsl.g:199:5: (lv_statementString_10_0= ruleparametersString )
                    {
                    // InternalMyDsl.g:199:5: (lv_statementString_10_0= ruleparametersString )
                    // InternalMyDsl.g:200:6: lv_statementString_10_0= ruleparametersString
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getStatementAccess().getStatementStringParametersStringParserRuleCall_2_2_0());
                      					
                    }
                    pushFollow(FOLLOW_6);
                    lv_statementString_10_0=ruleparametersString();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getStatementRule());
                      						}
                      						set(
                      							current,
                      							"statementString",
                      							lv_statementString_10_0,
                      							"org.xtext.example.mydsl.MyDsl.parametersString");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    otherlv_11=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_11, grammarAccess.getStatementAccess().getRightParenthesisKeyword_2_3());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:223:3: (otherlv_12= 'CreateBoolean' otherlv_13= '(' ( (lv_statementBoolean_14_0= ruleparametersBoolean ) ) otherlv_15= ')' )
                    {
                    // InternalMyDsl.g:223:3: (otherlv_12= 'CreateBoolean' otherlv_13= '(' ( (lv_statementBoolean_14_0= ruleparametersBoolean ) ) otherlv_15= ')' )
                    // InternalMyDsl.g:224:4: otherlv_12= 'CreateBoolean' otherlv_13= '(' ( (lv_statementBoolean_14_0= ruleparametersBoolean ) ) otherlv_15= ')'
                    {
                    otherlv_12=(Token)match(input,17,FOLLOW_4); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_12, grammarAccess.getStatementAccess().getCreateBooleanKeyword_3_0());
                      			
                    }
                    otherlv_13=(Token)match(input,13,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_13, grammarAccess.getStatementAccess().getLeftParenthesisKeyword_3_1());
                      			
                    }
                    // InternalMyDsl.g:232:4: ( (lv_statementBoolean_14_0= ruleparametersBoolean ) )
                    // InternalMyDsl.g:233:5: (lv_statementBoolean_14_0= ruleparametersBoolean )
                    {
                    // InternalMyDsl.g:233:5: (lv_statementBoolean_14_0= ruleparametersBoolean )
                    // InternalMyDsl.g:234:6: lv_statementBoolean_14_0= ruleparametersBoolean
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getStatementAccess().getStatementBooleanParametersBooleanParserRuleCall_3_2_0());
                      					
                    }
                    pushFollow(FOLLOW_6);
                    lv_statementBoolean_14_0=ruleparametersBoolean();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getStatementRule());
                      						}
                      						set(
                      							current,
                      							"statementBoolean",
                      							lv_statementBoolean_14_0,
                      							"org.xtext.example.mydsl.MyDsl.parametersBoolean");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    otherlv_15=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_15, grammarAccess.getStatementAccess().getRightParenthesisKeyword_3_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalMyDsl.g:257:3: (otherlv_16= 'CreateList' otherlv_17= '(' ( (lv_statementList_18_0= ruleparametersList ) ) otherlv_19= ')' )
                    {
                    // InternalMyDsl.g:257:3: (otherlv_16= 'CreateList' otherlv_17= '(' ( (lv_statementList_18_0= ruleparametersList ) ) otherlv_19= ')' )
                    // InternalMyDsl.g:258:4: otherlv_16= 'CreateList' otherlv_17= '(' ( (lv_statementList_18_0= ruleparametersList ) ) otherlv_19= ')'
                    {
                    otherlv_16=(Token)match(input,18,FOLLOW_4); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_16, grammarAccess.getStatementAccess().getCreateListKeyword_4_0());
                      			
                    }
                    otherlv_17=(Token)match(input,13,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_17, grammarAccess.getStatementAccess().getLeftParenthesisKeyword_4_1());
                      			
                    }
                    // InternalMyDsl.g:266:4: ( (lv_statementList_18_0= ruleparametersList ) )
                    // InternalMyDsl.g:267:5: (lv_statementList_18_0= ruleparametersList )
                    {
                    // InternalMyDsl.g:267:5: (lv_statementList_18_0= ruleparametersList )
                    // InternalMyDsl.g:268:6: lv_statementList_18_0= ruleparametersList
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getStatementAccess().getStatementListParametersListParserRuleCall_4_2_0());
                      					
                    }
                    pushFollow(FOLLOW_6);
                    lv_statementList_18_0=ruleparametersList();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getStatementRule());
                      						}
                      						set(
                      							current,
                      							"statementList",
                      							lv_statementList_18_0,
                      							"org.xtext.example.mydsl.MyDsl.parametersList");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    otherlv_19=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_19, grammarAccess.getStatementAccess().getRightParenthesisKeyword_4_3());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalMyDsl.g:291:3: (otherlv_20= 'CreatePermutation' otherlv_21= '(' ( (lv_statementPermutation_22_0= ruleparametersPermutation ) ) otherlv_23= ')' )
                    {
                    // InternalMyDsl.g:291:3: (otherlv_20= 'CreatePermutation' otherlv_21= '(' ( (lv_statementPermutation_22_0= ruleparametersPermutation ) ) otherlv_23= ')' )
                    // InternalMyDsl.g:292:4: otherlv_20= 'CreatePermutation' otherlv_21= '(' ( (lv_statementPermutation_22_0= ruleparametersPermutation ) ) otherlv_23= ')'
                    {
                    otherlv_20=(Token)match(input,19,FOLLOW_4); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_20, grammarAccess.getStatementAccess().getCreatePermutationKeyword_5_0());
                      			
                    }
                    otherlv_21=(Token)match(input,13,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_21, grammarAccess.getStatementAccess().getLeftParenthesisKeyword_5_1());
                      			
                    }
                    // InternalMyDsl.g:300:4: ( (lv_statementPermutation_22_0= ruleparametersPermutation ) )
                    // InternalMyDsl.g:301:5: (lv_statementPermutation_22_0= ruleparametersPermutation )
                    {
                    // InternalMyDsl.g:301:5: (lv_statementPermutation_22_0= ruleparametersPermutation )
                    // InternalMyDsl.g:302:6: lv_statementPermutation_22_0= ruleparametersPermutation
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getStatementAccess().getStatementPermutationParametersPermutationParserRuleCall_5_2_0());
                      					
                    }
                    pushFollow(FOLLOW_6);
                    lv_statementPermutation_22_0=ruleparametersPermutation();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getStatementRule());
                      						}
                      						set(
                      							current,
                      							"statementPermutation",
                      							lv_statementPermutation_22_0,
                      							"org.xtext.example.mydsl.MyDsl.parametersPermutation");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    otherlv_23=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_23, grammarAccess.getStatementAccess().getRightParenthesisKeyword_5_3());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStatement"


    // $ANTLR start "entryRuleparametersInteger"
    // InternalMyDsl.g:328:1: entryRuleparametersInteger returns [EObject current=null] : iv_ruleparametersInteger= ruleparametersInteger EOF ;
    public final EObject entryRuleparametersInteger() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleparametersInteger = null;


        try {
            // InternalMyDsl.g:328:58: (iv_ruleparametersInteger= ruleparametersInteger EOF )
            // InternalMyDsl.g:329:2: iv_ruleparametersInteger= ruleparametersInteger EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getParametersIntegerRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleparametersInteger=ruleparametersInteger();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleparametersInteger; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleparametersInteger"


    // $ANTLR start "ruleparametersInteger"
    // InternalMyDsl.g:335:1: ruleparametersInteger returns [EObject current=null] : (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' ) ;
    public final EObject ruleparametersInteger() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_statementInteger_2_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:341:2: ( (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' ) )
            // InternalMyDsl.g:342:2: (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' )
            {
            // InternalMyDsl.g:342:2: (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' )
            // InternalMyDsl.g:343:3: otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')'
            {
            otherlv_0=(Token)match(input,12,FOLLOW_4); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getParametersIntegerAccess().getCreateIntegerKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,13,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getParametersIntegerAccess().getLeftParenthesisKeyword_1());
              		
            }
            // InternalMyDsl.g:351:3: ( (lv_statementInteger_2_0= ruleparametersInteger ) )
            // InternalMyDsl.g:352:4: (lv_statementInteger_2_0= ruleparametersInteger )
            {
            // InternalMyDsl.g:352:4: (lv_statementInteger_2_0= ruleparametersInteger )
            // InternalMyDsl.g:353:5: lv_statementInteger_2_0= ruleparametersInteger
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getParametersIntegerAccess().getStatementIntegerParametersIntegerParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_6);
            lv_statementInteger_2_0=ruleparametersInteger();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getParametersIntegerRule());
              					}
              					set(
              						current,
              						"statementInteger",
              						lv_statementInteger_2_0,
              						"org.xtext.example.mydsl.MyDsl.parametersInteger");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            otherlv_3=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_3, grammarAccess.getParametersIntegerAccess().getRightParenthesisKeyword_3());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleparametersInteger"


    // $ANTLR start "entryRuleparametersFloat"
    // InternalMyDsl.g:378:1: entryRuleparametersFloat returns [EObject current=null] : iv_ruleparametersFloat= ruleparametersFloat EOF ;
    public final EObject entryRuleparametersFloat() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleparametersFloat = null;


        try {
            // InternalMyDsl.g:378:56: (iv_ruleparametersFloat= ruleparametersFloat EOF )
            // InternalMyDsl.g:379:2: iv_ruleparametersFloat= ruleparametersFloat EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getParametersFloatRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleparametersFloat=ruleparametersFloat();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleparametersFloat; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleparametersFloat"


    // $ANTLR start "ruleparametersFloat"
    // InternalMyDsl.g:385:1: ruleparametersFloat returns [EObject current=null] : (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' ) ;
    public final EObject ruleparametersFloat() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_statementInteger_2_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:391:2: ( (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' ) )
            // InternalMyDsl.g:392:2: (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' )
            {
            // InternalMyDsl.g:392:2: (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' )
            // InternalMyDsl.g:393:3: otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')'
            {
            otherlv_0=(Token)match(input,12,FOLLOW_4); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getParametersFloatAccess().getCreateIntegerKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,13,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getParametersFloatAccess().getLeftParenthesisKeyword_1());
              		
            }
            // InternalMyDsl.g:401:3: ( (lv_statementInteger_2_0= ruleparametersInteger ) )
            // InternalMyDsl.g:402:4: (lv_statementInteger_2_0= ruleparametersInteger )
            {
            // InternalMyDsl.g:402:4: (lv_statementInteger_2_0= ruleparametersInteger )
            // InternalMyDsl.g:403:5: lv_statementInteger_2_0= ruleparametersInteger
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getParametersFloatAccess().getStatementIntegerParametersIntegerParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_6);
            lv_statementInteger_2_0=ruleparametersInteger();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getParametersFloatRule());
              					}
              					set(
              						current,
              						"statementInteger",
              						lv_statementInteger_2_0,
              						"org.xtext.example.mydsl.MyDsl.parametersInteger");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            otherlv_3=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_3, grammarAccess.getParametersFloatAccess().getRightParenthesisKeyword_3());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleparametersFloat"


    // $ANTLR start "entryRuleparametersString"
    // InternalMyDsl.g:428:1: entryRuleparametersString returns [EObject current=null] : iv_ruleparametersString= ruleparametersString EOF ;
    public final EObject entryRuleparametersString() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleparametersString = null;


        try {
            // InternalMyDsl.g:428:57: (iv_ruleparametersString= ruleparametersString EOF )
            // InternalMyDsl.g:429:2: iv_ruleparametersString= ruleparametersString EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getParametersStringRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleparametersString=ruleparametersString();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleparametersString; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleparametersString"


    // $ANTLR start "ruleparametersString"
    // InternalMyDsl.g:435:1: ruleparametersString returns [EObject current=null] : (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' ) ;
    public final EObject ruleparametersString() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_statementInteger_2_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:441:2: ( (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' ) )
            // InternalMyDsl.g:442:2: (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' )
            {
            // InternalMyDsl.g:442:2: (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' )
            // InternalMyDsl.g:443:3: otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')'
            {
            otherlv_0=(Token)match(input,12,FOLLOW_4); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getParametersStringAccess().getCreateIntegerKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,13,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getParametersStringAccess().getLeftParenthesisKeyword_1());
              		
            }
            // InternalMyDsl.g:451:3: ( (lv_statementInteger_2_0= ruleparametersInteger ) )
            // InternalMyDsl.g:452:4: (lv_statementInteger_2_0= ruleparametersInteger )
            {
            // InternalMyDsl.g:452:4: (lv_statementInteger_2_0= ruleparametersInteger )
            // InternalMyDsl.g:453:5: lv_statementInteger_2_0= ruleparametersInteger
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getParametersStringAccess().getStatementIntegerParametersIntegerParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_6);
            lv_statementInteger_2_0=ruleparametersInteger();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getParametersStringRule());
              					}
              					set(
              						current,
              						"statementInteger",
              						lv_statementInteger_2_0,
              						"org.xtext.example.mydsl.MyDsl.parametersInteger");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            otherlv_3=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_3, grammarAccess.getParametersStringAccess().getRightParenthesisKeyword_3());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleparametersString"


    // $ANTLR start "entryRuleparametersBoolean"
    // InternalMyDsl.g:478:1: entryRuleparametersBoolean returns [EObject current=null] : iv_ruleparametersBoolean= ruleparametersBoolean EOF ;
    public final EObject entryRuleparametersBoolean() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleparametersBoolean = null;


        try {
            // InternalMyDsl.g:478:58: (iv_ruleparametersBoolean= ruleparametersBoolean EOF )
            // InternalMyDsl.g:479:2: iv_ruleparametersBoolean= ruleparametersBoolean EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getParametersBooleanRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleparametersBoolean=ruleparametersBoolean();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleparametersBoolean; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleparametersBoolean"


    // $ANTLR start "ruleparametersBoolean"
    // InternalMyDsl.g:485:1: ruleparametersBoolean returns [EObject current=null] : (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' ) ;
    public final EObject ruleparametersBoolean() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_statementInteger_2_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:491:2: ( (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' ) )
            // InternalMyDsl.g:492:2: (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' )
            {
            // InternalMyDsl.g:492:2: (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' )
            // InternalMyDsl.g:493:3: otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')'
            {
            otherlv_0=(Token)match(input,12,FOLLOW_4); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getParametersBooleanAccess().getCreateIntegerKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,13,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getParametersBooleanAccess().getLeftParenthesisKeyword_1());
              		
            }
            // InternalMyDsl.g:501:3: ( (lv_statementInteger_2_0= ruleparametersInteger ) )
            // InternalMyDsl.g:502:4: (lv_statementInteger_2_0= ruleparametersInteger )
            {
            // InternalMyDsl.g:502:4: (lv_statementInteger_2_0= ruleparametersInteger )
            // InternalMyDsl.g:503:5: lv_statementInteger_2_0= ruleparametersInteger
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getParametersBooleanAccess().getStatementIntegerParametersIntegerParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_6);
            lv_statementInteger_2_0=ruleparametersInteger();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getParametersBooleanRule());
              					}
              					set(
              						current,
              						"statementInteger",
              						lv_statementInteger_2_0,
              						"org.xtext.example.mydsl.MyDsl.parametersInteger");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            otherlv_3=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_3, grammarAccess.getParametersBooleanAccess().getRightParenthesisKeyword_3());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleparametersBoolean"


    // $ANTLR start "entryRuleparametersList"
    // InternalMyDsl.g:528:1: entryRuleparametersList returns [EObject current=null] : iv_ruleparametersList= ruleparametersList EOF ;
    public final EObject entryRuleparametersList() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleparametersList = null;


        try {
            // InternalMyDsl.g:528:55: (iv_ruleparametersList= ruleparametersList EOF )
            // InternalMyDsl.g:529:2: iv_ruleparametersList= ruleparametersList EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getParametersListRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleparametersList=ruleparametersList();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleparametersList; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleparametersList"


    // $ANTLR start "ruleparametersList"
    // InternalMyDsl.g:535:1: ruleparametersList returns [EObject current=null] : (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' ) ;
    public final EObject ruleparametersList() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_statementInteger_2_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:541:2: ( (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' ) )
            // InternalMyDsl.g:542:2: (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' )
            {
            // InternalMyDsl.g:542:2: (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' )
            // InternalMyDsl.g:543:3: otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')'
            {
            otherlv_0=(Token)match(input,12,FOLLOW_4); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getParametersListAccess().getCreateIntegerKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,13,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getParametersListAccess().getLeftParenthesisKeyword_1());
              		
            }
            // InternalMyDsl.g:551:3: ( (lv_statementInteger_2_0= ruleparametersInteger ) )
            // InternalMyDsl.g:552:4: (lv_statementInteger_2_0= ruleparametersInteger )
            {
            // InternalMyDsl.g:552:4: (lv_statementInteger_2_0= ruleparametersInteger )
            // InternalMyDsl.g:553:5: lv_statementInteger_2_0= ruleparametersInteger
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getParametersListAccess().getStatementIntegerParametersIntegerParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_6);
            lv_statementInteger_2_0=ruleparametersInteger();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getParametersListRule());
              					}
              					set(
              						current,
              						"statementInteger",
              						lv_statementInteger_2_0,
              						"org.xtext.example.mydsl.MyDsl.parametersInteger");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            otherlv_3=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_3, grammarAccess.getParametersListAccess().getRightParenthesisKeyword_3());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleparametersList"


    // $ANTLR start "entryRuleparametersPermutation"
    // InternalMyDsl.g:578:1: entryRuleparametersPermutation returns [EObject current=null] : iv_ruleparametersPermutation= ruleparametersPermutation EOF ;
    public final EObject entryRuleparametersPermutation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleparametersPermutation = null;


        try {
            // InternalMyDsl.g:578:62: (iv_ruleparametersPermutation= ruleparametersPermutation EOF )
            // InternalMyDsl.g:579:2: iv_ruleparametersPermutation= ruleparametersPermutation EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getParametersPermutationRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleparametersPermutation=ruleparametersPermutation();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleparametersPermutation; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleparametersPermutation"


    // $ANTLR start "ruleparametersPermutation"
    // InternalMyDsl.g:585:1: ruleparametersPermutation returns [EObject current=null] : (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= rulecondexpr ) ) otherlv_3= ')' ) ;
    public final EObject ruleparametersPermutation() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_statementInteger_2_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:591:2: ( (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= rulecondexpr ) ) otherlv_3= ')' ) )
            // InternalMyDsl.g:592:2: (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= rulecondexpr ) ) otherlv_3= ')' )
            {
            // InternalMyDsl.g:592:2: (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= rulecondexpr ) ) otherlv_3= ')' )
            // InternalMyDsl.g:593:3: otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= rulecondexpr ) ) otherlv_3= ')'
            {
            otherlv_0=(Token)match(input,12,FOLLOW_4); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getParametersPermutationAccess().getCreateIntegerKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,13,FOLLOW_7); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getParametersPermutationAccess().getLeftParenthesisKeyword_1());
              		
            }
            // InternalMyDsl.g:601:3: ( (lv_statementInteger_2_0= rulecondexpr ) )
            // InternalMyDsl.g:602:4: (lv_statementInteger_2_0= rulecondexpr )
            {
            // InternalMyDsl.g:602:4: (lv_statementInteger_2_0= rulecondexpr )
            // InternalMyDsl.g:603:5: lv_statementInteger_2_0= rulecondexpr
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getParametersPermutationAccess().getStatementIntegerCondexprParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_6);
            lv_statementInteger_2_0=rulecondexpr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getParametersPermutationRule());
              					}
              					set(
              						current,
              						"statementInteger",
              						lv_statementInteger_2_0,
              						"org.xtext.example.mydsl.MyDsl.condexpr");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            otherlv_3=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_3, grammarAccess.getParametersPermutationAccess().getRightParenthesisKeyword_3());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleparametersPermutation"


    // $ANTLR start "entryRuleconditional"
    // InternalMyDsl.g:628:1: entryRuleconditional returns [EObject current=null] : iv_ruleconditional= ruleconditional EOF ;
    public final EObject entryRuleconditional() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleconditional = null;


        try {
            // InternalMyDsl.g:628:52: (iv_ruleconditional= ruleconditional EOF )
            // InternalMyDsl.g:629:2: iv_ruleconditional= ruleconditional EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getConditionalRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleconditional=ruleconditional();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleconditional; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleconditional"


    // $ANTLR start "ruleconditional"
    // InternalMyDsl.g:635:1: ruleconditional returns [EObject current=null] : ( (otherlv_0= '==' ( (lv_statement_conditionals_1_1_0= ruleconditionals_1 ) ) ) | (otherlv_2= '!=' ( (lv_statement_conditionals_1_3_0= ruleconditionals_1 ) ) ) | (otherlv_4= '<' ( (lv_statement_conditionals_1_5_0= ruleconditionals_1 ) ) ) | (otherlv_6= '>' ( (lv_statement_conditionals_1_7_0= ruleconditionals_1 ) ) ) | (otherlv_8= '<=' ( (lv_statement_conditionals_1_9_0= ruleconditionals_1 ) ) ) | (otherlv_10= '>=' ( (lv_statement_conditionals_1_11_0= ruleconditionals_1 ) ) ) | ( ( (lv_statement_conectores_12_0= ruleconectores ) ) ( (lv_statement_condexpr_13_0= rulecondexpr ) ) ) ) ;
    public final EObject ruleconditional() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        EObject lv_statement_conditionals_1_1_0 = null;

        EObject lv_statement_conditionals_1_3_0 = null;

        EObject lv_statement_conditionals_1_5_0 = null;

        EObject lv_statement_conditionals_1_7_0 = null;

        EObject lv_statement_conditionals_1_9_0 = null;

        EObject lv_statement_conditionals_1_11_0 = null;

        AntlrDatatypeRuleToken lv_statement_conectores_12_0 = null;

        EObject lv_statement_condexpr_13_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:641:2: ( ( (otherlv_0= '==' ( (lv_statement_conditionals_1_1_0= ruleconditionals_1 ) ) ) | (otherlv_2= '!=' ( (lv_statement_conditionals_1_3_0= ruleconditionals_1 ) ) ) | (otherlv_4= '<' ( (lv_statement_conditionals_1_5_0= ruleconditionals_1 ) ) ) | (otherlv_6= '>' ( (lv_statement_conditionals_1_7_0= ruleconditionals_1 ) ) ) | (otherlv_8= '<=' ( (lv_statement_conditionals_1_9_0= ruleconditionals_1 ) ) ) | (otherlv_10= '>=' ( (lv_statement_conditionals_1_11_0= ruleconditionals_1 ) ) ) | ( ( (lv_statement_conectores_12_0= ruleconectores ) ) ( (lv_statement_condexpr_13_0= rulecondexpr ) ) ) ) )
            // InternalMyDsl.g:642:2: ( (otherlv_0= '==' ( (lv_statement_conditionals_1_1_0= ruleconditionals_1 ) ) ) | (otherlv_2= '!=' ( (lv_statement_conditionals_1_3_0= ruleconditionals_1 ) ) ) | (otherlv_4= '<' ( (lv_statement_conditionals_1_5_0= ruleconditionals_1 ) ) ) | (otherlv_6= '>' ( (lv_statement_conditionals_1_7_0= ruleconditionals_1 ) ) ) | (otherlv_8= '<=' ( (lv_statement_conditionals_1_9_0= ruleconditionals_1 ) ) ) | (otherlv_10= '>=' ( (lv_statement_conditionals_1_11_0= ruleconditionals_1 ) ) ) | ( ( (lv_statement_conectores_12_0= ruleconectores ) ) ( (lv_statement_condexpr_13_0= rulecondexpr ) ) ) )
            {
            // InternalMyDsl.g:642:2: ( (otherlv_0= '==' ( (lv_statement_conditionals_1_1_0= ruleconditionals_1 ) ) ) | (otherlv_2= '!=' ( (lv_statement_conditionals_1_3_0= ruleconditionals_1 ) ) ) | (otherlv_4= '<' ( (lv_statement_conditionals_1_5_0= ruleconditionals_1 ) ) ) | (otherlv_6= '>' ( (lv_statement_conditionals_1_7_0= ruleconditionals_1 ) ) ) | (otherlv_8= '<=' ( (lv_statement_conditionals_1_9_0= ruleconditionals_1 ) ) ) | (otherlv_10= '>=' ( (lv_statement_conditionals_1_11_0= ruleconditionals_1 ) ) ) | ( ( (lv_statement_conectores_12_0= ruleconectores ) ) ( (lv_statement_condexpr_13_0= rulecondexpr ) ) ) )
            int alt3=7;
            switch ( input.LA(1) ) {
            case 20:
                {
                alt3=1;
                }
                break;
            case 21:
                {
                alt3=2;
                }
                break;
            case 22:
                {
                alt3=3;
                }
                break;
            case 23:
                {
                alt3=4;
                }
                break;
            case 24:
                {
                alt3=5;
                }
                break;
            case 25:
                {
                alt3=6;
                }
                break;
            case 27:
            case 28:
                {
                alt3=7;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // InternalMyDsl.g:643:3: (otherlv_0= '==' ( (lv_statement_conditionals_1_1_0= ruleconditionals_1 ) ) )
                    {
                    // InternalMyDsl.g:643:3: (otherlv_0= '==' ( (lv_statement_conditionals_1_1_0= ruleconditionals_1 ) ) )
                    // InternalMyDsl.g:644:4: otherlv_0= '==' ( (lv_statement_conditionals_1_1_0= ruleconditionals_1 ) )
                    {
                    otherlv_0=(Token)match(input,20,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_0, grammarAccess.getConditionalAccess().getEqualsSignEqualsSignKeyword_0_0());
                      			
                    }
                    // InternalMyDsl.g:648:4: ( (lv_statement_conditionals_1_1_0= ruleconditionals_1 ) )
                    // InternalMyDsl.g:649:5: (lv_statement_conditionals_1_1_0= ruleconditionals_1 )
                    {
                    // InternalMyDsl.g:649:5: (lv_statement_conditionals_1_1_0= ruleconditionals_1 )
                    // InternalMyDsl.g:650:6: lv_statement_conditionals_1_1_0= ruleconditionals_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionalAccess().getStatement_conditionals_1Conditionals_1ParserRuleCall_0_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_conditionals_1_1_0=ruleconditionals_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionalRule());
                      						}
                      						set(
                      							current,
                      							"statement_conditionals_1",
                      							lv_statement_conditionals_1_1_0,
                      							"org.xtext.example.mydsl.MyDsl.conditionals_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:669:3: (otherlv_2= '!=' ( (lv_statement_conditionals_1_3_0= ruleconditionals_1 ) ) )
                    {
                    // InternalMyDsl.g:669:3: (otherlv_2= '!=' ( (lv_statement_conditionals_1_3_0= ruleconditionals_1 ) ) )
                    // InternalMyDsl.g:670:4: otherlv_2= '!=' ( (lv_statement_conditionals_1_3_0= ruleconditionals_1 ) )
                    {
                    otherlv_2=(Token)match(input,21,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_2, grammarAccess.getConditionalAccess().getExclamationMarkEqualsSignKeyword_1_0());
                      			
                    }
                    // InternalMyDsl.g:674:4: ( (lv_statement_conditionals_1_3_0= ruleconditionals_1 ) )
                    // InternalMyDsl.g:675:5: (lv_statement_conditionals_1_3_0= ruleconditionals_1 )
                    {
                    // InternalMyDsl.g:675:5: (lv_statement_conditionals_1_3_0= ruleconditionals_1 )
                    // InternalMyDsl.g:676:6: lv_statement_conditionals_1_3_0= ruleconditionals_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionalAccess().getStatement_conditionals_1Conditionals_1ParserRuleCall_1_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_conditionals_1_3_0=ruleconditionals_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionalRule());
                      						}
                      						set(
                      							current,
                      							"statement_conditionals_1",
                      							lv_statement_conditionals_1_3_0,
                      							"org.xtext.example.mydsl.MyDsl.conditionals_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:695:3: (otherlv_4= '<' ( (lv_statement_conditionals_1_5_0= ruleconditionals_1 ) ) )
                    {
                    // InternalMyDsl.g:695:3: (otherlv_4= '<' ( (lv_statement_conditionals_1_5_0= ruleconditionals_1 ) ) )
                    // InternalMyDsl.g:696:4: otherlv_4= '<' ( (lv_statement_conditionals_1_5_0= ruleconditionals_1 ) )
                    {
                    otherlv_4=(Token)match(input,22,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_4, grammarAccess.getConditionalAccess().getLessThanSignKeyword_2_0());
                      			
                    }
                    // InternalMyDsl.g:700:4: ( (lv_statement_conditionals_1_5_0= ruleconditionals_1 ) )
                    // InternalMyDsl.g:701:5: (lv_statement_conditionals_1_5_0= ruleconditionals_1 )
                    {
                    // InternalMyDsl.g:701:5: (lv_statement_conditionals_1_5_0= ruleconditionals_1 )
                    // InternalMyDsl.g:702:6: lv_statement_conditionals_1_5_0= ruleconditionals_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionalAccess().getStatement_conditionals_1Conditionals_1ParserRuleCall_2_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_conditionals_1_5_0=ruleconditionals_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionalRule());
                      						}
                      						set(
                      							current,
                      							"statement_conditionals_1",
                      							lv_statement_conditionals_1_5_0,
                      							"org.xtext.example.mydsl.MyDsl.conditionals_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:721:3: (otherlv_6= '>' ( (lv_statement_conditionals_1_7_0= ruleconditionals_1 ) ) )
                    {
                    // InternalMyDsl.g:721:3: (otherlv_6= '>' ( (lv_statement_conditionals_1_7_0= ruleconditionals_1 ) ) )
                    // InternalMyDsl.g:722:4: otherlv_6= '>' ( (lv_statement_conditionals_1_7_0= ruleconditionals_1 ) )
                    {
                    otherlv_6=(Token)match(input,23,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_6, grammarAccess.getConditionalAccess().getGreaterThanSignKeyword_3_0());
                      			
                    }
                    // InternalMyDsl.g:726:4: ( (lv_statement_conditionals_1_7_0= ruleconditionals_1 ) )
                    // InternalMyDsl.g:727:5: (lv_statement_conditionals_1_7_0= ruleconditionals_1 )
                    {
                    // InternalMyDsl.g:727:5: (lv_statement_conditionals_1_7_0= ruleconditionals_1 )
                    // InternalMyDsl.g:728:6: lv_statement_conditionals_1_7_0= ruleconditionals_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionalAccess().getStatement_conditionals_1Conditionals_1ParserRuleCall_3_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_conditionals_1_7_0=ruleconditionals_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionalRule());
                      						}
                      						set(
                      							current,
                      							"statement_conditionals_1",
                      							lv_statement_conditionals_1_7_0,
                      							"org.xtext.example.mydsl.MyDsl.conditionals_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 5 :
                    // InternalMyDsl.g:747:3: (otherlv_8= '<=' ( (lv_statement_conditionals_1_9_0= ruleconditionals_1 ) ) )
                    {
                    // InternalMyDsl.g:747:3: (otherlv_8= '<=' ( (lv_statement_conditionals_1_9_0= ruleconditionals_1 ) ) )
                    // InternalMyDsl.g:748:4: otherlv_8= '<=' ( (lv_statement_conditionals_1_9_0= ruleconditionals_1 ) )
                    {
                    otherlv_8=(Token)match(input,24,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_8, grammarAccess.getConditionalAccess().getLessThanSignEqualsSignKeyword_4_0());
                      			
                    }
                    // InternalMyDsl.g:752:4: ( (lv_statement_conditionals_1_9_0= ruleconditionals_1 ) )
                    // InternalMyDsl.g:753:5: (lv_statement_conditionals_1_9_0= ruleconditionals_1 )
                    {
                    // InternalMyDsl.g:753:5: (lv_statement_conditionals_1_9_0= ruleconditionals_1 )
                    // InternalMyDsl.g:754:6: lv_statement_conditionals_1_9_0= ruleconditionals_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionalAccess().getStatement_conditionals_1Conditionals_1ParserRuleCall_4_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_conditionals_1_9_0=ruleconditionals_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionalRule());
                      						}
                      						set(
                      							current,
                      							"statement_conditionals_1",
                      							lv_statement_conditionals_1_9_0,
                      							"org.xtext.example.mydsl.MyDsl.conditionals_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 6 :
                    // InternalMyDsl.g:773:3: (otherlv_10= '>=' ( (lv_statement_conditionals_1_11_0= ruleconditionals_1 ) ) )
                    {
                    // InternalMyDsl.g:773:3: (otherlv_10= '>=' ( (lv_statement_conditionals_1_11_0= ruleconditionals_1 ) ) )
                    // InternalMyDsl.g:774:4: otherlv_10= '>=' ( (lv_statement_conditionals_1_11_0= ruleconditionals_1 ) )
                    {
                    otherlv_10=(Token)match(input,25,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_10, grammarAccess.getConditionalAccess().getGreaterThanSignEqualsSignKeyword_5_0());
                      			
                    }
                    // InternalMyDsl.g:778:4: ( (lv_statement_conditionals_1_11_0= ruleconditionals_1 ) )
                    // InternalMyDsl.g:779:5: (lv_statement_conditionals_1_11_0= ruleconditionals_1 )
                    {
                    // InternalMyDsl.g:779:5: (lv_statement_conditionals_1_11_0= ruleconditionals_1 )
                    // InternalMyDsl.g:780:6: lv_statement_conditionals_1_11_0= ruleconditionals_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionalAccess().getStatement_conditionals_1Conditionals_1ParserRuleCall_5_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_conditionals_1_11_0=ruleconditionals_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionalRule());
                      						}
                      						set(
                      							current,
                      							"statement_conditionals_1",
                      							lv_statement_conditionals_1_11_0,
                      							"org.xtext.example.mydsl.MyDsl.conditionals_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 7 :
                    // InternalMyDsl.g:799:3: ( ( (lv_statement_conectores_12_0= ruleconectores ) ) ( (lv_statement_condexpr_13_0= rulecondexpr ) ) )
                    {
                    // InternalMyDsl.g:799:3: ( ( (lv_statement_conectores_12_0= ruleconectores ) ) ( (lv_statement_condexpr_13_0= rulecondexpr ) ) )
                    // InternalMyDsl.g:800:4: ( (lv_statement_conectores_12_0= ruleconectores ) ) ( (lv_statement_condexpr_13_0= rulecondexpr ) )
                    {
                    // InternalMyDsl.g:800:4: ( (lv_statement_conectores_12_0= ruleconectores ) )
                    // InternalMyDsl.g:801:5: (lv_statement_conectores_12_0= ruleconectores )
                    {
                    // InternalMyDsl.g:801:5: (lv_statement_conectores_12_0= ruleconectores )
                    // InternalMyDsl.g:802:6: lv_statement_conectores_12_0= ruleconectores
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionalAccess().getStatement_conectoresConectoresParserRuleCall_6_0_0());
                      					
                    }
                    pushFollow(FOLLOW_7);
                    lv_statement_conectores_12_0=ruleconectores();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionalRule());
                      						}
                      						set(
                      							current,
                      							"statement_conectores",
                      							lv_statement_conectores_12_0,
                      							"org.xtext.example.mydsl.MyDsl.conectores");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalMyDsl.g:819:4: ( (lv_statement_condexpr_13_0= rulecondexpr ) )
                    // InternalMyDsl.g:820:5: (lv_statement_condexpr_13_0= rulecondexpr )
                    {
                    // InternalMyDsl.g:820:5: (lv_statement_condexpr_13_0= rulecondexpr )
                    // InternalMyDsl.g:821:6: lv_statement_condexpr_13_0= rulecondexpr
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionalAccess().getStatement_condexprCondexprParserRuleCall_6_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_condexpr_13_0=rulecondexpr();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionalRule());
                      						}
                      						set(
                      							current,
                      							"statement_condexpr",
                      							lv_statement_condexpr_13_0,
                      							"org.xtext.example.mydsl.MyDsl.condexpr");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleconditional"


    // $ANTLR start "entryRulecondexpr"
    // InternalMyDsl.g:843:1: entryRulecondexpr returns [EObject current=null] : iv_rulecondexpr= rulecondexpr EOF ;
    public final EObject entryRulecondexpr() throws RecognitionException {
        EObject current = null;

        EObject iv_rulecondexpr = null;


        try {
            // InternalMyDsl.g:843:49: (iv_rulecondexpr= rulecondexpr EOF )
            // InternalMyDsl.g:844:2: iv_rulecondexpr= rulecondexpr EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getCondexprRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulecondexpr=rulecondexpr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulecondexpr; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulecondexpr"


    // $ANTLR start "rulecondexpr"
    // InternalMyDsl.g:850:1: rulecondexpr returns [EObject current=null] : ( (otherlv_0= 'not' otherlv_1= '(' ( (lv_statement_condexprs_2_0= rulecondexpr ) ) otherlv_3= ')' ( (lv_statement_conditional_4_0= ruleconditional ) ) ) | (otherlv_5= '(' ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) ) ) | ( ( (lv_statement_arith_7_0= rulearith ) ) ( (lv_statement_conditional_8_0= ruleconditional ) ) ) ) ;
    public final EObject rulecondexpr() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject lv_statement_condexprs_2_0 = null;

        EObject lv_statement_conditional_4_0 = null;

        EObject lv_statement_aux_condexpr_6_0 = null;

        EObject lv_statement_arith_7_0 = null;

        EObject lv_statement_conditional_8_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:856:2: ( ( (otherlv_0= 'not' otherlv_1= '(' ( (lv_statement_condexprs_2_0= rulecondexpr ) ) otherlv_3= ')' ( (lv_statement_conditional_4_0= ruleconditional ) ) ) | (otherlv_5= '(' ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) ) ) | ( ( (lv_statement_arith_7_0= rulearith ) ) ( (lv_statement_conditional_8_0= ruleconditional ) ) ) ) )
            // InternalMyDsl.g:857:2: ( (otherlv_0= 'not' otherlv_1= '(' ( (lv_statement_condexprs_2_0= rulecondexpr ) ) otherlv_3= ')' ( (lv_statement_conditional_4_0= ruleconditional ) ) ) | (otherlv_5= '(' ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) ) ) | ( ( (lv_statement_arith_7_0= rulearith ) ) ( (lv_statement_conditional_8_0= ruleconditional ) ) ) )
            {
            // InternalMyDsl.g:857:2: ( (otherlv_0= 'not' otherlv_1= '(' ( (lv_statement_condexprs_2_0= rulecondexpr ) ) otherlv_3= ')' ( (lv_statement_conditional_4_0= ruleconditional ) ) ) | (otherlv_5= '(' ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) ) ) | ( ( (lv_statement_arith_7_0= rulearith ) ) ( (lv_statement_conditional_8_0= ruleconditional ) ) ) )
            int alt4=3;
            switch ( input.LA(1) ) {
            case 26:
                {
                alt4=1;
                }
                break;
            case 13:
                {
                int LA4_2 = input.LA(2);

                if ( (synpred14_InternalMyDsl()) ) {
                    alt4=2;
                }
                else if ( (true) ) {
                    alt4=3;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 4, 2, input);

                    throw nvae;
                }
                }
                break;
            case RULE_ID:
            case RULE_INT:
            case RULE_DOUBLE:
            case 29:
            case 30:
                {
                alt4=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }

            switch (alt4) {
                case 1 :
                    // InternalMyDsl.g:858:3: (otherlv_0= 'not' otherlv_1= '(' ( (lv_statement_condexprs_2_0= rulecondexpr ) ) otherlv_3= ')' ( (lv_statement_conditional_4_0= ruleconditional ) ) )
                    {
                    // InternalMyDsl.g:858:3: (otherlv_0= 'not' otherlv_1= '(' ( (lv_statement_condexprs_2_0= rulecondexpr ) ) otherlv_3= ')' ( (lv_statement_conditional_4_0= ruleconditional ) ) )
                    // InternalMyDsl.g:859:4: otherlv_0= 'not' otherlv_1= '(' ( (lv_statement_condexprs_2_0= rulecondexpr ) ) otherlv_3= ')' ( (lv_statement_conditional_4_0= ruleconditional ) )
                    {
                    otherlv_0=(Token)match(input,26,FOLLOW_4); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_0, grammarAccess.getCondexprAccess().getNotKeyword_0_0());
                      			
                    }
                    otherlv_1=(Token)match(input,13,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_1, grammarAccess.getCondexprAccess().getLeftParenthesisKeyword_0_1());
                      			
                    }
                    // InternalMyDsl.g:867:4: ( (lv_statement_condexprs_2_0= rulecondexpr ) )
                    // InternalMyDsl.g:868:5: (lv_statement_condexprs_2_0= rulecondexpr )
                    {
                    // InternalMyDsl.g:868:5: (lv_statement_condexprs_2_0= rulecondexpr )
                    // InternalMyDsl.g:869:6: lv_statement_condexprs_2_0= rulecondexpr
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getCondexprAccess().getStatement_condexprsCondexprParserRuleCall_0_2_0());
                      					
                    }
                    pushFollow(FOLLOW_6);
                    lv_statement_condexprs_2_0=rulecondexpr();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getCondexprRule());
                      						}
                      						set(
                      							current,
                      							"statement_condexprs",
                      							lv_statement_condexprs_2_0,
                      							"org.xtext.example.mydsl.MyDsl.condexpr");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    otherlv_3=(Token)match(input,14,FOLLOW_8); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_3, grammarAccess.getCondexprAccess().getRightParenthesisKeyword_0_3());
                      			
                    }
                    // InternalMyDsl.g:890:4: ( (lv_statement_conditional_4_0= ruleconditional ) )
                    // InternalMyDsl.g:891:5: (lv_statement_conditional_4_0= ruleconditional )
                    {
                    // InternalMyDsl.g:891:5: (lv_statement_conditional_4_0= ruleconditional )
                    // InternalMyDsl.g:892:6: lv_statement_conditional_4_0= ruleconditional
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getCondexprAccess().getStatement_conditionalConditionalParserRuleCall_0_4_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_conditional_4_0=ruleconditional();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getCondexprRule());
                      						}
                      						set(
                      							current,
                      							"statement_conditional",
                      							lv_statement_conditional_4_0,
                      							"org.xtext.example.mydsl.MyDsl.conditional");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:911:3: (otherlv_5= '(' ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) ) )
                    {
                    // InternalMyDsl.g:911:3: (otherlv_5= '(' ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) ) )
                    // InternalMyDsl.g:912:4: otherlv_5= '(' ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) )
                    {
                    otherlv_5=(Token)match(input,13,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_5, grammarAccess.getCondexprAccess().getLeftParenthesisKeyword_1_0());
                      			
                    }
                    // InternalMyDsl.g:916:4: ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) )
                    // InternalMyDsl.g:917:5: (lv_statement_aux_condexpr_6_0= ruleaux_condexpr )
                    {
                    // InternalMyDsl.g:917:5: (lv_statement_aux_condexpr_6_0= ruleaux_condexpr )
                    // InternalMyDsl.g:918:6: lv_statement_aux_condexpr_6_0= ruleaux_condexpr
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getCondexprAccess().getStatement_aux_condexprAux_condexprParserRuleCall_1_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_aux_condexpr_6_0=ruleaux_condexpr();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getCondexprRule());
                      						}
                      						set(
                      							current,
                      							"statement_aux_condexpr",
                      							lv_statement_aux_condexpr_6_0,
                      							"org.xtext.example.mydsl.MyDsl.aux_condexpr");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:937:3: ( ( (lv_statement_arith_7_0= rulearith ) ) ( (lv_statement_conditional_8_0= ruleconditional ) ) )
                    {
                    // InternalMyDsl.g:937:3: ( ( (lv_statement_arith_7_0= rulearith ) ) ( (lv_statement_conditional_8_0= ruleconditional ) ) )
                    // InternalMyDsl.g:938:4: ( (lv_statement_arith_7_0= rulearith ) ) ( (lv_statement_conditional_8_0= ruleconditional ) )
                    {
                    // InternalMyDsl.g:938:4: ( (lv_statement_arith_7_0= rulearith ) )
                    // InternalMyDsl.g:939:5: (lv_statement_arith_7_0= rulearith )
                    {
                    // InternalMyDsl.g:939:5: (lv_statement_arith_7_0= rulearith )
                    // InternalMyDsl.g:940:6: lv_statement_arith_7_0= rulearith
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getCondexprAccess().getStatement_arithArithParserRuleCall_2_0_0());
                      					
                    }
                    pushFollow(FOLLOW_8);
                    lv_statement_arith_7_0=rulearith();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getCondexprRule());
                      						}
                      						set(
                      							current,
                      							"statement_arith",
                      							lv_statement_arith_7_0,
                      							"org.xtext.example.mydsl.MyDsl.arith");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalMyDsl.g:957:4: ( (lv_statement_conditional_8_0= ruleconditional ) )
                    // InternalMyDsl.g:958:5: (lv_statement_conditional_8_0= ruleconditional )
                    {
                    // InternalMyDsl.g:958:5: (lv_statement_conditional_8_0= ruleconditional )
                    // InternalMyDsl.g:959:6: lv_statement_conditional_8_0= ruleconditional
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getCondexprAccess().getStatement_conditionalConditionalParserRuleCall_2_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_conditional_8_0=ruleconditional();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getCondexprRule());
                      						}
                      						set(
                      							current,
                      							"statement_conditional",
                      							lv_statement_conditional_8_0,
                      							"org.xtext.example.mydsl.MyDsl.conditional");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulecondexpr"


    // $ANTLR start "entryRuleconditionals_1"
    // InternalMyDsl.g:981:1: entryRuleconditionals_1 returns [EObject current=null] : iv_ruleconditionals_1= ruleconditionals_1 EOF ;
    public final EObject entryRuleconditionals_1() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleconditionals_1 = null;


        try {
            // InternalMyDsl.g:981:55: (iv_ruleconditionals_1= ruleconditionals_1 EOF )
            // InternalMyDsl.g:982:2: iv_ruleconditionals_1= ruleconditionals_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getConditionals_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleconditionals_1=ruleconditionals_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleconditionals_1; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleconditionals_1"


    // $ANTLR start "ruleconditionals_1"
    // InternalMyDsl.g:988:1: ruleconditionals_1 returns [EObject current=null] : ( (otherlv_0= '(' ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ) | ( ( (lv_statement_arith_2_0= rulearith ) ) ( (lv_statement_conditional_3_0= ruleconditional ) ) ) | (otherlv_4= 'not' otherlv_5= '(' ( (lv_statement_condexpr_6_0= rulecondexpr ) ) otherlv_7= ')' ) ) ;
    public final EObject ruleconditionals_1() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        EObject lv_statement_aux_condexpr_1_0 = null;

        EObject lv_statement_arith_2_0 = null;

        EObject lv_statement_conditional_3_0 = null;

        EObject lv_statement_condexpr_6_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:994:2: ( ( (otherlv_0= '(' ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ) | ( ( (lv_statement_arith_2_0= rulearith ) ) ( (lv_statement_conditional_3_0= ruleconditional ) ) ) | (otherlv_4= 'not' otherlv_5= '(' ( (lv_statement_condexpr_6_0= rulecondexpr ) ) otherlv_7= ')' ) ) )
            // InternalMyDsl.g:995:2: ( (otherlv_0= '(' ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ) | ( ( (lv_statement_arith_2_0= rulearith ) ) ( (lv_statement_conditional_3_0= ruleconditional ) ) ) | (otherlv_4= 'not' otherlv_5= '(' ( (lv_statement_condexpr_6_0= rulecondexpr ) ) otherlv_7= ')' ) )
            {
            // InternalMyDsl.g:995:2: ( (otherlv_0= '(' ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ) | ( ( (lv_statement_arith_2_0= rulearith ) ) ( (lv_statement_conditional_3_0= ruleconditional ) ) ) | (otherlv_4= 'not' otherlv_5= '(' ( (lv_statement_condexpr_6_0= rulecondexpr ) ) otherlv_7= ')' ) )
            int alt5=3;
            switch ( input.LA(1) ) {
            case 13:
                {
                int LA5_1 = input.LA(2);

                if ( (synpred15_InternalMyDsl()) ) {
                    alt5=1;
                }
                else if ( (synpred16_InternalMyDsl()) ) {
                    alt5=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 5, 1, input);

                    throw nvae;
                }
                }
                break;
            case RULE_ID:
            case RULE_INT:
            case RULE_DOUBLE:
            case 29:
            case 30:
                {
                alt5=2;
                }
                break;
            case 26:
                {
                alt5=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    // InternalMyDsl.g:996:3: (otherlv_0= '(' ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) )
                    {
                    // InternalMyDsl.g:996:3: (otherlv_0= '(' ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) )
                    // InternalMyDsl.g:997:4: otherlv_0= '(' ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) )
                    {
                    otherlv_0=(Token)match(input,13,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_0, grammarAccess.getConditionals_1Access().getLeftParenthesisKeyword_0_0());
                      			
                    }
                    // InternalMyDsl.g:1001:4: ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) )
                    // InternalMyDsl.g:1002:5: (lv_statement_aux_condexpr_1_0= ruleaux_condexpr )
                    {
                    // InternalMyDsl.g:1002:5: (lv_statement_aux_condexpr_1_0= ruleaux_condexpr )
                    // InternalMyDsl.g:1003:6: lv_statement_aux_condexpr_1_0= ruleaux_condexpr
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionals_1Access().getStatement_aux_condexprAux_condexprParserRuleCall_0_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_aux_condexpr_1_0=ruleaux_condexpr();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionals_1Rule());
                      						}
                      						set(
                      							current,
                      							"statement_aux_condexpr",
                      							lv_statement_aux_condexpr_1_0,
                      							"org.xtext.example.mydsl.MyDsl.aux_condexpr");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1022:3: ( ( (lv_statement_arith_2_0= rulearith ) ) ( (lv_statement_conditional_3_0= ruleconditional ) ) )
                    {
                    // InternalMyDsl.g:1022:3: ( ( (lv_statement_arith_2_0= rulearith ) ) ( (lv_statement_conditional_3_0= ruleconditional ) ) )
                    // InternalMyDsl.g:1023:4: ( (lv_statement_arith_2_0= rulearith ) ) ( (lv_statement_conditional_3_0= ruleconditional ) )
                    {
                    // InternalMyDsl.g:1023:4: ( (lv_statement_arith_2_0= rulearith ) )
                    // InternalMyDsl.g:1024:5: (lv_statement_arith_2_0= rulearith )
                    {
                    // InternalMyDsl.g:1024:5: (lv_statement_arith_2_0= rulearith )
                    // InternalMyDsl.g:1025:6: lv_statement_arith_2_0= rulearith
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionals_1Access().getStatement_arithArithParserRuleCall_1_0_0());
                      					
                    }
                    pushFollow(FOLLOW_8);
                    lv_statement_arith_2_0=rulearith();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionals_1Rule());
                      						}
                      						set(
                      							current,
                      							"statement_arith",
                      							lv_statement_arith_2_0,
                      							"org.xtext.example.mydsl.MyDsl.arith");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalMyDsl.g:1042:4: ( (lv_statement_conditional_3_0= ruleconditional ) )
                    // InternalMyDsl.g:1043:5: (lv_statement_conditional_3_0= ruleconditional )
                    {
                    // InternalMyDsl.g:1043:5: (lv_statement_conditional_3_0= ruleconditional )
                    // InternalMyDsl.g:1044:6: lv_statement_conditional_3_0= ruleconditional
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionals_1Access().getStatement_conditionalConditionalParserRuleCall_1_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_conditional_3_0=ruleconditional();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionals_1Rule());
                      						}
                      						set(
                      							current,
                      							"statement_conditional",
                      							lv_statement_conditional_3_0,
                      							"org.xtext.example.mydsl.MyDsl.conditional");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:1063:3: (otherlv_4= 'not' otherlv_5= '(' ( (lv_statement_condexpr_6_0= rulecondexpr ) ) otherlv_7= ')' )
                    {
                    // InternalMyDsl.g:1063:3: (otherlv_4= 'not' otherlv_5= '(' ( (lv_statement_condexpr_6_0= rulecondexpr ) ) otherlv_7= ')' )
                    // InternalMyDsl.g:1064:4: otherlv_4= 'not' otherlv_5= '(' ( (lv_statement_condexpr_6_0= rulecondexpr ) ) otherlv_7= ')'
                    {
                    otherlv_4=(Token)match(input,26,FOLLOW_4); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_4, grammarAccess.getConditionals_1Access().getNotKeyword_2_0());
                      			
                    }
                    otherlv_5=(Token)match(input,13,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_5, grammarAccess.getConditionals_1Access().getLeftParenthesisKeyword_2_1());
                      			
                    }
                    // InternalMyDsl.g:1072:4: ( (lv_statement_condexpr_6_0= rulecondexpr ) )
                    // InternalMyDsl.g:1073:5: (lv_statement_condexpr_6_0= rulecondexpr )
                    {
                    // InternalMyDsl.g:1073:5: (lv_statement_condexpr_6_0= rulecondexpr )
                    // InternalMyDsl.g:1074:6: lv_statement_condexpr_6_0= rulecondexpr
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionals_1Access().getStatement_condexprCondexprParserRuleCall_2_2_0());
                      					
                    }
                    pushFollow(FOLLOW_6);
                    lv_statement_condexpr_6_0=rulecondexpr();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionals_1Rule());
                      						}
                      						set(
                      							current,
                      							"statement_condexpr",
                      							lv_statement_condexpr_6_0,
                      							"org.xtext.example.mydsl.MyDsl.condexpr");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    otherlv_7=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_7, grammarAccess.getConditionals_1Access().getRightParenthesisKeyword_2_3());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleconditionals_1"


    // $ANTLR start "entryRuleaux_condexpr"
    // InternalMyDsl.g:1100:1: entryRuleaux_condexpr returns [EObject current=null] : iv_ruleaux_condexpr= ruleaux_condexpr EOF ;
    public final EObject entryRuleaux_condexpr() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleaux_condexpr = null;


        try {
            // InternalMyDsl.g:1100:53: (iv_ruleaux_condexpr= ruleaux_condexpr EOF )
            // InternalMyDsl.g:1101:2: iv_ruleaux_condexpr= ruleaux_condexpr EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getAux_condexprRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleaux_condexpr=ruleaux_condexpr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleaux_condexpr; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleaux_condexpr"


    // $ANTLR start "ruleaux_condexpr"
    // InternalMyDsl.g:1107:1: ruleaux_condexpr returns [EObject current=null] : ( (otherlv_0= '(' ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) ) ) | ( ( (lv_statement_arith_3_0= rulearith ) ) ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) ) ) | (otherlv_5= 'not' otherlv_6= '(' ( (lv_statement_condexpr_7_0= rulecondexpr ) ) otherlv_8= ')' ( (lv_statement_optional_parentesis_not_9_0= ruleoptional_parentesis_not ) ) ) ) ;
    public final EObject ruleaux_condexpr() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        EObject lv_statement_aux_condexpr_1_0 = null;

        EObject lv_statement_optional_parentesis_2_0 = null;

        EObject lv_statement_arith_3_0 = null;

        EObject lv_statement_optional_parentesis_4_0 = null;

        EObject lv_statement_condexpr_7_0 = null;

        EObject lv_statement_optional_parentesis_not_9_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1113:2: ( ( (otherlv_0= '(' ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) ) ) | ( ( (lv_statement_arith_3_0= rulearith ) ) ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) ) ) | (otherlv_5= 'not' otherlv_6= '(' ( (lv_statement_condexpr_7_0= rulecondexpr ) ) otherlv_8= ')' ( (lv_statement_optional_parentesis_not_9_0= ruleoptional_parentesis_not ) ) ) ) )
            // InternalMyDsl.g:1114:2: ( (otherlv_0= '(' ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) ) ) | ( ( (lv_statement_arith_3_0= rulearith ) ) ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) ) ) | (otherlv_5= 'not' otherlv_6= '(' ( (lv_statement_condexpr_7_0= rulecondexpr ) ) otherlv_8= ')' ( (lv_statement_optional_parentesis_not_9_0= ruleoptional_parentesis_not ) ) ) )
            {
            // InternalMyDsl.g:1114:2: ( (otherlv_0= '(' ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) ) ) | ( ( (lv_statement_arith_3_0= rulearith ) ) ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) ) ) | (otherlv_5= 'not' otherlv_6= '(' ( (lv_statement_condexpr_7_0= rulecondexpr ) ) otherlv_8= ')' ( (lv_statement_optional_parentesis_not_9_0= ruleoptional_parentesis_not ) ) ) )
            int alt6=3;
            switch ( input.LA(1) ) {
            case 13:
                {
                int LA6_1 = input.LA(2);

                if ( (synpred17_InternalMyDsl()) ) {
                    alt6=1;
                }
                else if ( (synpred18_InternalMyDsl()) ) {
                    alt6=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 6, 1, input);

                    throw nvae;
                }
                }
                break;
            case RULE_ID:
            case RULE_INT:
            case RULE_DOUBLE:
            case 29:
            case 30:
                {
                alt6=2;
                }
                break;
            case 26:
                {
                alt6=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }

            switch (alt6) {
                case 1 :
                    // InternalMyDsl.g:1115:3: (otherlv_0= '(' ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) ) )
                    {
                    // InternalMyDsl.g:1115:3: (otherlv_0= '(' ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) ) )
                    // InternalMyDsl.g:1116:4: otherlv_0= '(' ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) )
                    {
                    otherlv_0=(Token)match(input,13,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_0, grammarAccess.getAux_condexprAccess().getLeftParenthesisKeyword_0_0());
                      			
                    }
                    // InternalMyDsl.g:1120:4: ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) )
                    // InternalMyDsl.g:1121:5: (lv_statement_aux_condexpr_1_0= ruleaux_condexpr )
                    {
                    // InternalMyDsl.g:1121:5: (lv_statement_aux_condexpr_1_0= ruleaux_condexpr )
                    // InternalMyDsl.g:1122:6: lv_statement_aux_condexpr_1_0= ruleaux_condexpr
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getAux_condexprAccess().getStatement_aux_condexprAux_condexprParserRuleCall_0_1_0());
                      					
                    }
                    pushFollow(FOLLOW_9);
                    lv_statement_aux_condexpr_1_0=ruleaux_condexpr();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getAux_condexprRule());
                      						}
                      						set(
                      							current,
                      							"statement_aux_condexpr",
                      							lv_statement_aux_condexpr_1_0,
                      							"org.xtext.example.mydsl.MyDsl.aux_condexpr");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalMyDsl.g:1139:4: ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) )
                    // InternalMyDsl.g:1140:5: (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis )
                    {
                    // InternalMyDsl.g:1140:5: (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis )
                    // InternalMyDsl.g:1141:6: lv_statement_optional_parentesis_2_0= ruleoptional_parentesis
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getAux_condexprAccess().getStatement_optional_parentesisOptional_parentesisParserRuleCall_0_2_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_optional_parentesis_2_0=ruleoptional_parentesis();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getAux_condexprRule());
                      						}
                      						set(
                      							current,
                      							"statement_optional_parentesis",
                      							lv_statement_optional_parentesis_2_0,
                      							"org.xtext.example.mydsl.MyDsl.optional_parentesis");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1160:3: ( ( (lv_statement_arith_3_0= rulearith ) ) ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) ) )
                    {
                    // InternalMyDsl.g:1160:3: ( ( (lv_statement_arith_3_0= rulearith ) ) ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) ) )
                    // InternalMyDsl.g:1161:4: ( (lv_statement_arith_3_0= rulearith ) ) ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) )
                    {
                    // InternalMyDsl.g:1161:4: ( (lv_statement_arith_3_0= rulearith ) )
                    // InternalMyDsl.g:1162:5: (lv_statement_arith_3_0= rulearith )
                    {
                    // InternalMyDsl.g:1162:5: (lv_statement_arith_3_0= rulearith )
                    // InternalMyDsl.g:1163:6: lv_statement_arith_3_0= rulearith
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getAux_condexprAccess().getStatement_arithArithParserRuleCall_1_0_0());
                      					
                    }
                    pushFollow(FOLLOW_9);
                    lv_statement_arith_3_0=rulearith();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getAux_condexprRule());
                      						}
                      						set(
                      							current,
                      							"statement_arith",
                      							lv_statement_arith_3_0,
                      							"org.xtext.example.mydsl.MyDsl.arith");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalMyDsl.g:1180:4: ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) )
                    // InternalMyDsl.g:1181:5: (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis )
                    {
                    // InternalMyDsl.g:1181:5: (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis )
                    // InternalMyDsl.g:1182:6: lv_statement_optional_parentesis_4_0= ruleoptional_parentesis
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getAux_condexprAccess().getStatement_optional_parentesisOptional_parentesisParserRuleCall_1_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_optional_parentesis_4_0=ruleoptional_parentesis();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getAux_condexprRule());
                      						}
                      						set(
                      							current,
                      							"statement_optional_parentesis",
                      							lv_statement_optional_parentesis_4_0,
                      							"org.xtext.example.mydsl.MyDsl.optional_parentesis");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:1201:3: (otherlv_5= 'not' otherlv_6= '(' ( (lv_statement_condexpr_7_0= rulecondexpr ) ) otherlv_8= ')' ( (lv_statement_optional_parentesis_not_9_0= ruleoptional_parentesis_not ) ) )
                    {
                    // InternalMyDsl.g:1201:3: (otherlv_5= 'not' otherlv_6= '(' ( (lv_statement_condexpr_7_0= rulecondexpr ) ) otherlv_8= ')' ( (lv_statement_optional_parentesis_not_9_0= ruleoptional_parentesis_not ) ) )
                    // InternalMyDsl.g:1202:4: otherlv_5= 'not' otherlv_6= '(' ( (lv_statement_condexpr_7_0= rulecondexpr ) ) otherlv_8= ')' ( (lv_statement_optional_parentesis_not_9_0= ruleoptional_parentesis_not ) )
                    {
                    otherlv_5=(Token)match(input,26,FOLLOW_4); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_5, grammarAccess.getAux_condexprAccess().getNotKeyword_2_0());
                      			
                    }
                    otherlv_6=(Token)match(input,13,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_6, grammarAccess.getAux_condexprAccess().getLeftParenthesisKeyword_2_1());
                      			
                    }
                    // InternalMyDsl.g:1210:4: ( (lv_statement_condexpr_7_0= rulecondexpr ) )
                    // InternalMyDsl.g:1211:5: (lv_statement_condexpr_7_0= rulecondexpr )
                    {
                    // InternalMyDsl.g:1211:5: (lv_statement_condexpr_7_0= rulecondexpr )
                    // InternalMyDsl.g:1212:6: lv_statement_condexpr_7_0= rulecondexpr
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getAux_condexprAccess().getStatement_condexprCondexprParserRuleCall_2_2_0());
                      					
                    }
                    pushFollow(FOLLOW_6);
                    lv_statement_condexpr_7_0=rulecondexpr();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getAux_condexprRule());
                      						}
                      						set(
                      							current,
                      							"statement_condexpr",
                      							lv_statement_condexpr_7_0,
                      							"org.xtext.example.mydsl.MyDsl.condexpr");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    otherlv_8=(Token)match(input,14,FOLLOW_9); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_8, grammarAccess.getAux_condexprAccess().getRightParenthesisKeyword_2_3());
                      			
                    }
                    // InternalMyDsl.g:1233:4: ( (lv_statement_optional_parentesis_not_9_0= ruleoptional_parentesis_not ) )
                    // InternalMyDsl.g:1234:5: (lv_statement_optional_parentesis_not_9_0= ruleoptional_parentesis_not )
                    {
                    // InternalMyDsl.g:1234:5: (lv_statement_optional_parentesis_not_9_0= ruleoptional_parentesis_not )
                    // InternalMyDsl.g:1235:6: lv_statement_optional_parentesis_not_9_0= ruleoptional_parentesis_not
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getAux_condexprAccess().getStatement_optional_parentesis_notOptional_parentesis_notParserRuleCall_2_4_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_optional_parentesis_not_9_0=ruleoptional_parentesis_not();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getAux_condexprRule());
                      						}
                      						set(
                      							current,
                      							"statement_optional_parentesis_not",
                      							lv_statement_optional_parentesis_not_9_0,
                      							"org.xtext.example.mydsl.MyDsl.optional_parentesis_not");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleaux_condexpr"


    // $ANTLR start "entryRuleoptional_parentesis"
    // InternalMyDsl.g:1257:1: entryRuleoptional_parentesis returns [EObject current=null] : iv_ruleoptional_parentesis= ruleoptional_parentesis EOF ;
    public final EObject entryRuleoptional_parentesis() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleoptional_parentesis = null;


        try {
            // InternalMyDsl.g:1257:60: (iv_ruleoptional_parentesis= ruleoptional_parentesis EOF )
            // InternalMyDsl.g:1258:2: iv_ruleoptional_parentesis= ruleoptional_parentesis EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getOptional_parentesisRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleoptional_parentesis=ruleoptional_parentesis();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleoptional_parentesis; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleoptional_parentesis"


    // $ANTLR start "ruleoptional_parentesis"
    // InternalMyDsl.g:1264:1: ruleoptional_parentesis returns [EObject current=null] : ( (otherlv_0= ')' ( (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 ) ) ) | ( ( (lv_statement_conditional_2_0= ruleconditional ) ) otherlv_3= ')' ( (lv_statement_optional_parentesis_1_4_0= ruleoptional_parentesis_1 ) ) ) ) ;
    public final EObject ruleoptional_parentesis() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_3=null;
        EObject lv_statement_optional_parentesis_1_1_0 = null;

        EObject lv_statement_conditional_2_0 = null;

        EObject lv_statement_optional_parentesis_1_4_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1270:2: ( ( (otherlv_0= ')' ( (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 ) ) ) | ( ( (lv_statement_conditional_2_0= ruleconditional ) ) otherlv_3= ')' ( (lv_statement_optional_parentesis_1_4_0= ruleoptional_parentesis_1 ) ) ) ) )
            // InternalMyDsl.g:1271:2: ( (otherlv_0= ')' ( (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 ) ) ) | ( ( (lv_statement_conditional_2_0= ruleconditional ) ) otherlv_3= ')' ( (lv_statement_optional_parentesis_1_4_0= ruleoptional_parentesis_1 ) ) ) )
            {
            // InternalMyDsl.g:1271:2: ( (otherlv_0= ')' ( (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 ) ) ) | ( ( (lv_statement_conditional_2_0= ruleconditional ) ) otherlv_3= ')' ( (lv_statement_optional_parentesis_1_4_0= ruleoptional_parentesis_1 ) ) ) )
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==14) ) {
                alt7=1;
            }
            else if ( ((LA7_0>=20 && LA7_0<=25)||(LA7_0>=27 && LA7_0<=28)) ) {
                alt7=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }
            switch (alt7) {
                case 1 :
                    // InternalMyDsl.g:1272:3: (otherlv_0= ')' ( (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 ) ) )
                    {
                    // InternalMyDsl.g:1272:3: (otherlv_0= ')' ( (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 ) ) )
                    // InternalMyDsl.g:1273:4: otherlv_0= ')' ( (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 ) )
                    {
                    otherlv_0=(Token)match(input,14,FOLLOW_10); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_0, grammarAccess.getOptional_parentesisAccess().getRightParenthesisKeyword_0_0());
                      			
                    }
                    // InternalMyDsl.g:1277:4: ( (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 ) )
                    // InternalMyDsl.g:1278:5: (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 )
                    {
                    // InternalMyDsl.g:1278:5: (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 )
                    // InternalMyDsl.g:1279:6: lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getOptional_parentesisAccess().getStatement_optional_parentesis_1Optional_parentesis_1ParserRuleCall_0_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_optional_parentesis_1_1_0=ruleoptional_parentesis_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getOptional_parentesisRule());
                      						}
                      						set(
                      							current,
                      							"statement_optional_parentesis_1",
                      							lv_statement_optional_parentesis_1_1_0,
                      							"org.xtext.example.mydsl.MyDsl.optional_parentesis_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1298:3: ( ( (lv_statement_conditional_2_0= ruleconditional ) ) otherlv_3= ')' ( (lv_statement_optional_parentesis_1_4_0= ruleoptional_parentesis_1 ) ) )
                    {
                    // InternalMyDsl.g:1298:3: ( ( (lv_statement_conditional_2_0= ruleconditional ) ) otherlv_3= ')' ( (lv_statement_optional_parentesis_1_4_0= ruleoptional_parentesis_1 ) ) )
                    // InternalMyDsl.g:1299:4: ( (lv_statement_conditional_2_0= ruleconditional ) ) otherlv_3= ')' ( (lv_statement_optional_parentesis_1_4_0= ruleoptional_parentesis_1 ) )
                    {
                    // InternalMyDsl.g:1299:4: ( (lv_statement_conditional_2_0= ruleconditional ) )
                    // InternalMyDsl.g:1300:5: (lv_statement_conditional_2_0= ruleconditional )
                    {
                    // InternalMyDsl.g:1300:5: (lv_statement_conditional_2_0= ruleconditional )
                    // InternalMyDsl.g:1301:6: lv_statement_conditional_2_0= ruleconditional
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getOptional_parentesisAccess().getStatement_conditionalConditionalParserRuleCall_1_0_0());
                      					
                    }
                    pushFollow(FOLLOW_6);
                    lv_statement_conditional_2_0=ruleconditional();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getOptional_parentesisRule());
                      						}
                      						set(
                      							current,
                      							"statement_conditional",
                      							lv_statement_conditional_2_0,
                      							"org.xtext.example.mydsl.MyDsl.conditional");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    otherlv_3=(Token)match(input,14,FOLLOW_10); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_3, grammarAccess.getOptional_parentesisAccess().getRightParenthesisKeyword_1_1());
                      			
                    }
                    // InternalMyDsl.g:1322:4: ( (lv_statement_optional_parentesis_1_4_0= ruleoptional_parentesis_1 ) )
                    // InternalMyDsl.g:1323:5: (lv_statement_optional_parentesis_1_4_0= ruleoptional_parentesis_1 )
                    {
                    // InternalMyDsl.g:1323:5: (lv_statement_optional_parentesis_1_4_0= ruleoptional_parentesis_1 )
                    // InternalMyDsl.g:1324:6: lv_statement_optional_parentesis_1_4_0= ruleoptional_parentesis_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getOptional_parentesisAccess().getStatement_optional_parentesis_1Optional_parentesis_1ParserRuleCall_1_2_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_optional_parentesis_1_4_0=ruleoptional_parentesis_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getOptional_parentesisRule());
                      						}
                      						set(
                      							current,
                      							"statement_optional_parentesis_1",
                      							lv_statement_optional_parentesis_1_4_0,
                      							"org.xtext.example.mydsl.MyDsl.optional_parentesis_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleoptional_parentesis"


    // $ANTLR start "entryRuleoptional_parentesis_not"
    // InternalMyDsl.g:1346:1: entryRuleoptional_parentesis_not returns [EObject current=null] : iv_ruleoptional_parentesis_not= ruleoptional_parentesis_not EOF ;
    public final EObject entryRuleoptional_parentesis_not() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleoptional_parentesis_not = null;


        try {
            // InternalMyDsl.g:1346:64: (iv_ruleoptional_parentesis_not= ruleoptional_parentesis_not EOF )
            // InternalMyDsl.g:1347:2: iv_ruleoptional_parentesis_not= ruleoptional_parentesis_not EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getOptional_parentesis_notRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleoptional_parentesis_not=ruleoptional_parentesis_not();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleoptional_parentesis_not; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleoptional_parentesis_not"


    // $ANTLR start "ruleoptional_parentesis_not"
    // InternalMyDsl.g:1353:1: ruleoptional_parentesis_not returns [EObject current=null] : ( (otherlv_0= ')' ( (lv_statement_conditional_1_0= ruleconditional ) ) ) | ( ( (lv_statement_conditional_2_0= ruleconditional ) ) otherlv_3= ')' ( (lv_statement_prueba_conditional_4_0= ruleprueba_conditional ) )? ) ) ;
    public final EObject ruleoptional_parentesis_not() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_3=null;
        EObject lv_statement_conditional_1_0 = null;

        EObject lv_statement_conditional_2_0 = null;

        EObject lv_statement_prueba_conditional_4_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1359:2: ( ( (otherlv_0= ')' ( (lv_statement_conditional_1_0= ruleconditional ) ) ) | ( ( (lv_statement_conditional_2_0= ruleconditional ) ) otherlv_3= ')' ( (lv_statement_prueba_conditional_4_0= ruleprueba_conditional ) )? ) ) )
            // InternalMyDsl.g:1360:2: ( (otherlv_0= ')' ( (lv_statement_conditional_1_0= ruleconditional ) ) ) | ( ( (lv_statement_conditional_2_0= ruleconditional ) ) otherlv_3= ')' ( (lv_statement_prueba_conditional_4_0= ruleprueba_conditional ) )? ) )
            {
            // InternalMyDsl.g:1360:2: ( (otherlv_0= ')' ( (lv_statement_conditional_1_0= ruleconditional ) ) ) | ( ( (lv_statement_conditional_2_0= ruleconditional ) ) otherlv_3= ')' ( (lv_statement_prueba_conditional_4_0= ruleprueba_conditional ) )? ) )
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==14) ) {
                alt9=1;
            }
            else if ( ((LA9_0>=20 && LA9_0<=25)||(LA9_0>=27 && LA9_0<=28)) ) {
                alt9=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }
            switch (alt9) {
                case 1 :
                    // InternalMyDsl.g:1361:3: (otherlv_0= ')' ( (lv_statement_conditional_1_0= ruleconditional ) ) )
                    {
                    // InternalMyDsl.g:1361:3: (otherlv_0= ')' ( (lv_statement_conditional_1_0= ruleconditional ) ) )
                    // InternalMyDsl.g:1362:4: otherlv_0= ')' ( (lv_statement_conditional_1_0= ruleconditional ) )
                    {
                    otherlv_0=(Token)match(input,14,FOLLOW_8); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_0, grammarAccess.getOptional_parentesis_notAccess().getRightParenthesisKeyword_0_0());
                      			
                    }
                    // InternalMyDsl.g:1366:4: ( (lv_statement_conditional_1_0= ruleconditional ) )
                    // InternalMyDsl.g:1367:5: (lv_statement_conditional_1_0= ruleconditional )
                    {
                    // InternalMyDsl.g:1367:5: (lv_statement_conditional_1_0= ruleconditional )
                    // InternalMyDsl.g:1368:6: lv_statement_conditional_1_0= ruleconditional
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getOptional_parentesis_notAccess().getStatement_conditionalConditionalParserRuleCall_0_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_conditional_1_0=ruleconditional();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getOptional_parentesis_notRule());
                      						}
                      						set(
                      							current,
                      							"statement_conditional",
                      							lv_statement_conditional_1_0,
                      							"org.xtext.example.mydsl.MyDsl.conditional");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1387:3: ( ( (lv_statement_conditional_2_0= ruleconditional ) ) otherlv_3= ')' ( (lv_statement_prueba_conditional_4_0= ruleprueba_conditional ) )? )
                    {
                    // InternalMyDsl.g:1387:3: ( ( (lv_statement_conditional_2_0= ruleconditional ) ) otherlv_3= ')' ( (lv_statement_prueba_conditional_4_0= ruleprueba_conditional ) )? )
                    // InternalMyDsl.g:1388:4: ( (lv_statement_conditional_2_0= ruleconditional ) ) otherlv_3= ')' ( (lv_statement_prueba_conditional_4_0= ruleprueba_conditional ) )?
                    {
                    // InternalMyDsl.g:1388:4: ( (lv_statement_conditional_2_0= ruleconditional ) )
                    // InternalMyDsl.g:1389:5: (lv_statement_conditional_2_0= ruleconditional )
                    {
                    // InternalMyDsl.g:1389:5: (lv_statement_conditional_2_0= ruleconditional )
                    // InternalMyDsl.g:1390:6: lv_statement_conditional_2_0= ruleconditional
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getOptional_parentesis_notAccess().getStatement_conditionalConditionalParserRuleCall_1_0_0());
                      					
                    }
                    pushFollow(FOLLOW_6);
                    lv_statement_conditional_2_0=ruleconditional();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getOptional_parentesis_notRule());
                      						}
                      						set(
                      							current,
                      							"statement_conditional",
                      							lv_statement_conditional_2_0,
                      							"org.xtext.example.mydsl.MyDsl.conditional");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    otherlv_3=(Token)match(input,14,FOLLOW_11); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_3, grammarAccess.getOptional_parentesis_notAccess().getRightParenthesisKeyword_1_1());
                      			
                    }
                    // InternalMyDsl.g:1411:4: ( (lv_statement_prueba_conditional_4_0= ruleprueba_conditional ) )?
                    int alt8=2;
                    alt8 = dfa8.predict(input);
                    switch (alt8) {
                        case 1 :
                            // InternalMyDsl.g:1412:5: (lv_statement_prueba_conditional_4_0= ruleprueba_conditional )
                            {
                            // InternalMyDsl.g:1412:5: (lv_statement_prueba_conditional_4_0= ruleprueba_conditional )
                            // InternalMyDsl.g:1413:6: lv_statement_prueba_conditional_4_0= ruleprueba_conditional
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getOptional_parentesis_notAccess().getStatement_prueba_conditionalPrueba_conditionalParserRuleCall_1_2_0());
                              					
                            }
                            pushFollow(FOLLOW_2);
                            lv_statement_prueba_conditional_4_0=ruleprueba_conditional();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElementForParent(grammarAccess.getOptional_parentesis_notRule());
                              						}
                              						set(
                              							current,
                              							"statement_prueba_conditional",
                              							lv_statement_prueba_conditional_4_0,
                              							"org.xtext.example.mydsl.MyDsl.prueba_conditional");
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }


                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleoptional_parentesis_not"


    // $ANTLR start "entryRuleoptional_parentesis_1"
    // InternalMyDsl.g:1435:1: entryRuleoptional_parentesis_1 returns [EObject current=null] : iv_ruleoptional_parentesis_1= ruleoptional_parentesis_1 EOF ;
    public final EObject entryRuleoptional_parentesis_1() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleoptional_parentesis_1 = null;


        try {
            // InternalMyDsl.g:1435:62: (iv_ruleoptional_parentesis_1= ruleoptional_parentesis_1 EOF )
            // InternalMyDsl.g:1436:2: iv_ruleoptional_parentesis_1= ruleoptional_parentesis_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getOptional_parentesis_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleoptional_parentesis_1=ruleoptional_parentesis_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleoptional_parentesis_1; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleoptional_parentesis_1"


    // $ANTLR start "ruleoptional_parentesis_1"
    // InternalMyDsl.g:1442:1: ruleoptional_parentesis_1 returns [EObject current=null] : ( ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) ) ) | ( (lv_statement_conditional_2_0= ruleconditional ) ) ) ;
    public final EObject ruleoptional_parentesis_1() throws RecognitionException {
        EObject current = null;

        AntlrDatatypeRuleToken lv_statement_operation_0_0 = null;

        EObject lv_statement_condexpr_1_0 = null;

        EObject lv_statement_conditional_2_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1448:2: ( ( ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) ) ) | ( (lv_statement_conditional_2_0= ruleconditional ) ) ) )
            // InternalMyDsl.g:1449:2: ( ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) ) ) | ( (lv_statement_conditional_2_0= ruleconditional ) ) )
            {
            // InternalMyDsl.g:1449:2: ( ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) ) ) | ( (lv_statement_conditional_2_0= ruleconditional ) ) )
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( ((LA10_0>=29 && LA10_0<=30)||(LA10_0>=35 && LA10_0<=37)) ) {
                alt10=1;
            }
            else if ( ((LA10_0>=20 && LA10_0<=25)||(LA10_0>=27 && LA10_0<=28)) ) {
                alt10=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }
            switch (alt10) {
                case 1 :
                    // InternalMyDsl.g:1450:3: ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) ) )
                    {
                    // InternalMyDsl.g:1450:3: ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) ) )
                    // InternalMyDsl.g:1451:4: ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) )
                    {
                    // InternalMyDsl.g:1451:4: ( (lv_statement_operation_0_0= ruleoperation ) )
                    // InternalMyDsl.g:1452:5: (lv_statement_operation_0_0= ruleoperation )
                    {
                    // InternalMyDsl.g:1452:5: (lv_statement_operation_0_0= ruleoperation )
                    // InternalMyDsl.g:1453:6: lv_statement_operation_0_0= ruleoperation
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getOptional_parentesis_1Access().getStatement_operationOperationParserRuleCall_0_0_0());
                      					
                    }
                    pushFollow(FOLLOW_7);
                    lv_statement_operation_0_0=ruleoperation();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getOptional_parentesis_1Rule());
                      						}
                      						set(
                      							current,
                      							"statement_operation",
                      							lv_statement_operation_0_0,
                      							"org.xtext.example.mydsl.MyDsl.operation");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalMyDsl.g:1470:4: ( (lv_statement_condexpr_1_0= rulecondexpr ) )
                    // InternalMyDsl.g:1471:5: (lv_statement_condexpr_1_0= rulecondexpr )
                    {
                    // InternalMyDsl.g:1471:5: (lv_statement_condexpr_1_0= rulecondexpr )
                    // InternalMyDsl.g:1472:6: lv_statement_condexpr_1_0= rulecondexpr
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getOptional_parentesis_1Access().getStatement_condexprCondexprParserRuleCall_0_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_condexpr_1_0=rulecondexpr();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getOptional_parentesis_1Rule());
                      						}
                      						set(
                      							current,
                      							"statement_condexpr",
                      							lv_statement_condexpr_1_0,
                      							"org.xtext.example.mydsl.MyDsl.condexpr");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1491:3: ( (lv_statement_conditional_2_0= ruleconditional ) )
                    {
                    // InternalMyDsl.g:1491:3: ( (lv_statement_conditional_2_0= ruleconditional ) )
                    // InternalMyDsl.g:1492:4: (lv_statement_conditional_2_0= ruleconditional )
                    {
                    // InternalMyDsl.g:1492:4: (lv_statement_conditional_2_0= ruleconditional )
                    // InternalMyDsl.g:1493:5: lv_statement_conditional_2_0= ruleconditional
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getOptional_parentesis_1Access().getStatement_conditionalConditionalParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_conditional_2_0=ruleconditional();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getOptional_parentesis_1Rule());
                      					}
                      					set(
                      						current,
                      						"statement_conditional",
                      						lv_statement_conditional_2_0,
                      						"org.xtext.example.mydsl.MyDsl.conditional");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleoptional_parentesis_1"


    // $ANTLR start "entryRuleprueba_conditional"
    // InternalMyDsl.g:1514:1: entryRuleprueba_conditional returns [EObject current=null] : iv_ruleprueba_conditional= ruleprueba_conditional EOF ;
    public final EObject entryRuleprueba_conditional() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleprueba_conditional = null;


        try {
            // InternalMyDsl.g:1514:59: (iv_ruleprueba_conditional= ruleprueba_conditional EOF )
            // InternalMyDsl.g:1515:2: iv_ruleprueba_conditional= ruleprueba_conditional EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPrueba_conditionalRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleprueba_conditional=ruleprueba_conditional();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleprueba_conditional; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleprueba_conditional"


    // $ANTLR start "ruleprueba_conditional"
    // InternalMyDsl.g:1521:1: ruleprueba_conditional returns [EObject current=null] : ( ( (lv_statement_conectores_0_0= ruleconectores ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) ) ) ;
    public final EObject ruleprueba_conditional() throws RecognitionException {
        EObject current = null;

        AntlrDatatypeRuleToken lv_statement_conectores_0_0 = null;

        EObject lv_statement_condexpr_1_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1527:2: ( ( ( (lv_statement_conectores_0_0= ruleconectores ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) ) ) )
            // InternalMyDsl.g:1528:2: ( ( (lv_statement_conectores_0_0= ruleconectores ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) ) )
            {
            // InternalMyDsl.g:1528:2: ( ( (lv_statement_conectores_0_0= ruleconectores ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) ) )
            // InternalMyDsl.g:1529:3: ( (lv_statement_conectores_0_0= ruleconectores ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) )
            {
            // InternalMyDsl.g:1529:3: ( (lv_statement_conectores_0_0= ruleconectores ) )
            // InternalMyDsl.g:1530:4: (lv_statement_conectores_0_0= ruleconectores )
            {
            // InternalMyDsl.g:1530:4: (lv_statement_conectores_0_0= ruleconectores )
            // InternalMyDsl.g:1531:5: lv_statement_conectores_0_0= ruleconectores
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getPrueba_conditionalAccess().getStatement_conectoresConectoresParserRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_7);
            lv_statement_conectores_0_0=ruleconectores();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getPrueba_conditionalRule());
              					}
              					set(
              						current,
              						"statement_conectores",
              						lv_statement_conectores_0_0,
              						"org.xtext.example.mydsl.MyDsl.conectores");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalMyDsl.g:1548:3: ( (lv_statement_condexpr_1_0= rulecondexpr ) )
            // InternalMyDsl.g:1549:4: (lv_statement_condexpr_1_0= rulecondexpr )
            {
            // InternalMyDsl.g:1549:4: (lv_statement_condexpr_1_0= rulecondexpr )
            // InternalMyDsl.g:1550:5: lv_statement_condexpr_1_0= rulecondexpr
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getPrueba_conditionalAccess().getStatement_condexprCondexprParserRuleCall_1_0());
              				
            }
            pushFollow(FOLLOW_2);
            lv_statement_condexpr_1_0=rulecondexpr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getPrueba_conditionalRule());
              					}
              					set(
              						current,
              						"statement_condexpr",
              						lv_statement_condexpr_1_0,
              						"org.xtext.example.mydsl.MyDsl.condexpr");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleprueba_conditional"


    // $ANTLR start "entryRuleconectores"
    // InternalMyDsl.g:1571:1: entryRuleconectores returns [String current=null] : iv_ruleconectores= ruleconectores EOF ;
    public final String entryRuleconectores() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleconectores = null;


        try {
            // InternalMyDsl.g:1571:50: (iv_ruleconectores= ruleconectores EOF )
            // InternalMyDsl.g:1572:2: iv_ruleconectores= ruleconectores EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getConectoresRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleconectores=ruleconectores();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleconectores.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleconectores"


    // $ANTLR start "ruleconectores"
    // InternalMyDsl.g:1578:1: ruleconectores returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'and' | kw= 'or' ) ;
    public final AntlrDatatypeRuleToken ruleconectores() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalMyDsl.g:1584:2: ( (kw= 'and' | kw= 'or' ) )
            // InternalMyDsl.g:1585:2: (kw= 'and' | kw= 'or' )
            {
            // InternalMyDsl.g:1585:2: (kw= 'and' | kw= 'or' )
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==27) ) {
                alt11=1;
            }
            else if ( (LA11_0==28) ) {
                alt11=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }
            switch (alt11) {
                case 1 :
                    // InternalMyDsl.g:1586:3: kw= 'and'
                    {
                    kw=(Token)match(input,27,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current.merge(kw);
                      			newLeafNode(kw, grammarAccess.getConectoresAccess().getAndKeyword_0());
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1592:3: kw= 'or'
                    {
                    kw=(Token)match(input,28,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current.merge(kw);
                      			newLeafNode(kw, grammarAccess.getConectoresAccess().getOrKeyword_1());
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleconectores"


    // $ANTLR start "entryRulearith"
    // InternalMyDsl.g:1601:1: entryRulearith returns [EObject current=null] : iv_rulearith= rulearith EOF ;
    public final EObject entryRulearith() throws RecognitionException {
        EObject current = null;

        EObject iv_rulearith = null;


        try {
            // InternalMyDsl.g:1601:46: (iv_rulearith= rulearith EOF )
            // InternalMyDsl.g:1602:2: iv_rulearith= rulearith EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getArithRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulearith=rulearith();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulearith; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulearith"


    // $ANTLR start "rulearith"
    // InternalMyDsl.g:1608:1: rulearith returns [EObject current=null] : ( ( ( (lv_statement_id_arithmetic_0_0= ruleid_arithmetic ) ) ( (lv_statement_arithmetic_1_0= rulearithmetic ) )? ) | (otherlv_2= '+' ( (lv_statement_arith_3_0= rulearith ) ) ) | (otherlv_4= '-' ( (lv_statement_arith_5_0= rulearith ) ) ) | (otherlv_6= '(' ( (lv_statement_arith_7_0= rulearith ) ) otherlv_8= ')' ( (lv_statement_next_parentesis_9_0= rulenext_parentesis ) ) ) ) ;
    public final EObject rulearith() throws RecognitionException {
        EObject current = null;

        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        EObject lv_statement_id_arithmetic_0_0 = null;

        EObject lv_statement_arithmetic_1_0 = null;

        EObject lv_statement_arith_3_0 = null;

        EObject lv_statement_arith_5_0 = null;

        EObject lv_statement_arith_7_0 = null;

        EObject lv_statement_next_parentesis_9_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1614:2: ( ( ( ( (lv_statement_id_arithmetic_0_0= ruleid_arithmetic ) ) ( (lv_statement_arithmetic_1_0= rulearithmetic ) )? ) | (otherlv_2= '+' ( (lv_statement_arith_3_0= rulearith ) ) ) | (otherlv_4= '-' ( (lv_statement_arith_5_0= rulearith ) ) ) | (otherlv_6= '(' ( (lv_statement_arith_7_0= rulearith ) ) otherlv_8= ')' ( (lv_statement_next_parentesis_9_0= rulenext_parentesis ) ) ) ) )
            // InternalMyDsl.g:1615:2: ( ( ( (lv_statement_id_arithmetic_0_0= ruleid_arithmetic ) ) ( (lv_statement_arithmetic_1_0= rulearithmetic ) )? ) | (otherlv_2= '+' ( (lv_statement_arith_3_0= rulearith ) ) ) | (otherlv_4= '-' ( (lv_statement_arith_5_0= rulearith ) ) ) | (otherlv_6= '(' ( (lv_statement_arith_7_0= rulearith ) ) otherlv_8= ')' ( (lv_statement_next_parentesis_9_0= rulenext_parentesis ) ) ) )
            {
            // InternalMyDsl.g:1615:2: ( ( ( (lv_statement_id_arithmetic_0_0= ruleid_arithmetic ) ) ( (lv_statement_arithmetic_1_0= rulearithmetic ) )? ) | (otherlv_2= '+' ( (lv_statement_arith_3_0= rulearith ) ) ) | (otherlv_4= '-' ( (lv_statement_arith_5_0= rulearith ) ) ) | (otherlv_6= '(' ( (lv_statement_arith_7_0= rulearith ) ) otherlv_8= ')' ( (lv_statement_next_parentesis_9_0= rulenext_parentesis ) ) ) )
            int alt13=4;
            switch ( input.LA(1) ) {
            case RULE_ID:
            case RULE_INT:
            case RULE_DOUBLE:
                {
                alt13=1;
                }
                break;
            case 29:
                {
                alt13=2;
                }
                break;
            case 30:
                {
                alt13=3;
                }
                break;
            case 13:
                {
                alt13=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }

            switch (alt13) {
                case 1 :
                    // InternalMyDsl.g:1616:3: ( ( (lv_statement_id_arithmetic_0_0= ruleid_arithmetic ) ) ( (lv_statement_arithmetic_1_0= rulearithmetic ) )? )
                    {
                    // InternalMyDsl.g:1616:3: ( ( (lv_statement_id_arithmetic_0_0= ruleid_arithmetic ) ) ( (lv_statement_arithmetic_1_0= rulearithmetic ) )? )
                    // InternalMyDsl.g:1617:4: ( (lv_statement_id_arithmetic_0_0= ruleid_arithmetic ) ) ( (lv_statement_arithmetic_1_0= rulearithmetic ) )?
                    {
                    // InternalMyDsl.g:1617:4: ( (lv_statement_id_arithmetic_0_0= ruleid_arithmetic ) )
                    // InternalMyDsl.g:1618:5: (lv_statement_id_arithmetic_0_0= ruleid_arithmetic )
                    {
                    // InternalMyDsl.g:1618:5: (lv_statement_id_arithmetic_0_0= ruleid_arithmetic )
                    // InternalMyDsl.g:1619:6: lv_statement_id_arithmetic_0_0= ruleid_arithmetic
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithAccess().getStatement_id_arithmeticId_arithmeticParserRuleCall_0_0_0());
                      					
                    }
                    pushFollow(FOLLOW_12);
                    lv_statement_id_arithmetic_0_0=ruleid_arithmetic();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithRule());
                      						}
                      						set(
                      							current,
                      							"statement_id_arithmetic",
                      							lv_statement_id_arithmetic_0_0,
                      							"org.xtext.example.mydsl.MyDsl.id_arithmetic");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalMyDsl.g:1636:4: ( (lv_statement_arithmetic_1_0= rulearithmetic ) )?
                    int alt12=2;
                    int LA12_0 = input.LA(1);

                    if ( ((LA12_0>=29 && LA12_0<=30)||(LA12_0>=35 && LA12_0<=37)) ) {
                        alt12=1;
                    }
                    switch (alt12) {
                        case 1 :
                            // InternalMyDsl.g:1637:5: (lv_statement_arithmetic_1_0= rulearithmetic )
                            {
                            // InternalMyDsl.g:1637:5: (lv_statement_arithmetic_1_0= rulearithmetic )
                            // InternalMyDsl.g:1638:6: lv_statement_arithmetic_1_0= rulearithmetic
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getArithAccess().getStatement_arithmeticArithmeticParserRuleCall_0_1_0());
                              					
                            }
                            pushFollow(FOLLOW_2);
                            lv_statement_arithmetic_1_0=rulearithmetic();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElementForParent(grammarAccess.getArithRule());
                              						}
                              						set(
                              							current,
                              							"statement_arithmetic",
                              							lv_statement_arithmetic_1_0,
                              							"org.xtext.example.mydsl.MyDsl.arithmetic");
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1657:3: (otherlv_2= '+' ( (lv_statement_arith_3_0= rulearith ) ) )
                    {
                    // InternalMyDsl.g:1657:3: (otherlv_2= '+' ( (lv_statement_arith_3_0= rulearith ) ) )
                    // InternalMyDsl.g:1658:4: otherlv_2= '+' ( (lv_statement_arith_3_0= rulearith ) )
                    {
                    otherlv_2=(Token)match(input,29,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_2, grammarAccess.getArithAccess().getPlusSignKeyword_1_0());
                      			
                    }
                    // InternalMyDsl.g:1662:4: ( (lv_statement_arith_3_0= rulearith ) )
                    // InternalMyDsl.g:1663:5: (lv_statement_arith_3_0= rulearith )
                    {
                    // InternalMyDsl.g:1663:5: (lv_statement_arith_3_0= rulearith )
                    // InternalMyDsl.g:1664:6: lv_statement_arith_3_0= rulearith
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithAccess().getStatement_arithArithParserRuleCall_1_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_arith_3_0=rulearith();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithRule());
                      						}
                      						set(
                      							current,
                      							"statement_arith",
                      							lv_statement_arith_3_0,
                      							"org.xtext.example.mydsl.MyDsl.arith");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:1683:3: (otherlv_4= '-' ( (lv_statement_arith_5_0= rulearith ) ) )
                    {
                    // InternalMyDsl.g:1683:3: (otherlv_4= '-' ( (lv_statement_arith_5_0= rulearith ) ) )
                    // InternalMyDsl.g:1684:4: otherlv_4= '-' ( (lv_statement_arith_5_0= rulearith ) )
                    {
                    otherlv_4=(Token)match(input,30,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_4, grammarAccess.getArithAccess().getHyphenMinusKeyword_2_0());
                      			
                    }
                    // InternalMyDsl.g:1688:4: ( (lv_statement_arith_5_0= rulearith ) )
                    // InternalMyDsl.g:1689:5: (lv_statement_arith_5_0= rulearith )
                    {
                    // InternalMyDsl.g:1689:5: (lv_statement_arith_5_0= rulearith )
                    // InternalMyDsl.g:1690:6: lv_statement_arith_5_0= rulearith
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithAccess().getStatement_arithArithParserRuleCall_2_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_arith_5_0=rulearith();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithRule());
                      						}
                      						set(
                      							current,
                      							"statement_arith",
                      							lv_statement_arith_5_0,
                      							"org.xtext.example.mydsl.MyDsl.arith");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:1709:3: (otherlv_6= '(' ( (lv_statement_arith_7_0= rulearith ) ) otherlv_8= ')' ( (lv_statement_next_parentesis_9_0= rulenext_parentesis ) ) )
                    {
                    // InternalMyDsl.g:1709:3: (otherlv_6= '(' ( (lv_statement_arith_7_0= rulearith ) ) otherlv_8= ')' ( (lv_statement_next_parentesis_9_0= rulenext_parentesis ) ) )
                    // InternalMyDsl.g:1710:4: otherlv_6= '(' ( (lv_statement_arith_7_0= rulearith ) ) otherlv_8= ')' ( (lv_statement_next_parentesis_9_0= rulenext_parentesis ) )
                    {
                    otherlv_6=(Token)match(input,13,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_6, grammarAccess.getArithAccess().getLeftParenthesisKeyword_3_0());
                      			
                    }
                    // InternalMyDsl.g:1714:4: ( (lv_statement_arith_7_0= rulearith ) )
                    // InternalMyDsl.g:1715:5: (lv_statement_arith_7_0= rulearith )
                    {
                    // InternalMyDsl.g:1715:5: (lv_statement_arith_7_0= rulearith )
                    // InternalMyDsl.g:1716:6: lv_statement_arith_7_0= rulearith
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithAccess().getStatement_arithArithParserRuleCall_3_1_0());
                      					
                    }
                    pushFollow(FOLLOW_6);
                    lv_statement_arith_7_0=rulearith();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithRule());
                      						}
                      						set(
                      							current,
                      							"statement_arith",
                      							lv_statement_arith_7_0,
                      							"org.xtext.example.mydsl.MyDsl.arith");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    otherlv_8=(Token)match(input,14,FOLLOW_13); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_8, grammarAccess.getArithAccess().getRightParenthesisKeyword_3_2());
                      			
                    }
                    // InternalMyDsl.g:1737:4: ( (lv_statement_next_parentesis_9_0= rulenext_parentesis ) )
                    // InternalMyDsl.g:1738:5: (lv_statement_next_parentesis_9_0= rulenext_parentesis )
                    {
                    // InternalMyDsl.g:1738:5: (lv_statement_next_parentesis_9_0= rulenext_parentesis )
                    // InternalMyDsl.g:1739:6: lv_statement_next_parentesis_9_0= rulenext_parentesis
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithAccess().getStatement_next_parentesisNext_parentesisParserRuleCall_3_3_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_next_parentesis_9_0=rulenext_parentesis();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithRule());
                      						}
                      						set(
                      							current,
                      							"statement_next_parentesis",
                      							lv_statement_next_parentesis_9_0,
                      							"org.xtext.example.mydsl.MyDsl.next_parentesis");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulearith"


    // $ANTLR start "entryRulenext_parentesis"
    // InternalMyDsl.g:1761:1: entryRulenext_parentesis returns [EObject current=null] : iv_rulenext_parentesis= rulenext_parentesis EOF ;
    public final EObject entryRulenext_parentesis() throws RecognitionException {
        EObject current = null;

        EObject iv_rulenext_parentesis = null;


        try {
            // InternalMyDsl.g:1761:56: (iv_rulenext_parentesis= rulenext_parentesis EOF )
            // InternalMyDsl.g:1762:2: iv_rulenext_parentesis= rulenext_parentesis EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getNext_parentesisRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulenext_parentesis=rulenext_parentesis();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulenext_parentesis; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulenext_parentesis"


    // $ANTLR start "rulenext_parentesis"
    // InternalMyDsl.g:1768:1: rulenext_parentesis returns [EObject current=null] : ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_arith_1_0= rulearith ) ) ) ;
    public final EObject rulenext_parentesis() throws RecognitionException {
        EObject current = null;

        AntlrDatatypeRuleToken lv_statement_operation_0_0 = null;

        EObject lv_statement_arith_1_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1774:2: ( ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_arith_1_0= rulearith ) ) ) )
            // InternalMyDsl.g:1775:2: ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_arith_1_0= rulearith ) ) )
            {
            // InternalMyDsl.g:1775:2: ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_arith_1_0= rulearith ) ) )
            // InternalMyDsl.g:1776:3: ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_arith_1_0= rulearith ) )
            {
            // InternalMyDsl.g:1776:3: ( (lv_statement_operation_0_0= ruleoperation ) )
            // InternalMyDsl.g:1777:4: (lv_statement_operation_0_0= ruleoperation )
            {
            // InternalMyDsl.g:1777:4: (lv_statement_operation_0_0= ruleoperation )
            // InternalMyDsl.g:1778:5: lv_statement_operation_0_0= ruleoperation
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getNext_parentesisAccess().getStatement_operationOperationParserRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_7);
            lv_statement_operation_0_0=ruleoperation();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getNext_parentesisRule());
              					}
              					set(
              						current,
              						"statement_operation",
              						lv_statement_operation_0_0,
              						"org.xtext.example.mydsl.MyDsl.operation");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalMyDsl.g:1795:3: ( (lv_statement_arith_1_0= rulearith ) )
            // InternalMyDsl.g:1796:4: (lv_statement_arith_1_0= rulearith )
            {
            // InternalMyDsl.g:1796:4: (lv_statement_arith_1_0= rulearith )
            // InternalMyDsl.g:1797:5: lv_statement_arith_1_0= rulearith
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getNext_parentesisAccess().getStatement_arithArithParserRuleCall_1_0());
              				
            }
            pushFollow(FOLLOW_2);
            lv_statement_arith_1_0=rulearith();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getNext_parentesisRule());
              					}
              					set(
              						current,
              						"statement_arith",
              						lv_statement_arith_1_0,
              						"org.xtext.example.mydsl.MyDsl.arith");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulenext_parentesis"


    // $ANTLR start "entryRulearithmetic"
    // InternalMyDsl.g:1818:1: entryRulearithmetic returns [EObject current=null] : iv_rulearithmetic= rulearithmetic EOF ;
    public final EObject entryRulearithmetic() throws RecognitionException {
        EObject current = null;

        EObject iv_rulearithmetic = null;


        try {
            // InternalMyDsl.g:1818:51: (iv_rulearithmetic= rulearithmetic EOF )
            // InternalMyDsl.g:1819:2: iv_rulearithmetic= rulearithmetic EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getArithmeticRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulearithmetic=rulearithmetic();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulearithmetic; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulearithmetic"


    // $ANTLR start "rulearithmetic"
    // InternalMyDsl.g:1825:1: rulearithmetic returns [EObject current=null] : ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_arith_1_0= rulearith ) ) ) ;
    public final EObject rulearithmetic() throws RecognitionException {
        EObject current = null;

        AntlrDatatypeRuleToken lv_statement_operation_0_0 = null;

        EObject lv_statement_arith_1_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1831:2: ( ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_arith_1_0= rulearith ) ) ) )
            // InternalMyDsl.g:1832:2: ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_arith_1_0= rulearith ) ) )
            {
            // InternalMyDsl.g:1832:2: ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_arith_1_0= rulearith ) ) )
            // InternalMyDsl.g:1833:3: ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_arith_1_0= rulearith ) )
            {
            // InternalMyDsl.g:1833:3: ( (lv_statement_operation_0_0= ruleoperation ) )
            // InternalMyDsl.g:1834:4: (lv_statement_operation_0_0= ruleoperation )
            {
            // InternalMyDsl.g:1834:4: (lv_statement_operation_0_0= ruleoperation )
            // InternalMyDsl.g:1835:5: lv_statement_operation_0_0= ruleoperation
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getArithmeticAccess().getStatement_operationOperationParserRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_7);
            lv_statement_operation_0_0=ruleoperation();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getArithmeticRule());
              					}
              					set(
              						current,
              						"statement_operation",
              						lv_statement_operation_0_0,
              						"org.xtext.example.mydsl.MyDsl.operation");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalMyDsl.g:1852:3: ( (lv_statement_arith_1_0= rulearith ) )
            // InternalMyDsl.g:1853:4: (lv_statement_arith_1_0= rulearith )
            {
            // InternalMyDsl.g:1853:4: (lv_statement_arith_1_0= rulearith )
            // InternalMyDsl.g:1854:5: lv_statement_arith_1_0= rulearith
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getArithmeticAccess().getStatement_arithArithParserRuleCall_1_0());
              				
            }
            pushFollow(FOLLOW_2);
            lv_statement_arith_1_0=rulearith();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getArithmeticRule());
              					}
              					set(
              						current,
              						"statement_arith",
              						lv_statement_arith_1_0,
              						"org.xtext.example.mydsl.MyDsl.arith");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulearithmetic"


    // $ANTLR start "entryRuleid_arithmetic"
    // InternalMyDsl.g:1875:1: entryRuleid_arithmetic returns [EObject current=null] : iv_ruleid_arithmetic= ruleid_arithmetic EOF ;
    public final EObject entryRuleid_arithmetic() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleid_arithmetic = null;


        try {
            // InternalMyDsl.g:1875:54: (iv_ruleid_arithmetic= ruleid_arithmetic EOF )
            // InternalMyDsl.g:1876:2: iv_ruleid_arithmetic= ruleid_arithmetic EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getId_arithmeticRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleid_arithmetic=ruleid_arithmetic();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleid_arithmetic; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleid_arithmetic"


    // $ANTLR start "ruleid_arithmetic"
    // InternalMyDsl.g:1882:1: ruleid_arithmetic returns [EObject current=null] : ( (this_ID_0= RULE_ID ( (lv_statement_function_arith_1_0= rulefunction_arith ) )? ) | this_INT_2= RULE_INT | this_DOUBLE_3= RULE_DOUBLE ) ;
    public final EObject ruleid_arithmetic() throws RecognitionException {
        EObject current = null;

        Token this_ID_0=null;
        Token this_INT_2=null;
        Token this_DOUBLE_3=null;
        EObject lv_statement_function_arith_1_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1888:2: ( ( (this_ID_0= RULE_ID ( (lv_statement_function_arith_1_0= rulefunction_arith ) )? ) | this_INT_2= RULE_INT | this_DOUBLE_3= RULE_DOUBLE ) )
            // InternalMyDsl.g:1889:2: ( (this_ID_0= RULE_ID ( (lv_statement_function_arith_1_0= rulefunction_arith ) )? ) | this_INT_2= RULE_INT | this_DOUBLE_3= RULE_DOUBLE )
            {
            // InternalMyDsl.g:1889:2: ( (this_ID_0= RULE_ID ( (lv_statement_function_arith_1_0= rulefunction_arith ) )? ) | this_INT_2= RULE_INT | this_DOUBLE_3= RULE_DOUBLE )
            int alt15=3;
            switch ( input.LA(1) ) {
            case RULE_ID:
                {
                alt15=1;
                }
                break;
            case RULE_INT:
                {
                alt15=2;
                }
                break;
            case RULE_DOUBLE:
                {
                alt15=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 15, 0, input);

                throw nvae;
            }

            switch (alt15) {
                case 1 :
                    // InternalMyDsl.g:1890:3: (this_ID_0= RULE_ID ( (lv_statement_function_arith_1_0= rulefunction_arith ) )? )
                    {
                    // InternalMyDsl.g:1890:3: (this_ID_0= RULE_ID ( (lv_statement_function_arith_1_0= rulefunction_arith ) )? )
                    // InternalMyDsl.g:1891:4: this_ID_0= RULE_ID ( (lv_statement_function_arith_1_0= rulefunction_arith ) )?
                    {
                    this_ID_0=(Token)match(input,RULE_ID,FOLLOW_14); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_ID_0, grammarAccess.getId_arithmeticAccess().getIDTerminalRuleCall_0_0());
                      			
                    }
                    // InternalMyDsl.g:1895:4: ( (lv_statement_function_arith_1_0= rulefunction_arith ) )?
                    int alt14=2;
                    int LA14_0 = input.LA(1);

                    if ( (LA14_0==31||LA14_0==33) ) {
                        alt14=1;
                    }
                    switch (alt14) {
                        case 1 :
                            // InternalMyDsl.g:1896:5: (lv_statement_function_arith_1_0= rulefunction_arith )
                            {
                            // InternalMyDsl.g:1896:5: (lv_statement_function_arith_1_0= rulefunction_arith )
                            // InternalMyDsl.g:1897:6: lv_statement_function_arith_1_0= rulefunction_arith
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getId_arithmeticAccess().getStatement_function_arithFunction_arithParserRuleCall_0_1_0());
                              					
                            }
                            pushFollow(FOLLOW_2);
                            lv_statement_function_arith_1_0=rulefunction_arith();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElementForParent(grammarAccess.getId_arithmeticRule());
                              						}
                              						set(
                              							current,
                              							"statement_function_arith",
                              							lv_statement_function_arith_1_0,
                              							"org.xtext.example.mydsl.MyDsl.function_arith");
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1916:3: this_INT_2= RULE_INT
                    {
                    this_INT_2=(Token)match(input,RULE_INT,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			newLeafNode(this_INT_2, grammarAccess.getId_arithmeticAccess().getINTTerminalRuleCall_1());
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:1921:3: this_DOUBLE_3= RULE_DOUBLE
                    {
                    this_DOUBLE_3=(Token)match(input,RULE_DOUBLE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			newLeafNode(this_DOUBLE_3, grammarAccess.getId_arithmeticAccess().getDOUBLETerminalRuleCall_2());
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleid_arithmetic"


    // $ANTLR start "entryRulefunction_arith"
    // InternalMyDsl.g:1929:1: entryRulefunction_arith returns [EObject current=null] : iv_rulefunction_arith= rulefunction_arith EOF ;
    public final EObject entryRulefunction_arith() throws RecognitionException {
        EObject current = null;

        EObject iv_rulefunction_arith = null;


        try {
            // InternalMyDsl.g:1929:55: (iv_rulefunction_arith= rulefunction_arith EOF )
            // InternalMyDsl.g:1930:2: iv_rulefunction_arith= rulefunction_arith EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getFunction_arithRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulefunction_arith=rulefunction_arith();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulefunction_arith; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulefunction_arith"


    // $ANTLR start "rulefunction_arith"
    // InternalMyDsl.g:1936:1: rulefunction_arith returns [EObject current=null] : ( (otherlv_0= '[' ( (lv_statement_arith_1_0= rulearith ) ) otherlv_2= ']' ) | (otherlv_3= '.' otherlv_4= 'size' ) ) ;
    public final EObject rulefunction_arith() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        EObject lv_statement_arith_1_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1942:2: ( ( (otherlv_0= '[' ( (lv_statement_arith_1_0= rulearith ) ) otherlv_2= ']' ) | (otherlv_3= '.' otherlv_4= 'size' ) ) )
            // InternalMyDsl.g:1943:2: ( (otherlv_0= '[' ( (lv_statement_arith_1_0= rulearith ) ) otherlv_2= ']' ) | (otherlv_3= '.' otherlv_4= 'size' ) )
            {
            // InternalMyDsl.g:1943:2: ( (otherlv_0= '[' ( (lv_statement_arith_1_0= rulearith ) ) otherlv_2= ']' ) | (otherlv_3= '.' otherlv_4= 'size' ) )
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==31) ) {
                alt16=1;
            }
            else if ( (LA16_0==33) ) {
                alt16=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 16, 0, input);

                throw nvae;
            }
            switch (alt16) {
                case 1 :
                    // InternalMyDsl.g:1944:3: (otherlv_0= '[' ( (lv_statement_arith_1_0= rulearith ) ) otherlv_2= ']' )
                    {
                    // InternalMyDsl.g:1944:3: (otherlv_0= '[' ( (lv_statement_arith_1_0= rulearith ) ) otherlv_2= ']' )
                    // InternalMyDsl.g:1945:4: otherlv_0= '[' ( (lv_statement_arith_1_0= rulearith ) ) otherlv_2= ']'
                    {
                    otherlv_0=(Token)match(input,31,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_0, grammarAccess.getFunction_arithAccess().getLeftSquareBracketKeyword_0_0());
                      			
                    }
                    // InternalMyDsl.g:1949:4: ( (lv_statement_arith_1_0= rulearith ) )
                    // InternalMyDsl.g:1950:5: (lv_statement_arith_1_0= rulearith )
                    {
                    // InternalMyDsl.g:1950:5: (lv_statement_arith_1_0= rulearith )
                    // InternalMyDsl.g:1951:6: lv_statement_arith_1_0= rulearith
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getFunction_arithAccess().getStatement_arithArithParserRuleCall_0_1_0());
                      					
                    }
                    pushFollow(FOLLOW_15);
                    lv_statement_arith_1_0=rulearith();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getFunction_arithRule());
                      						}
                      						set(
                      							current,
                      							"statement_arith",
                      							lv_statement_arith_1_0,
                      							"org.xtext.example.mydsl.MyDsl.arith");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    otherlv_2=(Token)match(input,32,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_2, grammarAccess.getFunction_arithAccess().getRightSquareBracketKeyword_0_2());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1974:3: (otherlv_3= '.' otherlv_4= 'size' )
                    {
                    // InternalMyDsl.g:1974:3: (otherlv_3= '.' otherlv_4= 'size' )
                    // InternalMyDsl.g:1975:4: otherlv_3= '.' otherlv_4= 'size'
                    {
                    otherlv_3=(Token)match(input,33,FOLLOW_16); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_3, grammarAccess.getFunction_arithAccess().getFullStopKeyword_1_0());
                      			
                    }
                    otherlv_4=(Token)match(input,34,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_4, grammarAccess.getFunction_arithAccess().getSizeKeyword_1_1());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulefunction_arith"


    // $ANTLR start "entryRuleoperation"
    // InternalMyDsl.g:1988:1: entryRuleoperation returns [String current=null] : iv_ruleoperation= ruleoperation EOF ;
    public final String entryRuleoperation() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleoperation = null;


        try {
            // InternalMyDsl.g:1988:49: (iv_ruleoperation= ruleoperation EOF )
            // InternalMyDsl.g:1989:2: iv_ruleoperation= ruleoperation EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getOperationRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleoperation=ruleoperation();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleoperation.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleoperation"


    // $ANTLR start "ruleoperation"
    // InternalMyDsl.g:1995:1: ruleoperation returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= '+' | kw= '-' | kw= '*' | kw= '/' | kw= '%' ) ;
    public final AntlrDatatypeRuleToken ruleoperation() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalMyDsl.g:2001:2: ( (kw= '+' | kw= '-' | kw= '*' | kw= '/' | kw= '%' ) )
            // InternalMyDsl.g:2002:2: (kw= '+' | kw= '-' | kw= '*' | kw= '/' | kw= '%' )
            {
            // InternalMyDsl.g:2002:2: (kw= '+' | kw= '-' | kw= '*' | kw= '/' | kw= '%' )
            int alt17=5;
            switch ( input.LA(1) ) {
            case 29:
                {
                alt17=1;
                }
                break;
            case 30:
                {
                alt17=2;
                }
                break;
            case 35:
                {
                alt17=3;
                }
                break;
            case 36:
                {
                alt17=4;
                }
                break;
            case 37:
                {
                alt17=5;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;
            }

            switch (alt17) {
                case 1 :
                    // InternalMyDsl.g:2003:3: kw= '+'
                    {
                    kw=(Token)match(input,29,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current.merge(kw);
                      			newLeafNode(kw, grammarAccess.getOperationAccess().getPlusSignKeyword_0());
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:2009:3: kw= '-'
                    {
                    kw=(Token)match(input,30,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current.merge(kw);
                      			newLeafNode(kw, grammarAccess.getOperationAccess().getHyphenMinusKeyword_1());
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:2015:3: kw= '*'
                    {
                    kw=(Token)match(input,35,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current.merge(kw);
                      			newLeafNode(kw, grammarAccess.getOperationAccess().getAsteriskKeyword_2());
                      		
                    }

                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:2021:3: kw= '/'
                    {
                    kw=(Token)match(input,36,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current.merge(kw);
                      			newLeafNode(kw, grammarAccess.getOperationAccess().getSolidusKeyword_3());
                      		
                    }

                    }
                    break;
                case 5 :
                    // InternalMyDsl.g:2027:3: kw= '%'
                    {
                    kw=(Token)match(input,37,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current.merge(kw);
                      			newLeafNode(kw, grammarAccess.getOperationAccess().getPercentSignKeyword_4());
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleoperation"

    // $ANTLR start synpred14_InternalMyDsl
    public final void synpred14_InternalMyDsl_fragment() throws RecognitionException {   
        Token otherlv_5=null;
        EObject lv_statement_aux_condexpr_6_0 = null;


        // InternalMyDsl.g:911:3: ( (otherlv_5= '(' ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) ) ) )
        // InternalMyDsl.g:911:3: (otherlv_5= '(' ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) ) )
        {
        // InternalMyDsl.g:911:3: (otherlv_5= '(' ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) ) )
        // InternalMyDsl.g:912:4: otherlv_5= '(' ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) )
        {
        otherlv_5=(Token)match(input,13,FOLLOW_7); if (state.failed) return ;
        // InternalMyDsl.g:916:4: ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) )
        // InternalMyDsl.g:917:5: (lv_statement_aux_condexpr_6_0= ruleaux_condexpr )
        {
        // InternalMyDsl.g:917:5: (lv_statement_aux_condexpr_6_0= ruleaux_condexpr )
        // InternalMyDsl.g:918:6: lv_statement_aux_condexpr_6_0= ruleaux_condexpr
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getCondexprAccess().getStatement_aux_condexprAux_condexprParserRuleCall_1_1_0());
          					
        }
        pushFollow(FOLLOW_2);
        lv_statement_aux_condexpr_6_0=ruleaux_condexpr();

        state._fsp--;
        if (state.failed) return ;

        }


        }


        }


        }
    }
    // $ANTLR end synpred14_InternalMyDsl

    // $ANTLR start synpred15_InternalMyDsl
    public final void synpred15_InternalMyDsl_fragment() throws RecognitionException {   
        Token otherlv_0=null;
        EObject lv_statement_aux_condexpr_1_0 = null;


        // InternalMyDsl.g:996:3: ( (otherlv_0= '(' ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ) )
        // InternalMyDsl.g:996:3: (otherlv_0= '(' ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) )
        {
        // InternalMyDsl.g:996:3: (otherlv_0= '(' ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) )
        // InternalMyDsl.g:997:4: otherlv_0= '(' ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) )
        {
        otherlv_0=(Token)match(input,13,FOLLOW_7); if (state.failed) return ;
        // InternalMyDsl.g:1001:4: ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) )
        // InternalMyDsl.g:1002:5: (lv_statement_aux_condexpr_1_0= ruleaux_condexpr )
        {
        // InternalMyDsl.g:1002:5: (lv_statement_aux_condexpr_1_0= ruleaux_condexpr )
        // InternalMyDsl.g:1003:6: lv_statement_aux_condexpr_1_0= ruleaux_condexpr
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getConditionals_1Access().getStatement_aux_condexprAux_condexprParserRuleCall_0_1_0());
          					
        }
        pushFollow(FOLLOW_2);
        lv_statement_aux_condexpr_1_0=ruleaux_condexpr();

        state._fsp--;
        if (state.failed) return ;

        }


        }


        }


        }
    }
    // $ANTLR end synpred15_InternalMyDsl

    // $ANTLR start synpred16_InternalMyDsl
    public final void synpred16_InternalMyDsl_fragment() throws RecognitionException {   
        EObject lv_statement_arith_2_0 = null;

        EObject lv_statement_conditional_3_0 = null;


        // InternalMyDsl.g:1022:3: ( ( ( (lv_statement_arith_2_0= rulearith ) ) ( (lv_statement_conditional_3_0= ruleconditional ) ) ) )
        // InternalMyDsl.g:1022:3: ( ( (lv_statement_arith_2_0= rulearith ) ) ( (lv_statement_conditional_3_0= ruleconditional ) ) )
        {
        // InternalMyDsl.g:1022:3: ( ( (lv_statement_arith_2_0= rulearith ) ) ( (lv_statement_conditional_3_0= ruleconditional ) ) )
        // InternalMyDsl.g:1023:4: ( (lv_statement_arith_2_0= rulearith ) ) ( (lv_statement_conditional_3_0= ruleconditional ) )
        {
        // InternalMyDsl.g:1023:4: ( (lv_statement_arith_2_0= rulearith ) )
        // InternalMyDsl.g:1024:5: (lv_statement_arith_2_0= rulearith )
        {
        // InternalMyDsl.g:1024:5: (lv_statement_arith_2_0= rulearith )
        // InternalMyDsl.g:1025:6: lv_statement_arith_2_0= rulearith
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getConditionals_1Access().getStatement_arithArithParserRuleCall_1_0_0());
          					
        }
        pushFollow(FOLLOW_8);
        lv_statement_arith_2_0=rulearith();

        state._fsp--;
        if (state.failed) return ;

        }


        }

        // InternalMyDsl.g:1042:4: ( (lv_statement_conditional_3_0= ruleconditional ) )
        // InternalMyDsl.g:1043:5: (lv_statement_conditional_3_0= ruleconditional )
        {
        // InternalMyDsl.g:1043:5: (lv_statement_conditional_3_0= ruleconditional )
        // InternalMyDsl.g:1044:6: lv_statement_conditional_3_0= ruleconditional
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getConditionals_1Access().getStatement_conditionalConditionalParserRuleCall_1_1_0());
          					
        }
        pushFollow(FOLLOW_2);
        lv_statement_conditional_3_0=ruleconditional();

        state._fsp--;
        if (state.failed) return ;

        }


        }


        }


        }
    }
    // $ANTLR end synpred16_InternalMyDsl

    // $ANTLR start synpred17_InternalMyDsl
    public final void synpred17_InternalMyDsl_fragment() throws RecognitionException {   
        Token otherlv_0=null;
        EObject lv_statement_aux_condexpr_1_0 = null;

        EObject lv_statement_optional_parentesis_2_0 = null;


        // InternalMyDsl.g:1115:3: ( (otherlv_0= '(' ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) ) ) )
        // InternalMyDsl.g:1115:3: (otherlv_0= '(' ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) ) )
        {
        // InternalMyDsl.g:1115:3: (otherlv_0= '(' ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) ) )
        // InternalMyDsl.g:1116:4: otherlv_0= '(' ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) )
        {
        otherlv_0=(Token)match(input,13,FOLLOW_7); if (state.failed) return ;
        // InternalMyDsl.g:1120:4: ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) )
        // InternalMyDsl.g:1121:5: (lv_statement_aux_condexpr_1_0= ruleaux_condexpr )
        {
        // InternalMyDsl.g:1121:5: (lv_statement_aux_condexpr_1_0= ruleaux_condexpr )
        // InternalMyDsl.g:1122:6: lv_statement_aux_condexpr_1_0= ruleaux_condexpr
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getAux_condexprAccess().getStatement_aux_condexprAux_condexprParserRuleCall_0_1_0());
          					
        }
        pushFollow(FOLLOW_9);
        lv_statement_aux_condexpr_1_0=ruleaux_condexpr();

        state._fsp--;
        if (state.failed) return ;

        }


        }

        // InternalMyDsl.g:1139:4: ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) )
        // InternalMyDsl.g:1140:5: (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis )
        {
        // InternalMyDsl.g:1140:5: (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis )
        // InternalMyDsl.g:1141:6: lv_statement_optional_parentesis_2_0= ruleoptional_parentesis
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getAux_condexprAccess().getStatement_optional_parentesisOptional_parentesisParserRuleCall_0_2_0());
          					
        }
        pushFollow(FOLLOW_2);
        lv_statement_optional_parentesis_2_0=ruleoptional_parentesis();

        state._fsp--;
        if (state.failed) return ;

        }


        }


        }


        }
    }
    // $ANTLR end synpred17_InternalMyDsl

    // $ANTLR start synpred18_InternalMyDsl
    public final void synpred18_InternalMyDsl_fragment() throws RecognitionException {   
        EObject lv_statement_arith_3_0 = null;

        EObject lv_statement_optional_parentesis_4_0 = null;


        // InternalMyDsl.g:1160:3: ( ( ( (lv_statement_arith_3_0= rulearith ) ) ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) ) ) )
        // InternalMyDsl.g:1160:3: ( ( (lv_statement_arith_3_0= rulearith ) ) ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) ) )
        {
        // InternalMyDsl.g:1160:3: ( ( (lv_statement_arith_3_0= rulearith ) ) ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) ) )
        // InternalMyDsl.g:1161:4: ( (lv_statement_arith_3_0= rulearith ) ) ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) )
        {
        // InternalMyDsl.g:1161:4: ( (lv_statement_arith_3_0= rulearith ) )
        // InternalMyDsl.g:1162:5: (lv_statement_arith_3_0= rulearith )
        {
        // InternalMyDsl.g:1162:5: (lv_statement_arith_3_0= rulearith )
        // InternalMyDsl.g:1163:6: lv_statement_arith_3_0= rulearith
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getAux_condexprAccess().getStatement_arithArithParserRuleCall_1_0_0());
          					
        }
        pushFollow(FOLLOW_9);
        lv_statement_arith_3_0=rulearith();

        state._fsp--;
        if (state.failed) return ;

        }


        }

        // InternalMyDsl.g:1180:4: ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) )
        // InternalMyDsl.g:1181:5: (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis )
        {
        // InternalMyDsl.g:1181:5: (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis )
        // InternalMyDsl.g:1182:6: lv_statement_optional_parentesis_4_0= ruleoptional_parentesis
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getAux_condexprAccess().getStatement_optional_parentesisOptional_parentesisParserRuleCall_1_1_0());
          					
        }
        pushFollow(FOLLOW_2);
        lv_statement_optional_parentesis_4_0=ruleoptional_parentesis();

        state._fsp--;
        if (state.failed) return ;

        }


        }


        }


        }
    }
    // $ANTLR end synpred18_InternalMyDsl

    // $ANTLR start synpred21_InternalMyDsl
    public final void synpred21_InternalMyDsl_fragment() throws RecognitionException {   
        EObject lv_statement_prueba_conditional_4_0 = null;


        // InternalMyDsl.g:1412:5: ( (lv_statement_prueba_conditional_4_0= ruleprueba_conditional ) )
        // InternalMyDsl.g:1412:5: (lv_statement_prueba_conditional_4_0= ruleprueba_conditional )
        {
        // InternalMyDsl.g:1412:5: (lv_statement_prueba_conditional_4_0= ruleprueba_conditional )
        // InternalMyDsl.g:1413:6: lv_statement_prueba_conditional_4_0= ruleprueba_conditional
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getOptional_parentesis_notAccess().getStatement_prueba_conditionalPrueba_conditionalParserRuleCall_1_2_0());
          					
        }
        pushFollow(FOLLOW_2);
        lv_statement_prueba_conditional_4_0=ruleprueba_conditional();

        state._fsp--;
        if (state.failed) return ;

        }


        }
    }
    // $ANTLR end synpred21_InternalMyDsl

    // Delegated rules

    public final boolean synpred16_InternalMyDsl() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred16_InternalMyDsl_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred15_InternalMyDsl() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred15_InternalMyDsl_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred21_InternalMyDsl() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred21_InternalMyDsl_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred14_InternalMyDsl() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred14_InternalMyDsl_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred17_InternalMyDsl() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred17_InternalMyDsl_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred18_InternalMyDsl() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred18_InternalMyDsl_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }


    protected DFA8 dfa8 = new DFA8(this);
    static final String dfa_1s = "\14\uffff";
    static final String dfa_2s = "\1\3\13\uffff";
    static final String dfa_3s = "\1\16\2\0\11\uffff";
    static final String dfa_4s = "\1\34\2\0\11\uffff";
    static final String dfa_5s = "\3\uffff\1\2\7\uffff\1\1";
    static final String dfa_6s = "\1\uffff\1\0\1\1\11\uffff}>";
    static final String[] dfa_7s = {
            "\1\3\5\uffff\6\3\1\uffff\1\1\1\2",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final short[] dfa_2 = DFA.unpackEncodedString(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final char[] dfa_4 = DFA.unpackEncodedStringToUnsignedChars(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[] dfa_6 = DFA.unpackEncodedString(dfa_6s);
    static final short[][] dfa_7 = unpackEncodedStringArray(dfa_7s);

    class DFA8 extends DFA {

        public DFA8(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 8;
            this.eot = dfa_1;
            this.eof = dfa_2;
            this.min = dfa_3;
            this.max = dfa_4;
            this.accept = dfa_5;
            this.special = dfa_6;
            this.transition = dfa_7;
        }
        public String getDescription() {
            return "1411:4: ( (lv_statement_prueba_conditional_4_0= ruleprueba_conditional ) )?";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA8_1 = input.LA(1);

                         
                        int index8_1 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred21_InternalMyDsl()) ) {s = 11;}

                        else if ( (true) ) {s = 3;}

                         
                        input.seek(index8_1);
                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA8_2 = input.LA(1);

                         
                        int index8_2 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred21_InternalMyDsl()) ) {s = 11;}

                        else if ( (true) ) {s = 3;}

                         
                        input.seek(index8_2);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 8, _s, input);
            error(nvae);
            throw nvae;
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x00000000000F9002L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000064002070L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x000000001BF00000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x000000001BF04000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x000000387BF00000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x000000001BF00002L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000003860000002L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000003860000000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000280000002L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000100000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000400000000L});

}