package org.xtext.example.mydsl.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.example.mydsl.services.DomainModelGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
@SuppressWarnings("all")
public class InternalDomainModelParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_DOUBLE", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'CreateInteger'", "'('", "')'", "'CreateFloat'", "'CreateString'", "'CreateBoolean'", "'CreateList'", "'CreatePermutation'", "'CreateChar'", "'name'", "'='", "'condition'", "'format'", "'length_type'", "'min_length'", "'max_length'", "'content_type'", "'word_set'", "'['", "','", "']'", "'=='", "'!='", "'<'", "'>'", "'<='", "'>='", "'not'", "'and'", "'or'", "'.'", "'size'", "'+'", "'-'", "'*'", "'/'", "'%'"
    };
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int RULE_ID=4;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=8;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=9;
    public static final int T__37=37;
    public static final int RULE_DOUBLE=7;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=10;
    public static final int RULE_ANY_OTHER=11;
    public static final int T__48=48;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalDomainModelParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalDomainModelParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalDomainModelParser.tokenNames; }
    public String getGrammarFileName() { return "InternalDomainModel.g"; }



    /*
      This grammar contains a lot of empty actions to work around a bug in ANTLR.
      Otherwise the ANTLR tool will create synpreds that cannot be compiled in some rare cases.
    */

     	private DomainModelGrammarAccess grammarAccess;

        public InternalDomainModelParser(TokenStream input, DomainModelGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Model";
       	}

       	@Override
       	protected DomainModelGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleModel"
    // InternalDomainModel.g:70:1: entryRuleModel returns [EObject current=null] : iv_ruleModel= ruleModel EOF ;
    public final EObject entryRuleModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModel = null;


        try {
            // InternalDomainModel.g:70:46: (iv_ruleModel= ruleModel EOF )
            // InternalDomainModel.g:71:2: iv_ruleModel= ruleModel EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getModelRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleModel=ruleModel();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleModel; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalDomainModel.g:77:1: ruleModel returns [EObject current=null] : ( (lv_staments_0_0= ruleStatement ) )+ ;
    public final EObject ruleModel() throws RecognitionException {
        EObject current = null;

        EObject lv_staments_0_0 = null;



        	enterRule();

        try {
            // InternalDomainModel.g:83:2: ( ( (lv_staments_0_0= ruleStatement ) )+ )
            // InternalDomainModel.g:84:2: ( (lv_staments_0_0= ruleStatement ) )+
            {
            // InternalDomainModel.g:84:2: ( (lv_staments_0_0= ruleStatement ) )+
            int cnt1=0;
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==12||(LA1_0>=15 && LA1_0<=20)) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalDomainModel.g:85:3: (lv_staments_0_0= ruleStatement )
            	    {
            	    // InternalDomainModel.g:85:3: (lv_staments_0_0= ruleStatement )
            	    // InternalDomainModel.g:86:4: lv_staments_0_0= ruleStatement
            	    {
            	    if ( state.backtracking==0 ) {

            	      				newCompositeNode(grammarAccess.getModelAccess().getStamentsStatementParserRuleCall_0());
            	      			
            	    }
            	    pushFollow(FOLLOW_3);
            	    lv_staments_0_0=ruleStatement();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      				if (current==null) {
            	      					current = createModelElementForParent(grammarAccess.getModelRule());
            	      				}
            	      				add(
            	      					current,
            	      					"staments",
            	      					lv_staments_0_0,
            	      					"org.xtext.example.mydsl.DomainModel.Statement");
            	      				afterParserOrEnumRuleCall();
            	      			
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleStatement"
    // InternalDomainModel.g:106:1: entryRuleStatement returns [EObject current=null] : iv_ruleStatement= ruleStatement EOF ;
    public final EObject entryRuleStatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStatement = null;


        try {
            // InternalDomainModel.g:106:50: (iv_ruleStatement= ruleStatement EOF )
            // InternalDomainModel.g:107:2: iv_ruleStatement= ruleStatement EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getStatementRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleStatement=ruleStatement();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleStatement; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStatement"


    // $ANTLR start "ruleStatement"
    // InternalDomainModel.g:113:1: ruleStatement returns [EObject current=null] : ( (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' ) | (otherlv_4= 'CreateFloat' otherlv_5= '(' ( (lv_statementFloat_6_0= ruleparametersFloat ) ) otherlv_7= ')' ) | (otherlv_8= 'CreateString' otherlv_9= '(' ( (lv_statementString_10_0= ruleparametersString ) ) otherlv_11= ')' ) | (otherlv_12= 'CreateBoolean' otherlv_13= '(' ( (lv_statementBoolean_14_0= ruleparametersBoolean ) ) otherlv_15= ')' ) | (otherlv_16= 'CreateList' otherlv_17= '(' ( (lv_statementList_18_0= ruleparametersList ) )? otherlv_19= ')' ) | (otherlv_20= 'CreatePermutation' otherlv_21= '(' ( (lv_statementPermutation_22_0= ruleparametersPermutation ) ) otherlv_23= ')' ) | (otherlv_24= 'CreateChar' otherlv_25= '(' ( (lv_statementChar_26_0= ruleparametersChar ) ) otherlv_27= ')' ) ) ;
    public final EObject ruleStatement() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        Token otherlv_13=null;
        Token otherlv_15=null;
        Token otherlv_16=null;
        Token otherlv_17=null;
        Token otherlv_19=null;
        Token otherlv_20=null;
        Token otherlv_21=null;
        Token otherlv_23=null;
        Token otherlv_24=null;
        Token otherlv_25=null;
        Token otherlv_27=null;
        EObject lv_statementInteger_2_0 = null;

        EObject lv_statementFloat_6_0 = null;

        EObject lv_statementString_10_0 = null;

        EObject lv_statementBoolean_14_0 = null;

        EObject lv_statementList_18_0 = null;

        EObject lv_statementPermutation_22_0 = null;

        EObject lv_statementChar_26_0 = null;



        	enterRule();

        try {
            // InternalDomainModel.g:119:2: ( ( (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' ) | (otherlv_4= 'CreateFloat' otherlv_5= '(' ( (lv_statementFloat_6_0= ruleparametersFloat ) ) otherlv_7= ')' ) | (otherlv_8= 'CreateString' otherlv_9= '(' ( (lv_statementString_10_0= ruleparametersString ) ) otherlv_11= ')' ) | (otherlv_12= 'CreateBoolean' otherlv_13= '(' ( (lv_statementBoolean_14_0= ruleparametersBoolean ) ) otherlv_15= ')' ) | (otherlv_16= 'CreateList' otherlv_17= '(' ( (lv_statementList_18_0= ruleparametersList ) )? otherlv_19= ')' ) | (otherlv_20= 'CreatePermutation' otherlv_21= '(' ( (lv_statementPermutation_22_0= ruleparametersPermutation ) ) otherlv_23= ')' ) | (otherlv_24= 'CreateChar' otherlv_25= '(' ( (lv_statementChar_26_0= ruleparametersChar ) ) otherlv_27= ')' ) ) )
            // InternalDomainModel.g:120:2: ( (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' ) | (otherlv_4= 'CreateFloat' otherlv_5= '(' ( (lv_statementFloat_6_0= ruleparametersFloat ) ) otherlv_7= ')' ) | (otherlv_8= 'CreateString' otherlv_9= '(' ( (lv_statementString_10_0= ruleparametersString ) ) otherlv_11= ')' ) | (otherlv_12= 'CreateBoolean' otherlv_13= '(' ( (lv_statementBoolean_14_0= ruleparametersBoolean ) ) otherlv_15= ')' ) | (otherlv_16= 'CreateList' otherlv_17= '(' ( (lv_statementList_18_0= ruleparametersList ) )? otherlv_19= ')' ) | (otherlv_20= 'CreatePermutation' otherlv_21= '(' ( (lv_statementPermutation_22_0= ruleparametersPermutation ) ) otherlv_23= ')' ) | (otherlv_24= 'CreateChar' otherlv_25= '(' ( (lv_statementChar_26_0= ruleparametersChar ) ) otherlv_27= ')' ) )
            {
            // InternalDomainModel.g:120:2: ( (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' ) | (otherlv_4= 'CreateFloat' otherlv_5= '(' ( (lv_statementFloat_6_0= ruleparametersFloat ) ) otherlv_7= ')' ) | (otherlv_8= 'CreateString' otherlv_9= '(' ( (lv_statementString_10_0= ruleparametersString ) ) otherlv_11= ')' ) | (otherlv_12= 'CreateBoolean' otherlv_13= '(' ( (lv_statementBoolean_14_0= ruleparametersBoolean ) ) otherlv_15= ')' ) | (otherlv_16= 'CreateList' otherlv_17= '(' ( (lv_statementList_18_0= ruleparametersList ) )? otherlv_19= ')' ) | (otherlv_20= 'CreatePermutation' otherlv_21= '(' ( (lv_statementPermutation_22_0= ruleparametersPermutation ) ) otherlv_23= ')' ) | (otherlv_24= 'CreateChar' otherlv_25= '(' ( (lv_statementChar_26_0= ruleparametersChar ) ) otherlv_27= ')' ) )
            int alt3=7;
            switch ( input.LA(1) ) {
            case 12:
                {
                alt3=1;
                }
                break;
            case 15:
                {
                alt3=2;
                }
                break;
            case 16:
                {
                alt3=3;
                }
                break;
            case 17:
                {
                alt3=4;
                }
                break;
            case 18:
                {
                alt3=5;
                }
                break;
            case 19:
                {
                alt3=6;
                }
                break;
            case 20:
                {
                alt3=7;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // InternalDomainModel.g:121:3: (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' )
                    {
                    // InternalDomainModel.g:121:3: (otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')' )
                    // InternalDomainModel.g:122:4: otherlv_0= 'CreateInteger' otherlv_1= '(' ( (lv_statementInteger_2_0= ruleparametersInteger ) ) otherlv_3= ')'
                    {
                    otherlv_0=(Token)match(input,12,FOLLOW_4); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_0, grammarAccess.getStatementAccess().getCreateIntegerKeyword_0_0());
                      			
                    }
                    otherlv_1=(Token)match(input,13,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_1, grammarAccess.getStatementAccess().getLeftParenthesisKeyword_0_1());
                      			
                    }
                    // InternalDomainModel.g:130:4: ( (lv_statementInteger_2_0= ruleparametersInteger ) )
                    // InternalDomainModel.g:131:5: (lv_statementInteger_2_0= ruleparametersInteger )
                    {
                    // InternalDomainModel.g:131:5: (lv_statementInteger_2_0= ruleparametersInteger )
                    // InternalDomainModel.g:132:6: lv_statementInteger_2_0= ruleparametersInteger
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getStatementAccess().getStatementIntegerParametersIntegerParserRuleCall_0_2_0());
                      					
                    }
                    pushFollow(FOLLOW_6);
                    lv_statementInteger_2_0=ruleparametersInteger();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getStatementRule());
                      						}
                      						set(
                      							current,
                      							"statementInteger",
                      							lv_statementInteger_2_0,
                      							"org.xtext.example.mydsl.DomainModel.parametersInteger");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    otherlv_3=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_3, grammarAccess.getStatementAccess().getRightParenthesisKeyword_0_3());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalDomainModel.g:155:3: (otherlv_4= 'CreateFloat' otherlv_5= '(' ( (lv_statementFloat_6_0= ruleparametersFloat ) ) otherlv_7= ')' )
                    {
                    // InternalDomainModel.g:155:3: (otherlv_4= 'CreateFloat' otherlv_5= '(' ( (lv_statementFloat_6_0= ruleparametersFloat ) ) otherlv_7= ')' )
                    // InternalDomainModel.g:156:4: otherlv_4= 'CreateFloat' otherlv_5= '(' ( (lv_statementFloat_6_0= ruleparametersFloat ) ) otherlv_7= ')'
                    {
                    otherlv_4=(Token)match(input,15,FOLLOW_4); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_4, grammarAccess.getStatementAccess().getCreateFloatKeyword_1_0());
                      			
                    }
                    otherlv_5=(Token)match(input,13,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_5, grammarAccess.getStatementAccess().getLeftParenthesisKeyword_1_1());
                      			
                    }
                    // InternalDomainModel.g:164:4: ( (lv_statementFloat_6_0= ruleparametersFloat ) )
                    // InternalDomainModel.g:165:5: (lv_statementFloat_6_0= ruleparametersFloat )
                    {
                    // InternalDomainModel.g:165:5: (lv_statementFloat_6_0= ruleparametersFloat )
                    // InternalDomainModel.g:166:6: lv_statementFloat_6_0= ruleparametersFloat
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getStatementAccess().getStatementFloatParametersFloatParserRuleCall_1_2_0());
                      					
                    }
                    pushFollow(FOLLOW_6);
                    lv_statementFloat_6_0=ruleparametersFloat();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getStatementRule());
                      						}
                      						set(
                      							current,
                      							"statementFloat",
                      							lv_statementFloat_6_0,
                      							"org.xtext.example.mydsl.DomainModel.parametersFloat");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    otherlv_7=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_7, grammarAccess.getStatementAccess().getRightParenthesisKeyword_1_3());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalDomainModel.g:189:3: (otherlv_8= 'CreateString' otherlv_9= '(' ( (lv_statementString_10_0= ruleparametersString ) ) otherlv_11= ')' )
                    {
                    // InternalDomainModel.g:189:3: (otherlv_8= 'CreateString' otherlv_9= '(' ( (lv_statementString_10_0= ruleparametersString ) ) otherlv_11= ')' )
                    // InternalDomainModel.g:190:4: otherlv_8= 'CreateString' otherlv_9= '(' ( (lv_statementString_10_0= ruleparametersString ) ) otherlv_11= ')'
                    {
                    otherlv_8=(Token)match(input,16,FOLLOW_4); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_8, grammarAccess.getStatementAccess().getCreateStringKeyword_2_0());
                      			
                    }
                    otherlv_9=(Token)match(input,13,FOLLOW_8); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_9, grammarAccess.getStatementAccess().getLeftParenthesisKeyword_2_1());
                      			
                    }
                    // InternalDomainModel.g:198:4: ( (lv_statementString_10_0= ruleparametersString ) )
                    // InternalDomainModel.g:199:5: (lv_statementString_10_0= ruleparametersString )
                    {
                    // InternalDomainModel.g:199:5: (lv_statementString_10_0= ruleparametersString )
                    // InternalDomainModel.g:200:6: lv_statementString_10_0= ruleparametersString
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getStatementAccess().getStatementStringParametersStringParserRuleCall_2_2_0());
                      					
                    }
                    pushFollow(FOLLOW_6);
                    lv_statementString_10_0=ruleparametersString();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getStatementRule());
                      						}
                      						set(
                      							current,
                      							"statementString",
                      							lv_statementString_10_0,
                      							"org.xtext.example.mydsl.DomainModel.parametersString");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    otherlv_11=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_11, grammarAccess.getStatementAccess().getRightParenthesisKeyword_2_3());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalDomainModel.g:223:3: (otherlv_12= 'CreateBoolean' otherlv_13= '(' ( (lv_statementBoolean_14_0= ruleparametersBoolean ) ) otherlv_15= ')' )
                    {
                    // InternalDomainModel.g:223:3: (otherlv_12= 'CreateBoolean' otherlv_13= '(' ( (lv_statementBoolean_14_0= ruleparametersBoolean ) ) otherlv_15= ')' )
                    // InternalDomainModel.g:224:4: otherlv_12= 'CreateBoolean' otherlv_13= '(' ( (lv_statementBoolean_14_0= ruleparametersBoolean ) ) otherlv_15= ')'
                    {
                    otherlv_12=(Token)match(input,17,FOLLOW_4); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_12, grammarAccess.getStatementAccess().getCreateBooleanKeyword_3_0());
                      			
                    }
                    otherlv_13=(Token)match(input,13,FOLLOW_9); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_13, grammarAccess.getStatementAccess().getLeftParenthesisKeyword_3_1());
                      			
                    }
                    // InternalDomainModel.g:232:4: ( (lv_statementBoolean_14_0= ruleparametersBoolean ) )
                    // InternalDomainModel.g:233:5: (lv_statementBoolean_14_0= ruleparametersBoolean )
                    {
                    // InternalDomainModel.g:233:5: (lv_statementBoolean_14_0= ruleparametersBoolean )
                    // InternalDomainModel.g:234:6: lv_statementBoolean_14_0= ruleparametersBoolean
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getStatementAccess().getStatementBooleanParametersBooleanParserRuleCall_3_2_0());
                      					
                    }
                    pushFollow(FOLLOW_6);
                    lv_statementBoolean_14_0=ruleparametersBoolean();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getStatementRule());
                      						}
                      						set(
                      							current,
                      							"statementBoolean",
                      							lv_statementBoolean_14_0,
                      							"org.xtext.example.mydsl.DomainModel.parametersBoolean");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    otherlv_15=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_15, grammarAccess.getStatementAccess().getRightParenthesisKeyword_3_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalDomainModel.g:257:3: (otherlv_16= 'CreateList' otherlv_17= '(' ( (lv_statementList_18_0= ruleparametersList ) )? otherlv_19= ')' )
                    {
                    // InternalDomainModel.g:257:3: (otherlv_16= 'CreateList' otherlv_17= '(' ( (lv_statementList_18_0= ruleparametersList ) )? otherlv_19= ')' )
                    // InternalDomainModel.g:258:4: otherlv_16= 'CreateList' otherlv_17= '(' ( (lv_statementList_18_0= ruleparametersList ) )? otherlv_19= ')'
                    {
                    otherlv_16=(Token)match(input,18,FOLLOW_4); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_16, grammarAccess.getStatementAccess().getCreateListKeyword_4_0());
                      			
                    }
                    otherlv_17=(Token)match(input,13,FOLLOW_10); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_17, grammarAccess.getStatementAccess().getLeftParenthesisKeyword_4_1());
                      			
                    }
                    // InternalDomainModel.g:266:4: ( (lv_statementList_18_0= ruleparametersList ) )?
                    int alt2=2;
                    int LA2_0 = input.LA(1);

                    if ( ((LA2_0>=25 && LA2_0<=28)) ) {
                        alt2=1;
                    }
                    switch (alt2) {
                        case 1 :
                            // InternalDomainModel.g:267:5: (lv_statementList_18_0= ruleparametersList )
                            {
                            // InternalDomainModel.g:267:5: (lv_statementList_18_0= ruleparametersList )
                            // InternalDomainModel.g:268:6: lv_statementList_18_0= ruleparametersList
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getStatementAccess().getStatementListParametersListParserRuleCall_4_2_0());
                              					
                            }
                            pushFollow(FOLLOW_6);
                            lv_statementList_18_0=ruleparametersList();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElementForParent(grammarAccess.getStatementRule());
                              						}
                              						set(
                              							current,
                              							"statementList",
                              							lv_statementList_18_0,
                              							"org.xtext.example.mydsl.DomainModel.parametersList");
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }


                            }
                            break;

                    }

                    otherlv_19=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_19, grammarAccess.getStatementAccess().getRightParenthesisKeyword_4_3());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalDomainModel.g:291:3: (otherlv_20= 'CreatePermutation' otherlv_21= '(' ( (lv_statementPermutation_22_0= ruleparametersPermutation ) ) otherlv_23= ')' )
                    {
                    // InternalDomainModel.g:291:3: (otherlv_20= 'CreatePermutation' otherlv_21= '(' ( (lv_statementPermutation_22_0= ruleparametersPermutation ) ) otherlv_23= ')' )
                    // InternalDomainModel.g:292:4: otherlv_20= 'CreatePermutation' otherlv_21= '(' ( (lv_statementPermutation_22_0= ruleparametersPermutation ) ) otherlv_23= ')'
                    {
                    otherlv_20=(Token)match(input,19,FOLLOW_4); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_20, grammarAccess.getStatementAccess().getCreatePermutationKeyword_5_0());
                      			
                    }
                    otherlv_21=(Token)match(input,13,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_21, grammarAccess.getStatementAccess().getLeftParenthesisKeyword_5_1());
                      			
                    }
                    // InternalDomainModel.g:300:4: ( (lv_statementPermutation_22_0= ruleparametersPermutation ) )
                    // InternalDomainModel.g:301:5: (lv_statementPermutation_22_0= ruleparametersPermutation )
                    {
                    // InternalDomainModel.g:301:5: (lv_statementPermutation_22_0= ruleparametersPermutation )
                    // InternalDomainModel.g:302:6: lv_statementPermutation_22_0= ruleparametersPermutation
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getStatementAccess().getStatementPermutationParametersPermutationParserRuleCall_5_2_0());
                      					
                    }
                    pushFollow(FOLLOW_6);
                    lv_statementPermutation_22_0=ruleparametersPermutation();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getStatementRule());
                      						}
                      						set(
                      							current,
                      							"statementPermutation",
                      							lv_statementPermutation_22_0,
                      							"org.xtext.example.mydsl.DomainModel.parametersPermutation");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    otherlv_23=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_23, grammarAccess.getStatementAccess().getRightParenthesisKeyword_5_3());
                      			
                    }

                    }


                    }
                    break;
                case 7 :
                    // InternalDomainModel.g:325:3: (otherlv_24= 'CreateChar' otherlv_25= '(' ( (lv_statementChar_26_0= ruleparametersChar ) ) otherlv_27= ')' )
                    {
                    // InternalDomainModel.g:325:3: (otherlv_24= 'CreateChar' otherlv_25= '(' ( (lv_statementChar_26_0= ruleparametersChar ) ) otherlv_27= ')' )
                    // InternalDomainModel.g:326:4: otherlv_24= 'CreateChar' otherlv_25= '(' ( (lv_statementChar_26_0= ruleparametersChar ) ) otherlv_27= ')'
                    {
                    otherlv_24=(Token)match(input,20,FOLLOW_4); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_24, grammarAccess.getStatementAccess().getCreateCharKeyword_6_0());
                      			
                    }
                    otherlv_25=(Token)match(input,13,FOLLOW_8); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_25, grammarAccess.getStatementAccess().getLeftParenthesisKeyword_6_1());
                      			
                    }
                    // InternalDomainModel.g:334:4: ( (lv_statementChar_26_0= ruleparametersChar ) )
                    // InternalDomainModel.g:335:5: (lv_statementChar_26_0= ruleparametersChar )
                    {
                    // InternalDomainModel.g:335:5: (lv_statementChar_26_0= ruleparametersChar )
                    // InternalDomainModel.g:336:6: lv_statementChar_26_0= ruleparametersChar
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getStatementAccess().getStatementCharParametersCharParserRuleCall_6_2_0());
                      					
                    }
                    pushFollow(FOLLOW_6);
                    lv_statementChar_26_0=ruleparametersChar();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getStatementRule());
                      						}
                      						set(
                      							current,
                      							"statementChar",
                      							lv_statementChar_26_0,
                      							"org.xtext.example.mydsl.DomainModel.parametersChar");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    otherlv_27=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_27, grammarAccess.getStatementAccess().getRightParenthesisKeyword_6_3());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStatement"


    // $ANTLR start "entryRuleoption_name"
    // InternalDomainModel.g:362:1: entryRuleoption_name returns [EObject current=null] : iv_ruleoption_name= ruleoption_name EOF ;
    public final EObject entryRuleoption_name() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleoption_name = null;


        try {
            // InternalDomainModel.g:362:52: (iv_ruleoption_name= ruleoption_name EOF )
            // InternalDomainModel.g:363:2: iv_ruleoption_name= ruleoption_name EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getOption_nameRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleoption_name=ruleoption_name();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleoption_name; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleoption_name"


    // $ANTLR start "ruleoption_name"
    // InternalDomainModel.g:369:1: ruleoption_name returns [EObject current=null] : (otherlv_0= 'name' otherlv_1= '=' ( (lv_id_name_2_0= RULE_ID ) ) ) ;
    public final EObject ruleoption_name() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_id_name_2_0=null;


        	enterRule();

        try {
            // InternalDomainModel.g:375:2: ( (otherlv_0= 'name' otherlv_1= '=' ( (lv_id_name_2_0= RULE_ID ) ) ) )
            // InternalDomainModel.g:376:2: (otherlv_0= 'name' otherlv_1= '=' ( (lv_id_name_2_0= RULE_ID ) ) )
            {
            // InternalDomainModel.g:376:2: (otherlv_0= 'name' otherlv_1= '=' ( (lv_id_name_2_0= RULE_ID ) ) )
            // InternalDomainModel.g:377:3: otherlv_0= 'name' otherlv_1= '=' ( (lv_id_name_2_0= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,21,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getOption_nameAccess().getNameKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,22,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getOption_nameAccess().getEqualsSignKeyword_1());
              		
            }
            // InternalDomainModel.g:385:3: ( (lv_id_name_2_0= RULE_ID ) )
            // InternalDomainModel.g:386:4: (lv_id_name_2_0= RULE_ID )
            {
            // InternalDomainModel.g:386:4: (lv_id_name_2_0= RULE_ID )
            // InternalDomainModel.g:387:5: lv_id_name_2_0= RULE_ID
            {
            lv_id_name_2_0=(Token)match(input,RULE_ID,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_id_name_2_0, grammarAccess.getOption_nameAccess().getId_nameIDTerminalRuleCall_2_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getOption_nameRule());
              					}
              					setWithLastConsumed(
              						current,
              						"id_name",
              						lv_id_name_2_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleoption_name"


    // $ANTLR start "entryRuleoption_condition"
    // InternalDomainModel.g:407:1: entryRuleoption_condition returns [EObject current=null] : iv_ruleoption_condition= ruleoption_condition EOF ;
    public final EObject entryRuleoption_condition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleoption_condition = null;


        try {
            // InternalDomainModel.g:407:57: (iv_ruleoption_condition= ruleoption_condition EOF )
            // InternalDomainModel.g:408:2: iv_ruleoption_condition= ruleoption_condition EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getOption_conditionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleoption_condition=ruleoption_condition();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleoption_condition; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleoption_condition"


    // $ANTLR start "ruleoption_condition"
    // InternalDomainModel.g:414:1: ruleoption_condition returns [EObject current=null] : (otherlv_0= 'condition' otherlv_1= '=' ( (lv_id_condexpr_2_0= RULE_STRING ) ) ) ;
    public final EObject ruleoption_condition() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_id_condexpr_2_0=null;


        	enterRule();

        try {
            // InternalDomainModel.g:420:2: ( (otherlv_0= 'condition' otherlv_1= '=' ( (lv_id_condexpr_2_0= RULE_STRING ) ) ) )
            // InternalDomainModel.g:421:2: (otherlv_0= 'condition' otherlv_1= '=' ( (lv_id_condexpr_2_0= RULE_STRING ) ) )
            {
            // InternalDomainModel.g:421:2: (otherlv_0= 'condition' otherlv_1= '=' ( (lv_id_condexpr_2_0= RULE_STRING ) ) )
            // InternalDomainModel.g:422:3: otherlv_0= 'condition' otherlv_1= '=' ( (lv_id_condexpr_2_0= RULE_STRING ) )
            {
            otherlv_0=(Token)match(input,23,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getOption_conditionAccess().getConditionKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,22,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getOption_conditionAccess().getEqualsSignKeyword_1());
              		
            }
            // InternalDomainModel.g:430:3: ( (lv_id_condexpr_2_0= RULE_STRING ) )
            // InternalDomainModel.g:431:4: (lv_id_condexpr_2_0= RULE_STRING )
            {
            // InternalDomainModel.g:431:4: (lv_id_condexpr_2_0= RULE_STRING )
            // InternalDomainModel.g:432:5: lv_id_condexpr_2_0= RULE_STRING
            {
            lv_id_condexpr_2_0=(Token)match(input,RULE_STRING,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_id_condexpr_2_0, grammarAccess.getOption_conditionAccess().getId_condexprSTRINGTerminalRuleCall_2_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getOption_conditionRule());
              					}
              					setWithLastConsumed(
              						current,
              						"id_condexpr",
              						lv_id_condexpr_2_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleoption_condition"


    // $ANTLR start "entryRuleoption_format"
    // InternalDomainModel.g:452:1: entryRuleoption_format returns [EObject current=null] : iv_ruleoption_format= ruleoption_format EOF ;
    public final EObject entryRuleoption_format() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleoption_format = null;


        try {
            // InternalDomainModel.g:452:54: (iv_ruleoption_format= ruleoption_format EOF )
            // InternalDomainModel.g:453:2: iv_ruleoption_format= ruleoption_format EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getOption_formatRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleoption_format=ruleoption_format();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleoption_format; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleoption_format"


    // $ANTLR start "ruleoption_format"
    // InternalDomainModel.g:459:1: ruleoption_format returns [EObject current=null] : (otherlv_0= 'format' otherlv_1= '=' ( (lv_id_arith_2_0= RULE_INT ) ) ) ;
    public final EObject ruleoption_format() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_id_arith_2_0=null;


        	enterRule();

        try {
            // InternalDomainModel.g:465:2: ( (otherlv_0= 'format' otherlv_1= '=' ( (lv_id_arith_2_0= RULE_INT ) ) ) )
            // InternalDomainModel.g:466:2: (otherlv_0= 'format' otherlv_1= '=' ( (lv_id_arith_2_0= RULE_INT ) ) )
            {
            // InternalDomainModel.g:466:2: (otherlv_0= 'format' otherlv_1= '=' ( (lv_id_arith_2_0= RULE_INT ) ) )
            // InternalDomainModel.g:467:3: otherlv_0= 'format' otherlv_1= '=' ( (lv_id_arith_2_0= RULE_INT ) )
            {
            otherlv_0=(Token)match(input,24,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getOption_formatAccess().getFormatKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,22,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getOption_formatAccess().getEqualsSignKeyword_1());
              		
            }
            // InternalDomainModel.g:475:3: ( (lv_id_arith_2_0= RULE_INT ) )
            // InternalDomainModel.g:476:4: (lv_id_arith_2_0= RULE_INT )
            {
            // InternalDomainModel.g:476:4: (lv_id_arith_2_0= RULE_INT )
            // InternalDomainModel.g:477:5: lv_id_arith_2_0= RULE_INT
            {
            lv_id_arith_2_0=(Token)match(input,RULE_INT,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_id_arith_2_0, grammarAccess.getOption_formatAccess().getId_arithINTTerminalRuleCall_2_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getOption_formatRule());
              					}
              					setWithLastConsumed(
              						current,
              						"id_arith",
              						lv_id_arith_2_0,
              						"org.eclipse.xtext.common.Terminals.INT");
              				
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleoption_format"


    // $ANTLR start "entryRuleoption_format_1"
    // InternalDomainModel.g:497:1: entryRuleoption_format_1 returns [EObject current=null] : iv_ruleoption_format_1= ruleoption_format_1 EOF ;
    public final EObject entryRuleoption_format_1() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleoption_format_1 = null;


        try {
            // InternalDomainModel.g:497:56: (iv_ruleoption_format_1= ruleoption_format_1 EOF )
            // InternalDomainModel.g:498:2: iv_ruleoption_format_1= ruleoption_format_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getOption_format_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleoption_format_1=ruleoption_format_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleoption_format_1; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleoption_format_1"


    // $ANTLR start "ruleoption_format_1"
    // InternalDomainModel.g:504:1: ruleoption_format_1 returns [EObject current=null] : (otherlv_0= 'format' otherlv_1= '=' ( (lv_id_string_2_0= RULE_STRING ) ) ) ;
    public final EObject ruleoption_format_1() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_id_string_2_0=null;


        	enterRule();

        try {
            // InternalDomainModel.g:510:2: ( (otherlv_0= 'format' otherlv_1= '=' ( (lv_id_string_2_0= RULE_STRING ) ) ) )
            // InternalDomainModel.g:511:2: (otherlv_0= 'format' otherlv_1= '=' ( (lv_id_string_2_0= RULE_STRING ) ) )
            {
            // InternalDomainModel.g:511:2: (otherlv_0= 'format' otherlv_1= '=' ( (lv_id_string_2_0= RULE_STRING ) ) )
            // InternalDomainModel.g:512:3: otherlv_0= 'format' otherlv_1= '=' ( (lv_id_string_2_0= RULE_STRING ) )
            {
            otherlv_0=(Token)match(input,24,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getOption_format_1Access().getFormatKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,22,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getOption_format_1Access().getEqualsSignKeyword_1());
              		
            }
            // InternalDomainModel.g:520:3: ( (lv_id_string_2_0= RULE_STRING ) )
            // InternalDomainModel.g:521:4: (lv_id_string_2_0= RULE_STRING )
            {
            // InternalDomainModel.g:521:4: (lv_id_string_2_0= RULE_STRING )
            // InternalDomainModel.g:522:5: lv_id_string_2_0= RULE_STRING
            {
            lv_id_string_2_0=(Token)match(input,RULE_STRING,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_id_string_2_0, grammarAccess.getOption_format_1Access().getId_stringSTRINGTerminalRuleCall_2_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getOption_format_1Rule());
              					}
              					setWithLastConsumed(
              						current,
              						"id_string",
              						lv_id_string_2_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleoption_format_1"


    // $ANTLR start "entryRuleoption_length_type"
    // InternalDomainModel.g:542:1: entryRuleoption_length_type returns [EObject current=null] : iv_ruleoption_length_type= ruleoption_length_type EOF ;
    public final EObject entryRuleoption_length_type() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleoption_length_type = null;


        try {
            // InternalDomainModel.g:542:59: (iv_ruleoption_length_type= ruleoption_length_type EOF )
            // InternalDomainModel.g:543:2: iv_ruleoption_length_type= ruleoption_length_type EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getOption_length_typeRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleoption_length_type=ruleoption_length_type();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleoption_length_type; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleoption_length_type"


    // $ANTLR start "ruleoption_length_type"
    // InternalDomainModel.g:549:1: ruleoption_length_type returns [EObject current=null] : (otherlv_0= 'length_type' otherlv_1= '=' ( (lv_id_string_2_0= RULE_STRING ) ) ) ;
    public final EObject ruleoption_length_type() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_id_string_2_0=null;


        	enterRule();

        try {
            // InternalDomainModel.g:555:2: ( (otherlv_0= 'length_type' otherlv_1= '=' ( (lv_id_string_2_0= RULE_STRING ) ) ) )
            // InternalDomainModel.g:556:2: (otherlv_0= 'length_type' otherlv_1= '=' ( (lv_id_string_2_0= RULE_STRING ) ) )
            {
            // InternalDomainModel.g:556:2: (otherlv_0= 'length_type' otherlv_1= '=' ( (lv_id_string_2_0= RULE_STRING ) ) )
            // InternalDomainModel.g:557:3: otherlv_0= 'length_type' otherlv_1= '=' ( (lv_id_string_2_0= RULE_STRING ) )
            {
            otherlv_0=(Token)match(input,25,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getOption_length_typeAccess().getLength_typeKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,22,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getOption_length_typeAccess().getEqualsSignKeyword_1());
              		
            }
            // InternalDomainModel.g:565:3: ( (lv_id_string_2_0= RULE_STRING ) )
            // InternalDomainModel.g:566:4: (lv_id_string_2_0= RULE_STRING )
            {
            // InternalDomainModel.g:566:4: (lv_id_string_2_0= RULE_STRING )
            // InternalDomainModel.g:567:5: lv_id_string_2_0= RULE_STRING
            {
            lv_id_string_2_0=(Token)match(input,RULE_STRING,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_id_string_2_0, grammarAccess.getOption_length_typeAccess().getId_stringSTRINGTerminalRuleCall_2_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getOption_length_typeRule());
              					}
              					setWithLastConsumed(
              						current,
              						"id_string",
              						lv_id_string_2_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleoption_length_type"


    // $ANTLR start "entryRuleoption_min_length"
    // InternalDomainModel.g:587:1: entryRuleoption_min_length returns [EObject current=null] : iv_ruleoption_min_length= ruleoption_min_length EOF ;
    public final EObject entryRuleoption_min_length() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleoption_min_length = null;


        try {
            // InternalDomainModel.g:587:58: (iv_ruleoption_min_length= ruleoption_min_length EOF )
            // InternalDomainModel.g:588:2: iv_ruleoption_min_length= ruleoption_min_length EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getOption_min_lengthRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleoption_min_length=ruleoption_min_length();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleoption_min_length; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleoption_min_length"


    // $ANTLR start "ruleoption_min_length"
    // InternalDomainModel.g:594:1: ruleoption_min_length returns [EObject current=null] : (otherlv_0= 'min_length' otherlv_1= '=' ( (lv_id_int_2_0= RULE_INT ) ) ) ;
    public final EObject ruleoption_min_length() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_id_int_2_0=null;


        	enterRule();

        try {
            // InternalDomainModel.g:600:2: ( (otherlv_0= 'min_length' otherlv_1= '=' ( (lv_id_int_2_0= RULE_INT ) ) ) )
            // InternalDomainModel.g:601:2: (otherlv_0= 'min_length' otherlv_1= '=' ( (lv_id_int_2_0= RULE_INT ) ) )
            {
            // InternalDomainModel.g:601:2: (otherlv_0= 'min_length' otherlv_1= '=' ( (lv_id_int_2_0= RULE_INT ) ) )
            // InternalDomainModel.g:602:3: otherlv_0= 'min_length' otherlv_1= '=' ( (lv_id_int_2_0= RULE_INT ) )
            {
            otherlv_0=(Token)match(input,26,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getOption_min_lengthAccess().getMin_lengthKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,22,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getOption_min_lengthAccess().getEqualsSignKeyword_1());
              		
            }
            // InternalDomainModel.g:610:3: ( (lv_id_int_2_0= RULE_INT ) )
            // InternalDomainModel.g:611:4: (lv_id_int_2_0= RULE_INT )
            {
            // InternalDomainModel.g:611:4: (lv_id_int_2_0= RULE_INT )
            // InternalDomainModel.g:612:5: lv_id_int_2_0= RULE_INT
            {
            lv_id_int_2_0=(Token)match(input,RULE_INT,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_id_int_2_0, grammarAccess.getOption_min_lengthAccess().getId_intINTTerminalRuleCall_2_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getOption_min_lengthRule());
              					}
              					setWithLastConsumed(
              						current,
              						"id_int",
              						lv_id_int_2_0,
              						"org.eclipse.xtext.common.Terminals.INT");
              				
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleoption_min_length"


    // $ANTLR start "entryRuleoption_max_length"
    // InternalDomainModel.g:632:1: entryRuleoption_max_length returns [EObject current=null] : iv_ruleoption_max_length= ruleoption_max_length EOF ;
    public final EObject entryRuleoption_max_length() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleoption_max_length = null;


        try {
            // InternalDomainModel.g:632:58: (iv_ruleoption_max_length= ruleoption_max_length EOF )
            // InternalDomainModel.g:633:2: iv_ruleoption_max_length= ruleoption_max_length EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getOption_max_lengthRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleoption_max_length=ruleoption_max_length();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleoption_max_length; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleoption_max_length"


    // $ANTLR start "ruleoption_max_length"
    // InternalDomainModel.g:639:1: ruleoption_max_length returns [EObject current=null] : (otherlv_0= 'max_length' otherlv_1= '=' ( (lv_id_int_2_0= RULE_INT ) ) ) ;
    public final EObject ruleoption_max_length() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_id_int_2_0=null;


        	enterRule();

        try {
            // InternalDomainModel.g:645:2: ( (otherlv_0= 'max_length' otherlv_1= '=' ( (lv_id_int_2_0= RULE_INT ) ) ) )
            // InternalDomainModel.g:646:2: (otherlv_0= 'max_length' otherlv_1= '=' ( (lv_id_int_2_0= RULE_INT ) ) )
            {
            // InternalDomainModel.g:646:2: (otherlv_0= 'max_length' otherlv_1= '=' ( (lv_id_int_2_0= RULE_INT ) ) )
            // InternalDomainModel.g:647:3: otherlv_0= 'max_length' otherlv_1= '=' ( (lv_id_int_2_0= RULE_INT ) )
            {
            otherlv_0=(Token)match(input,27,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getOption_max_lengthAccess().getMax_lengthKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,22,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getOption_max_lengthAccess().getEqualsSignKeyword_1());
              		
            }
            // InternalDomainModel.g:655:3: ( (lv_id_int_2_0= RULE_INT ) )
            // InternalDomainModel.g:656:4: (lv_id_int_2_0= RULE_INT )
            {
            // InternalDomainModel.g:656:4: (lv_id_int_2_0= RULE_INT )
            // InternalDomainModel.g:657:5: lv_id_int_2_0= RULE_INT
            {
            lv_id_int_2_0=(Token)match(input,RULE_INT,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_id_int_2_0, grammarAccess.getOption_max_lengthAccess().getId_intINTTerminalRuleCall_2_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getOption_max_lengthRule());
              					}
              					setWithLastConsumed(
              						current,
              						"id_int",
              						lv_id_int_2_0,
              						"org.eclipse.xtext.common.Terminals.INT");
              				
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleoption_max_length"


    // $ANTLR start "entryRuleoption_content_type"
    // InternalDomainModel.g:677:1: entryRuleoption_content_type returns [EObject current=null] : iv_ruleoption_content_type= ruleoption_content_type EOF ;
    public final EObject entryRuleoption_content_type() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleoption_content_type = null;


        try {
            // InternalDomainModel.g:677:60: (iv_ruleoption_content_type= ruleoption_content_type EOF )
            // InternalDomainModel.g:678:2: iv_ruleoption_content_type= ruleoption_content_type EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getOption_content_typeRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleoption_content_type=ruleoption_content_type();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleoption_content_type; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleoption_content_type"


    // $ANTLR start "ruleoption_content_type"
    // InternalDomainModel.g:684:1: ruleoption_content_type returns [EObject current=null] : (otherlv_0= 'content_type' otherlv_1= '=' ( (lv_id_string_2_0= RULE_STRING ) ) ) ;
    public final EObject ruleoption_content_type() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_id_string_2_0=null;


        	enterRule();

        try {
            // InternalDomainModel.g:690:2: ( (otherlv_0= 'content_type' otherlv_1= '=' ( (lv_id_string_2_0= RULE_STRING ) ) ) )
            // InternalDomainModel.g:691:2: (otherlv_0= 'content_type' otherlv_1= '=' ( (lv_id_string_2_0= RULE_STRING ) ) )
            {
            // InternalDomainModel.g:691:2: (otherlv_0= 'content_type' otherlv_1= '=' ( (lv_id_string_2_0= RULE_STRING ) ) )
            // InternalDomainModel.g:692:3: otherlv_0= 'content_type' otherlv_1= '=' ( (lv_id_string_2_0= RULE_STRING ) )
            {
            otherlv_0=(Token)match(input,28,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getOption_content_typeAccess().getContent_typeKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,22,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getOption_content_typeAccess().getEqualsSignKeyword_1());
              		
            }
            // InternalDomainModel.g:700:3: ( (lv_id_string_2_0= RULE_STRING ) )
            // InternalDomainModel.g:701:4: (lv_id_string_2_0= RULE_STRING )
            {
            // InternalDomainModel.g:701:4: (lv_id_string_2_0= RULE_STRING )
            // InternalDomainModel.g:702:5: lv_id_string_2_0= RULE_STRING
            {
            lv_id_string_2_0=(Token)match(input,RULE_STRING,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_id_string_2_0, grammarAccess.getOption_content_typeAccess().getId_stringSTRINGTerminalRuleCall_2_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getOption_content_typeRule());
              					}
              					setWithLastConsumed(
              						current,
              						"id_string",
              						lv_id_string_2_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleoption_content_type"


    // $ANTLR start "entryRuleoption_word_set"
    // InternalDomainModel.g:722:1: entryRuleoption_word_set returns [EObject current=null] : iv_ruleoption_word_set= ruleoption_word_set EOF ;
    public final EObject entryRuleoption_word_set() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleoption_word_set = null;


        try {
            // InternalDomainModel.g:722:56: (iv_ruleoption_word_set= ruleoption_word_set EOF )
            // InternalDomainModel.g:723:2: iv_ruleoption_word_set= ruleoption_word_set EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getOption_word_setRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleoption_word_set=ruleoption_word_set();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleoption_word_set; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleoption_word_set"


    // $ANTLR start "ruleoption_word_set"
    // InternalDomainModel.g:729:1: ruleoption_word_set returns [EObject current=null] : (otherlv_0= 'word_set' otherlv_1= '=' (otherlv_2= '[' ( (lv_first_string_3_0= RULE_STRING ) ) (otherlv_4= ',' ( (lv_last_strings_5_0= RULE_STRING ) ) )* otherlv_6= ']' ) ) ;
    public final EObject ruleoption_word_set() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_first_string_3_0=null;
        Token otherlv_4=null;
        Token lv_last_strings_5_0=null;
        Token otherlv_6=null;


        	enterRule();

        try {
            // InternalDomainModel.g:735:2: ( (otherlv_0= 'word_set' otherlv_1= '=' (otherlv_2= '[' ( (lv_first_string_3_0= RULE_STRING ) ) (otherlv_4= ',' ( (lv_last_strings_5_0= RULE_STRING ) ) )* otherlv_6= ']' ) ) )
            // InternalDomainModel.g:736:2: (otherlv_0= 'word_set' otherlv_1= '=' (otherlv_2= '[' ( (lv_first_string_3_0= RULE_STRING ) ) (otherlv_4= ',' ( (lv_last_strings_5_0= RULE_STRING ) ) )* otherlv_6= ']' ) )
            {
            // InternalDomainModel.g:736:2: (otherlv_0= 'word_set' otherlv_1= '=' (otherlv_2= '[' ( (lv_first_string_3_0= RULE_STRING ) ) (otherlv_4= ',' ( (lv_last_strings_5_0= RULE_STRING ) ) )* otherlv_6= ']' ) )
            // InternalDomainModel.g:737:3: otherlv_0= 'word_set' otherlv_1= '=' (otherlv_2= '[' ( (lv_first_string_3_0= RULE_STRING ) ) (otherlv_4= ',' ( (lv_last_strings_5_0= RULE_STRING ) ) )* otherlv_6= ']' )
            {
            otherlv_0=(Token)match(input,29,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getOption_word_setAccess().getWord_setKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,22,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getOption_word_setAccess().getEqualsSignKeyword_1());
              		
            }
            // InternalDomainModel.g:745:3: (otherlv_2= '[' ( (lv_first_string_3_0= RULE_STRING ) ) (otherlv_4= ',' ( (lv_last_strings_5_0= RULE_STRING ) ) )* otherlv_6= ']' )
            // InternalDomainModel.g:746:4: otherlv_2= '[' ( (lv_first_string_3_0= RULE_STRING ) ) (otherlv_4= ',' ( (lv_last_strings_5_0= RULE_STRING ) ) )* otherlv_6= ']'
            {
            otherlv_2=(Token)match(input,30,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(otherlv_2, grammarAccess.getOption_word_setAccess().getLeftSquareBracketKeyword_2_0());
              			
            }
            // InternalDomainModel.g:750:4: ( (lv_first_string_3_0= RULE_STRING ) )
            // InternalDomainModel.g:751:5: (lv_first_string_3_0= RULE_STRING )
            {
            // InternalDomainModel.g:751:5: (lv_first_string_3_0= RULE_STRING )
            // InternalDomainModel.g:752:6: lv_first_string_3_0= RULE_STRING
            {
            lv_first_string_3_0=(Token)match(input,RULE_STRING,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              						newLeafNode(lv_first_string_3_0, grammarAccess.getOption_word_setAccess().getFirst_stringSTRINGTerminalRuleCall_2_1_0());
              					
            }
            if ( state.backtracking==0 ) {

              						if (current==null) {
              							current = createModelElement(grammarAccess.getOption_word_setRule());
              						}
              						setWithLastConsumed(
              							current,
              							"first_string",
              							lv_first_string_3_0,
              							"org.eclipse.xtext.common.Terminals.STRING");
              					
            }

            }


            }

            // InternalDomainModel.g:768:4: (otherlv_4= ',' ( (lv_last_strings_5_0= RULE_STRING ) ) )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==31) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalDomainModel.g:769:5: otherlv_4= ',' ( (lv_last_strings_5_0= RULE_STRING ) )
            	    {
            	    otherlv_4=(Token)match(input,31,FOLLOW_13); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					newLeafNode(otherlv_4, grammarAccess.getOption_word_setAccess().getCommaKeyword_2_2_0());
            	      				
            	    }
            	    // InternalDomainModel.g:773:5: ( (lv_last_strings_5_0= RULE_STRING ) )
            	    // InternalDomainModel.g:774:6: (lv_last_strings_5_0= RULE_STRING )
            	    {
            	    // InternalDomainModel.g:774:6: (lv_last_strings_5_0= RULE_STRING )
            	    // InternalDomainModel.g:775:7: lv_last_strings_5_0= RULE_STRING
            	    {
            	    lv_last_strings_5_0=(Token)match(input,RULE_STRING,FOLLOW_15); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      							newLeafNode(lv_last_strings_5_0, grammarAccess.getOption_word_setAccess().getLast_stringsSTRINGTerminalRuleCall_2_2_1_0());
            	      						
            	    }
            	    if ( state.backtracking==0 ) {

            	      							if (current==null) {
            	      								current = createModelElement(grammarAccess.getOption_word_setRule());
            	      							}
            	      							addWithLastConsumed(
            	      								current,
            	      								"last_strings",
            	      								lv_last_strings_5_0,
            	      								"org.eclipse.xtext.common.Terminals.STRING");
            	      						
            	    }

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

            otherlv_6=(Token)match(input,32,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(otherlv_6, grammarAccess.getOption_word_setAccess().getRightSquareBracketKeyword_2_3());
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleoption_word_set"


    // $ANTLR start "entryRuleparametersInteger"
    // InternalDomainModel.g:801:1: entryRuleparametersInteger returns [EObject current=null] : iv_ruleparametersInteger= ruleparametersInteger EOF ;
    public final EObject entryRuleparametersInteger() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleparametersInteger = null;


        try {
            // InternalDomainModel.g:801:58: (iv_ruleparametersInteger= ruleparametersInteger EOF )
            // InternalDomainModel.g:802:2: iv_ruleparametersInteger= ruleparametersInteger EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getParametersIntegerRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleparametersInteger=ruleparametersInteger();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleparametersInteger; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleparametersInteger"


    // $ANTLR start "ruleparametersInteger"
    // InternalDomainModel.g:808:1: ruleparametersInteger returns [EObject current=null] : ( ( (lv_int1_0_0= RULE_INT ) ) otherlv_1= ',' ( (lv_int2_2_0= RULE_INT ) ) (otherlv_3= ',' ( (lv_parameters_condition_4_0= ruleoption_condition ) ) )? (otherlv_5= ',' ( (lv_parameters_name_6_0= ruleoption_name ) ) )? ) ;
    public final EObject ruleparametersInteger() throws RecognitionException {
        EObject current = null;

        Token lv_int1_0_0=null;
        Token otherlv_1=null;
        Token lv_int2_2_0=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject lv_parameters_condition_4_0 = null;

        EObject lv_parameters_name_6_0 = null;



        	enterRule();

        try {
            // InternalDomainModel.g:814:2: ( ( ( (lv_int1_0_0= RULE_INT ) ) otherlv_1= ',' ( (lv_int2_2_0= RULE_INT ) ) (otherlv_3= ',' ( (lv_parameters_condition_4_0= ruleoption_condition ) ) )? (otherlv_5= ',' ( (lv_parameters_name_6_0= ruleoption_name ) ) )? ) )
            // InternalDomainModel.g:815:2: ( ( (lv_int1_0_0= RULE_INT ) ) otherlv_1= ',' ( (lv_int2_2_0= RULE_INT ) ) (otherlv_3= ',' ( (lv_parameters_condition_4_0= ruleoption_condition ) ) )? (otherlv_5= ',' ( (lv_parameters_name_6_0= ruleoption_name ) ) )? )
            {
            // InternalDomainModel.g:815:2: ( ( (lv_int1_0_0= RULE_INT ) ) otherlv_1= ',' ( (lv_int2_2_0= RULE_INT ) ) (otherlv_3= ',' ( (lv_parameters_condition_4_0= ruleoption_condition ) ) )? (otherlv_5= ',' ( (lv_parameters_name_6_0= ruleoption_name ) ) )? )
            // InternalDomainModel.g:816:3: ( (lv_int1_0_0= RULE_INT ) ) otherlv_1= ',' ( (lv_int2_2_0= RULE_INT ) ) (otherlv_3= ',' ( (lv_parameters_condition_4_0= ruleoption_condition ) ) )? (otherlv_5= ',' ( (lv_parameters_name_6_0= ruleoption_name ) ) )?
            {
            // InternalDomainModel.g:816:3: ( (lv_int1_0_0= RULE_INT ) )
            // InternalDomainModel.g:817:4: (lv_int1_0_0= RULE_INT )
            {
            // InternalDomainModel.g:817:4: (lv_int1_0_0= RULE_INT )
            // InternalDomainModel.g:818:5: lv_int1_0_0= RULE_INT
            {
            lv_int1_0_0=(Token)match(input,RULE_INT,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_int1_0_0, grammarAccess.getParametersIntegerAccess().getInt1INTTerminalRuleCall_0_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getParametersIntegerRule());
              					}
              					setWithLastConsumed(
              						current,
              						"int1",
              						lv_int1_0_0,
              						"org.eclipse.xtext.common.Terminals.INT");
              				
            }

            }


            }

            otherlv_1=(Token)match(input,31,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getParametersIntegerAccess().getCommaKeyword_1());
              		
            }
            // InternalDomainModel.g:838:3: ( (lv_int2_2_0= RULE_INT ) )
            // InternalDomainModel.g:839:4: (lv_int2_2_0= RULE_INT )
            {
            // InternalDomainModel.g:839:4: (lv_int2_2_0= RULE_INT )
            // InternalDomainModel.g:840:5: lv_int2_2_0= RULE_INT
            {
            lv_int2_2_0=(Token)match(input,RULE_INT,FOLLOW_17); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_int2_2_0, grammarAccess.getParametersIntegerAccess().getInt2INTTerminalRuleCall_2_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getParametersIntegerRule());
              					}
              					setWithLastConsumed(
              						current,
              						"int2",
              						lv_int2_2_0,
              						"org.eclipse.xtext.common.Terminals.INT");
              				
            }

            }


            }

            // InternalDomainModel.g:856:3: (otherlv_3= ',' ( (lv_parameters_condition_4_0= ruleoption_condition ) ) )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==31) ) {
                int LA5_1 = input.LA(2);

                if ( (LA5_1==23) ) {
                    alt5=1;
                }
            }
            switch (alt5) {
                case 1 :
                    // InternalDomainModel.g:857:4: otherlv_3= ',' ( (lv_parameters_condition_4_0= ruleoption_condition ) )
                    {
                    otherlv_3=(Token)match(input,31,FOLLOW_8); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_3, grammarAccess.getParametersIntegerAccess().getCommaKeyword_3_0());
                      			
                    }
                    // InternalDomainModel.g:861:4: ( (lv_parameters_condition_4_0= ruleoption_condition ) )
                    // InternalDomainModel.g:862:5: (lv_parameters_condition_4_0= ruleoption_condition )
                    {
                    // InternalDomainModel.g:862:5: (lv_parameters_condition_4_0= ruleoption_condition )
                    // InternalDomainModel.g:863:6: lv_parameters_condition_4_0= ruleoption_condition
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getParametersIntegerAccess().getParameters_conditionOption_conditionParserRuleCall_3_1_0());
                      					
                    }
                    pushFollow(FOLLOW_17);
                    lv_parameters_condition_4_0=ruleoption_condition();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getParametersIntegerRule());
                      						}
                      						set(
                      							current,
                      							"parameters_condition",
                      							lv_parameters_condition_4_0,
                      							"org.xtext.example.mydsl.DomainModel.option_condition");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            // InternalDomainModel.g:881:3: (otherlv_5= ',' ( (lv_parameters_name_6_0= ruleoption_name ) ) )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==31) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalDomainModel.g:882:4: otherlv_5= ',' ( (lv_parameters_name_6_0= ruleoption_name ) )
                    {
                    otherlv_5=(Token)match(input,31,FOLLOW_18); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_5, grammarAccess.getParametersIntegerAccess().getCommaKeyword_4_0());
                      			
                    }
                    // InternalDomainModel.g:886:4: ( (lv_parameters_name_6_0= ruleoption_name ) )
                    // InternalDomainModel.g:887:5: (lv_parameters_name_6_0= ruleoption_name )
                    {
                    // InternalDomainModel.g:887:5: (lv_parameters_name_6_0= ruleoption_name )
                    // InternalDomainModel.g:888:6: lv_parameters_name_6_0= ruleoption_name
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getParametersIntegerAccess().getParameters_nameOption_nameParserRuleCall_4_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_parameters_name_6_0=ruleoption_name();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getParametersIntegerRule());
                      						}
                      						set(
                      							current,
                      							"parameters_name",
                      							lv_parameters_name_6_0,
                      							"org.xtext.example.mydsl.DomainModel.option_name");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleparametersInteger"


    // $ANTLR start "entryRuleparametersFloat"
    // InternalDomainModel.g:910:1: entryRuleparametersFloat returns [EObject current=null] : iv_ruleparametersFloat= ruleparametersFloat EOF ;
    public final EObject entryRuleparametersFloat() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleparametersFloat = null;


        try {
            // InternalDomainModel.g:910:56: (iv_ruleparametersFloat= ruleparametersFloat EOF )
            // InternalDomainModel.g:911:2: iv_ruleparametersFloat= ruleparametersFloat EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getParametersFloatRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleparametersFloat=ruleparametersFloat();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleparametersFloat; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleparametersFloat"


    // $ANTLR start "ruleparametersFloat"
    // InternalDomainModel.g:917:1: ruleparametersFloat returns [EObject current=null] : ( ( (lv_float1_0_0= RULE_DOUBLE ) ) otherlv_1= ',' ( (lv_float2_2_0= RULE_DOUBLE ) ) (otherlv_3= ',' ( (lv_parameters_condition_4_0= ruleoption_condition ) ) )? (otherlv_5= ',' ( (lv_parameters_format_6_0= ruleoption_format ) ) )? (otherlv_7= ',' ( (lv_parameters_name_8_0= ruleoption_name ) ) )? ) ;
    public final EObject ruleparametersFloat() throws RecognitionException {
        EObject current = null;

        Token lv_float1_0_0=null;
        Token otherlv_1=null;
        Token lv_float2_2_0=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        EObject lv_parameters_condition_4_0 = null;

        EObject lv_parameters_format_6_0 = null;

        EObject lv_parameters_name_8_0 = null;



        	enterRule();

        try {
            // InternalDomainModel.g:923:2: ( ( ( (lv_float1_0_0= RULE_DOUBLE ) ) otherlv_1= ',' ( (lv_float2_2_0= RULE_DOUBLE ) ) (otherlv_3= ',' ( (lv_parameters_condition_4_0= ruleoption_condition ) ) )? (otherlv_5= ',' ( (lv_parameters_format_6_0= ruleoption_format ) ) )? (otherlv_7= ',' ( (lv_parameters_name_8_0= ruleoption_name ) ) )? ) )
            // InternalDomainModel.g:924:2: ( ( (lv_float1_0_0= RULE_DOUBLE ) ) otherlv_1= ',' ( (lv_float2_2_0= RULE_DOUBLE ) ) (otherlv_3= ',' ( (lv_parameters_condition_4_0= ruleoption_condition ) ) )? (otherlv_5= ',' ( (lv_parameters_format_6_0= ruleoption_format ) ) )? (otherlv_7= ',' ( (lv_parameters_name_8_0= ruleoption_name ) ) )? )
            {
            // InternalDomainModel.g:924:2: ( ( (lv_float1_0_0= RULE_DOUBLE ) ) otherlv_1= ',' ( (lv_float2_2_0= RULE_DOUBLE ) ) (otherlv_3= ',' ( (lv_parameters_condition_4_0= ruleoption_condition ) ) )? (otherlv_5= ',' ( (lv_parameters_format_6_0= ruleoption_format ) ) )? (otherlv_7= ',' ( (lv_parameters_name_8_0= ruleoption_name ) ) )? )
            // InternalDomainModel.g:925:3: ( (lv_float1_0_0= RULE_DOUBLE ) ) otherlv_1= ',' ( (lv_float2_2_0= RULE_DOUBLE ) ) (otherlv_3= ',' ( (lv_parameters_condition_4_0= ruleoption_condition ) ) )? (otherlv_5= ',' ( (lv_parameters_format_6_0= ruleoption_format ) ) )? (otherlv_7= ',' ( (lv_parameters_name_8_0= ruleoption_name ) ) )?
            {
            // InternalDomainModel.g:925:3: ( (lv_float1_0_0= RULE_DOUBLE ) )
            // InternalDomainModel.g:926:4: (lv_float1_0_0= RULE_DOUBLE )
            {
            // InternalDomainModel.g:926:4: (lv_float1_0_0= RULE_DOUBLE )
            // InternalDomainModel.g:927:5: lv_float1_0_0= RULE_DOUBLE
            {
            lv_float1_0_0=(Token)match(input,RULE_DOUBLE,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_float1_0_0, grammarAccess.getParametersFloatAccess().getFloat1DOUBLETerminalRuleCall_0_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getParametersFloatRule());
              					}
              					setWithLastConsumed(
              						current,
              						"float1",
              						lv_float1_0_0,
              						"org.xtext.example.mydsl.DomainModel.DOUBLE");
              				
            }

            }


            }

            otherlv_1=(Token)match(input,31,FOLLOW_7); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getParametersFloatAccess().getCommaKeyword_1());
              		
            }
            // InternalDomainModel.g:947:3: ( (lv_float2_2_0= RULE_DOUBLE ) )
            // InternalDomainModel.g:948:4: (lv_float2_2_0= RULE_DOUBLE )
            {
            // InternalDomainModel.g:948:4: (lv_float2_2_0= RULE_DOUBLE )
            // InternalDomainModel.g:949:5: lv_float2_2_0= RULE_DOUBLE
            {
            lv_float2_2_0=(Token)match(input,RULE_DOUBLE,FOLLOW_17); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_float2_2_0, grammarAccess.getParametersFloatAccess().getFloat2DOUBLETerminalRuleCall_2_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getParametersFloatRule());
              					}
              					setWithLastConsumed(
              						current,
              						"float2",
              						lv_float2_2_0,
              						"org.xtext.example.mydsl.DomainModel.DOUBLE");
              				
            }

            }


            }

            // InternalDomainModel.g:965:3: (otherlv_3= ',' ( (lv_parameters_condition_4_0= ruleoption_condition ) ) )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==31) ) {
                int LA7_1 = input.LA(2);

                if ( (LA7_1==23) ) {
                    alt7=1;
                }
            }
            switch (alt7) {
                case 1 :
                    // InternalDomainModel.g:966:4: otherlv_3= ',' ( (lv_parameters_condition_4_0= ruleoption_condition ) )
                    {
                    otherlv_3=(Token)match(input,31,FOLLOW_8); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_3, grammarAccess.getParametersFloatAccess().getCommaKeyword_3_0());
                      			
                    }
                    // InternalDomainModel.g:970:4: ( (lv_parameters_condition_4_0= ruleoption_condition ) )
                    // InternalDomainModel.g:971:5: (lv_parameters_condition_4_0= ruleoption_condition )
                    {
                    // InternalDomainModel.g:971:5: (lv_parameters_condition_4_0= ruleoption_condition )
                    // InternalDomainModel.g:972:6: lv_parameters_condition_4_0= ruleoption_condition
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getParametersFloatAccess().getParameters_conditionOption_conditionParserRuleCall_3_1_0());
                      					
                    }
                    pushFollow(FOLLOW_17);
                    lv_parameters_condition_4_0=ruleoption_condition();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getParametersFloatRule());
                      						}
                      						set(
                      							current,
                      							"parameters_condition",
                      							lv_parameters_condition_4_0,
                      							"org.xtext.example.mydsl.DomainModel.option_condition");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            // InternalDomainModel.g:990:3: (otherlv_5= ',' ( (lv_parameters_format_6_0= ruleoption_format ) ) )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==31) ) {
                int LA8_1 = input.LA(2);

                if ( (LA8_1==24) ) {
                    alt8=1;
                }
            }
            switch (alt8) {
                case 1 :
                    // InternalDomainModel.g:991:4: otherlv_5= ',' ( (lv_parameters_format_6_0= ruleoption_format ) )
                    {
                    otherlv_5=(Token)match(input,31,FOLLOW_19); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_5, grammarAccess.getParametersFloatAccess().getCommaKeyword_4_0());
                      			
                    }
                    // InternalDomainModel.g:995:4: ( (lv_parameters_format_6_0= ruleoption_format ) )
                    // InternalDomainModel.g:996:5: (lv_parameters_format_6_0= ruleoption_format )
                    {
                    // InternalDomainModel.g:996:5: (lv_parameters_format_6_0= ruleoption_format )
                    // InternalDomainModel.g:997:6: lv_parameters_format_6_0= ruleoption_format
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getParametersFloatAccess().getParameters_formatOption_formatParserRuleCall_4_1_0());
                      					
                    }
                    pushFollow(FOLLOW_17);
                    lv_parameters_format_6_0=ruleoption_format();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getParametersFloatRule());
                      						}
                      						set(
                      							current,
                      							"parameters_format",
                      							lv_parameters_format_6_0,
                      							"org.xtext.example.mydsl.DomainModel.option_format");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            // InternalDomainModel.g:1015:3: (otherlv_7= ',' ( (lv_parameters_name_8_0= ruleoption_name ) ) )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==31) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalDomainModel.g:1016:4: otherlv_7= ',' ( (lv_parameters_name_8_0= ruleoption_name ) )
                    {
                    otherlv_7=(Token)match(input,31,FOLLOW_18); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_7, grammarAccess.getParametersFloatAccess().getCommaKeyword_5_0());
                      			
                    }
                    // InternalDomainModel.g:1020:4: ( (lv_parameters_name_8_0= ruleoption_name ) )
                    // InternalDomainModel.g:1021:5: (lv_parameters_name_8_0= ruleoption_name )
                    {
                    // InternalDomainModel.g:1021:5: (lv_parameters_name_8_0= ruleoption_name )
                    // InternalDomainModel.g:1022:6: lv_parameters_name_8_0= ruleoption_name
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getParametersFloatAccess().getParameters_nameOption_nameParserRuleCall_5_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_parameters_name_8_0=ruleoption_name();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getParametersFloatRule());
                      						}
                      						set(
                      							current,
                      							"parameters_name",
                      							lv_parameters_name_8_0,
                      							"org.xtext.example.mydsl.DomainModel.option_name");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleparametersFloat"


    // $ANTLR start "entryRuleparametersBoolean"
    // InternalDomainModel.g:1044:1: entryRuleparametersBoolean returns [EObject current=null] : iv_ruleparametersBoolean= ruleparametersBoolean EOF ;
    public final EObject entryRuleparametersBoolean() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleparametersBoolean = null;


        try {
            // InternalDomainModel.g:1044:58: (iv_ruleparametersBoolean= ruleparametersBoolean EOF )
            // InternalDomainModel.g:1045:2: iv_ruleparametersBoolean= ruleparametersBoolean EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getParametersBooleanRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleparametersBoolean=ruleparametersBoolean();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleparametersBoolean; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleparametersBoolean"


    // $ANTLR start "ruleparametersBoolean"
    // InternalDomainModel.g:1051:1: ruleparametersBoolean returns [EObject current=null] : ( (lv_parameters_format_0_0= ruleoption_format_1 ) )? ;
    public final EObject ruleparametersBoolean() throws RecognitionException {
        EObject current = null;

        EObject lv_parameters_format_0_0 = null;



        	enterRule();

        try {
            // InternalDomainModel.g:1057:2: ( ( (lv_parameters_format_0_0= ruleoption_format_1 ) )? )
            // InternalDomainModel.g:1058:2: ( (lv_parameters_format_0_0= ruleoption_format_1 ) )?
            {
            // InternalDomainModel.g:1058:2: ( (lv_parameters_format_0_0= ruleoption_format_1 ) )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==24) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalDomainModel.g:1059:3: (lv_parameters_format_0_0= ruleoption_format_1 )
                    {
                    // InternalDomainModel.g:1059:3: (lv_parameters_format_0_0= ruleoption_format_1 )
                    // InternalDomainModel.g:1060:4: lv_parameters_format_0_0= ruleoption_format_1
                    {
                    if ( state.backtracking==0 ) {

                      				newCompositeNode(grammarAccess.getParametersBooleanAccess().getParameters_formatOption_format_1ParserRuleCall_0());
                      			
                    }
                    pushFollow(FOLLOW_2);
                    lv_parameters_format_0_0=ruleoption_format_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				if (current==null) {
                      					current = createModelElementForParent(grammarAccess.getParametersBooleanRule());
                      				}
                      				set(
                      					current,
                      					"parameters_format",
                      					lv_parameters_format_0_0,
                      					"org.xtext.example.mydsl.DomainModel.option_format_1");
                      				afterParserOrEnumRuleCall();
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleparametersBoolean"


    // $ANTLR start "entryRuleparametersList"
    // InternalDomainModel.g:1080:1: entryRuleparametersList returns [EObject current=null] : iv_ruleparametersList= ruleparametersList EOF ;
    public final EObject entryRuleparametersList() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleparametersList = null;


        try {
            // InternalDomainModel.g:1080:55: (iv_ruleparametersList= ruleparametersList EOF )
            // InternalDomainModel.g:1081:2: iv_ruleparametersList= ruleparametersList EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getParametersListRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleparametersList=ruleparametersList();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleparametersList; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleparametersList"


    // $ANTLR start "ruleparametersList"
    // InternalDomainModel.g:1087:1: ruleparametersList returns [EObject current=null] : ( ( ( (lv_parameters_length_type_0_0= ruleoption_length_type ) ) (otherlv_1= ',' ( (lv_parameters_min_length_2_0= ruleoption_min_length ) ) )? (otherlv_3= ',' ( (lv_parameters_max_length_4_0= ruleoption_max_length ) ) )? (otherlv_5= ',' ( (lv_parameters_content_type_6_0= ruleoption_content_type ) ) )? ) | ( ( (lv_parameters_min_length_7_0= ruleoption_min_length ) ) (otherlv_8= ',' ( (lv_parameters_max_length_9_0= ruleoption_max_length ) ) )? (otherlv_10= ',' ( (lv_parameters_content_type_11_0= ruleoption_content_type ) ) )? ) | ( ( (lv_parameters_max_length_12_0= ruleoption_max_length ) ) (otherlv_13= ',' ( (lv_parameters_content_type_14_0= ruleoption_content_type ) ) )? ) | ( (lv_parameters_content_type_15_0= ruleoption_content_type ) ) ) ;
    public final EObject ruleparametersList() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_13=null;
        EObject lv_parameters_length_type_0_0 = null;

        EObject lv_parameters_min_length_2_0 = null;

        EObject lv_parameters_max_length_4_0 = null;

        EObject lv_parameters_content_type_6_0 = null;

        EObject lv_parameters_min_length_7_0 = null;

        EObject lv_parameters_max_length_9_0 = null;

        EObject lv_parameters_content_type_11_0 = null;

        EObject lv_parameters_max_length_12_0 = null;

        EObject lv_parameters_content_type_14_0 = null;

        EObject lv_parameters_content_type_15_0 = null;



        	enterRule();

        try {
            // InternalDomainModel.g:1093:2: ( ( ( ( (lv_parameters_length_type_0_0= ruleoption_length_type ) ) (otherlv_1= ',' ( (lv_parameters_min_length_2_0= ruleoption_min_length ) ) )? (otherlv_3= ',' ( (lv_parameters_max_length_4_0= ruleoption_max_length ) ) )? (otherlv_5= ',' ( (lv_parameters_content_type_6_0= ruleoption_content_type ) ) )? ) | ( ( (lv_parameters_min_length_7_0= ruleoption_min_length ) ) (otherlv_8= ',' ( (lv_parameters_max_length_9_0= ruleoption_max_length ) ) )? (otherlv_10= ',' ( (lv_parameters_content_type_11_0= ruleoption_content_type ) ) )? ) | ( ( (lv_parameters_max_length_12_0= ruleoption_max_length ) ) (otherlv_13= ',' ( (lv_parameters_content_type_14_0= ruleoption_content_type ) ) )? ) | ( (lv_parameters_content_type_15_0= ruleoption_content_type ) ) ) )
            // InternalDomainModel.g:1094:2: ( ( ( (lv_parameters_length_type_0_0= ruleoption_length_type ) ) (otherlv_1= ',' ( (lv_parameters_min_length_2_0= ruleoption_min_length ) ) )? (otherlv_3= ',' ( (lv_parameters_max_length_4_0= ruleoption_max_length ) ) )? (otherlv_5= ',' ( (lv_parameters_content_type_6_0= ruleoption_content_type ) ) )? ) | ( ( (lv_parameters_min_length_7_0= ruleoption_min_length ) ) (otherlv_8= ',' ( (lv_parameters_max_length_9_0= ruleoption_max_length ) ) )? (otherlv_10= ',' ( (lv_parameters_content_type_11_0= ruleoption_content_type ) ) )? ) | ( ( (lv_parameters_max_length_12_0= ruleoption_max_length ) ) (otherlv_13= ',' ( (lv_parameters_content_type_14_0= ruleoption_content_type ) ) )? ) | ( (lv_parameters_content_type_15_0= ruleoption_content_type ) ) )
            {
            // InternalDomainModel.g:1094:2: ( ( ( (lv_parameters_length_type_0_0= ruleoption_length_type ) ) (otherlv_1= ',' ( (lv_parameters_min_length_2_0= ruleoption_min_length ) ) )? (otherlv_3= ',' ( (lv_parameters_max_length_4_0= ruleoption_max_length ) ) )? (otherlv_5= ',' ( (lv_parameters_content_type_6_0= ruleoption_content_type ) ) )? ) | ( ( (lv_parameters_min_length_7_0= ruleoption_min_length ) ) (otherlv_8= ',' ( (lv_parameters_max_length_9_0= ruleoption_max_length ) ) )? (otherlv_10= ',' ( (lv_parameters_content_type_11_0= ruleoption_content_type ) ) )? ) | ( ( (lv_parameters_max_length_12_0= ruleoption_max_length ) ) (otherlv_13= ',' ( (lv_parameters_content_type_14_0= ruleoption_content_type ) ) )? ) | ( (lv_parameters_content_type_15_0= ruleoption_content_type ) ) )
            int alt17=4;
            switch ( input.LA(1) ) {
            case 25:
                {
                alt17=1;
                }
                break;
            case 26:
                {
                alt17=2;
                }
                break;
            case 27:
                {
                alt17=3;
                }
                break;
            case 28:
                {
                alt17=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;
            }

            switch (alt17) {
                case 1 :
                    // InternalDomainModel.g:1095:3: ( ( (lv_parameters_length_type_0_0= ruleoption_length_type ) ) (otherlv_1= ',' ( (lv_parameters_min_length_2_0= ruleoption_min_length ) ) )? (otherlv_3= ',' ( (lv_parameters_max_length_4_0= ruleoption_max_length ) ) )? (otherlv_5= ',' ( (lv_parameters_content_type_6_0= ruleoption_content_type ) ) )? )
                    {
                    // InternalDomainModel.g:1095:3: ( ( (lv_parameters_length_type_0_0= ruleoption_length_type ) ) (otherlv_1= ',' ( (lv_parameters_min_length_2_0= ruleoption_min_length ) ) )? (otherlv_3= ',' ( (lv_parameters_max_length_4_0= ruleoption_max_length ) ) )? (otherlv_5= ',' ( (lv_parameters_content_type_6_0= ruleoption_content_type ) ) )? )
                    // InternalDomainModel.g:1096:4: ( (lv_parameters_length_type_0_0= ruleoption_length_type ) ) (otherlv_1= ',' ( (lv_parameters_min_length_2_0= ruleoption_min_length ) ) )? (otherlv_3= ',' ( (lv_parameters_max_length_4_0= ruleoption_max_length ) ) )? (otherlv_5= ',' ( (lv_parameters_content_type_6_0= ruleoption_content_type ) ) )?
                    {
                    // InternalDomainModel.g:1096:4: ( (lv_parameters_length_type_0_0= ruleoption_length_type ) )
                    // InternalDomainModel.g:1097:5: (lv_parameters_length_type_0_0= ruleoption_length_type )
                    {
                    // InternalDomainModel.g:1097:5: (lv_parameters_length_type_0_0= ruleoption_length_type )
                    // InternalDomainModel.g:1098:6: lv_parameters_length_type_0_0= ruleoption_length_type
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getParametersListAccess().getParameters_length_typeOption_length_typeParserRuleCall_0_0_0());
                      					
                    }
                    pushFollow(FOLLOW_17);
                    lv_parameters_length_type_0_0=ruleoption_length_type();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getParametersListRule());
                      						}
                      						set(
                      							current,
                      							"parameters_length_type",
                      							lv_parameters_length_type_0_0,
                      							"org.xtext.example.mydsl.DomainModel.option_length_type");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:1115:4: (otherlv_1= ',' ( (lv_parameters_min_length_2_0= ruleoption_min_length ) ) )?
                    int alt11=2;
                    int LA11_0 = input.LA(1);

                    if ( (LA11_0==31) ) {
                        int LA11_1 = input.LA(2);

                        if ( (LA11_1==26) ) {
                            alt11=1;
                        }
                    }
                    switch (alt11) {
                        case 1 :
                            // InternalDomainModel.g:1116:5: otherlv_1= ',' ( (lv_parameters_min_length_2_0= ruleoption_min_length ) )
                            {
                            otherlv_1=(Token)match(input,31,FOLLOW_20); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_1, grammarAccess.getParametersListAccess().getCommaKeyword_0_1_0());
                              				
                            }
                            // InternalDomainModel.g:1120:5: ( (lv_parameters_min_length_2_0= ruleoption_min_length ) )
                            // InternalDomainModel.g:1121:6: (lv_parameters_min_length_2_0= ruleoption_min_length )
                            {
                            // InternalDomainModel.g:1121:6: (lv_parameters_min_length_2_0= ruleoption_min_length )
                            // InternalDomainModel.g:1122:7: lv_parameters_min_length_2_0= ruleoption_min_length
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getParametersListAccess().getParameters_min_lengthOption_min_lengthParserRuleCall_0_1_1_0());
                              						
                            }
                            pushFollow(FOLLOW_17);
                            lv_parameters_min_length_2_0=ruleoption_min_length();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElementForParent(grammarAccess.getParametersListRule());
                              							}
                              							set(
                              								current,
                              								"parameters_min_length",
                              								lv_parameters_min_length_2_0,
                              								"org.xtext.example.mydsl.DomainModel.option_min_length");
                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }


                            }


                            }
                            break;

                    }

                    // InternalDomainModel.g:1140:4: (otherlv_3= ',' ( (lv_parameters_max_length_4_0= ruleoption_max_length ) ) )?
                    int alt12=2;
                    int LA12_0 = input.LA(1);

                    if ( (LA12_0==31) ) {
                        int LA12_1 = input.LA(2);

                        if ( (LA12_1==27) ) {
                            alt12=1;
                        }
                    }
                    switch (alt12) {
                        case 1 :
                            // InternalDomainModel.g:1141:5: otherlv_3= ',' ( (lv_parameters_max_length_4_0= ruleoption_max_length ) )
                            {
                            otherlv_3=(Token)match(input,31,FOLLOW_21); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_3, grammarAccess.getParametersListAccess().getCommaKeyword_0_2_0());
                              				
                            }
                            // InternalDomainModel.g:1145:5: ( (lv_parameters_max_length_4_0= ruleoption_max_length ) )
                            // InternalDomainModel.g:1146:6: (lv_parameters_max_length_4_0= ruleoption_max_length )
                            {
                            // InternalDomainModel.g:1146:6: (lv_parameters_max_length_4_0= ruleoption_max_length )
                            // InternalDomainModel.g:1147:7: lv_parameters_max_length_4_0= ruleoption_max_length
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getParametersListAccess().getParameters_max_lengthOption_max_lengthParserRuleCall_0_2_1_0());
                              						
                            }
                            pushFollow(FOLLOW_17);
                            lv_parameters_max_length_4_0=ruleoption_max_length();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElementForParent(grammarAccess.getParametersListRule());
                              							}
                              							set(
                              								current,
                              								"parameters_max_length",
                              								lv_parameters_max_length_4_0,
                              								"org.xtext.example.mydsl.DomainModel.option_max_length");
                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }


                            }


                            }
                            break;

                    }

                    // InternalDomainModel.g:1165:4: (otherlv_5= ',' ( (lv_parameters_content_type_6_0= ruleoption_content_type ) ) )?
                    int alt13=2;
                    int LA13_0 = input.LA(1);

                    if ( (LA13_0==31) ) {
                        alt13=1;
                    }
                    switch (alt13) {
                        case 1 :
                            // InternalDomainModel.g:1166:5: otherlv_5= ',' ( (lv_parameters_content_type_6_0= ruleoption_content_type ) )
                            {
                            otherlv_5=(Token)match(input,31,FOLLOW_22); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_5, grammarAccess.getParametersListAccess().getCommaKeyword_0_3_0());
                              				
                            }
                            // InternalDomainModel.g:1170:5: ( (lv_parameters_content_type_6_0= ruleoption_content_type ) )
                            // InternalDomainModel.g:1171:6: (lv_parameters_content_type_6_0= ruleoption_content_type )
                            {
                            // InternalDomainModel.g:1171:6: (lv_parameters_content_type_6_0= ruleoption_content_type )
                            // InternalDomainModel.g:1172:7: lv_parameters_content_type_6_0= ruleoption_content_type
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getParametersListAccess().getParameters_content_typeOption_content_typeParserRuleCall_0_3_1_0());
                              						
                            }
                            pushFollow(FOLLOW_2);
                            lv_parameters_content_type_6_0=ruleoption_content_type();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElementForParent(grammarAccess.getParametersListRule());
                              							}
                              							set(
                              								current,
                              								"parameters_content_type",
                              								lv_parameters_content_type_6_0,
                              								"org.xtext.example.mydsl.DomainModel.option_content_type");
                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }


                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalDomainModel.g:1192:3: ( ( (lv_parameters_min_length_7_0= ruleoption_min_length ) ) (otherlv_8= ',' ( (lv_parameters_max_length_9_0= ruleoption_max_length ) ) )? (otherlv_10= ',' ( (lv_parameters_content_type_11_0= ruleoption_content_type ) ) )? )
                    {
                    // InternalDomainModel.g:1192:3: ( ( (lv_parameters_min_length_7_0= ruleoption_min_length ) ) (otherlv_8= ',' ( (lv_parameters_max_length_9_0= ruleoption_max_length ) ) )? (otherlv_10= ',' ( (lv_parameters_content_type_11_0= ruleoption_content_type ) ) )? )
                    // InternalDomainModel.g:1193:4: ( (lv_parameters_min_length_7_0= ruleoption_min_length ) ) (otherlv_8= ',' ( (lv_parameters_max_length_9_0= ruleoption_max_length ) ) )? (otherlv_10= ',' ( (lv_parameters_content_type_11_0= ruleoption_content_type ) ) )?
                    {
                    // InternalDomainModel.g:1193:4: ( (lv_parameters_min_length_7_0= ruleoption_min_length ) )
                    // InternalDomainModel.g:1194:5: (lv_parameters_min_length_7_0= ruleoption_min_length )
                    {
                    // InternalDomainModel.g:1194:5: (lv_parameters_min_length_7_0= ruleoption_min_length )
                    // InternalDomainModel.g:1195:6: lv_parameters_min_length_7_0= ruleoption_min_length
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getParametersListAccess().getParameters_min_lengthOption_min_lengthParserRuleCall_1_0_0());
                      					
                    }
                    pushFollow(FOLLOW_17);
                    lv_parameters_min_length_7_0=ruleoption_min_length();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getParametersListRule());
                      						}
                      						set(
                      							current,
                      							"parameters_min_length",
                      							lv_parameters_min_length_7_0,
                      							"org.xtext.example.mydsl.DomainModel.option_min_length");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:1212:4: (otherlv_8= ',' ( (lv_parameters_max_length_9_0= ruleoption_max_length ) ) )?
                    int alt14=2;
                    int LA14_0 = input.LA(1);

                    if ( (LA14_0==31) ) {
                        int LA14_1 = input.LA(2);

                        if ( (LA14_1==27) ) {
                            alt14=1;
                        }
                    }
                    switch (alt14) {
                        case 1 :
                            // InternalDomainModel.g:1213:5: otherlv_8= ',' ( (lv_parameters_max_length_9_0= ruleoption_max_length ) )
                            {
                            otherlv_8=(Token)match(input,31,FOLLOW_21); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_8, grammarAccess.getParametersListAccess().getCommaKeyword_1_1_0());
                              				
                            }
                            // InternalDomainModel.g:1217:5: ( (lv_parameters_max_length_9_0= ruleoption_max_length ) )
                            // InternalDomainModel.g:1218:6: (lv_parameters_max_length_9_0= ruleoption_max_length )
                            {
                            // InternalDomainModel.g:1218:6: (lv_parameters_max_length_9_0= ruleoption_max_length )
                            // InternalDomainModel.g:1219:7: lv_parameters_max_length_9_0= ruleoption_max_length
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getParametersListAccess().getParameters_max_lengthOption_max_lengthParserRuleCall_1_1_1_0());
                              						
                            }
                            pushFollow(FOLLOW_17);
                            lv_parameters_max_length_9_0=ruleoption_max_length();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElementForParent(grammarAccess.getParametersListRule());
                              							}
                              							set(
                              								current,
                              								"parameters_max_length",
                              								lv_parameters_max_length_9_0,
                              								"org.xtext.example.mydsl.DomainModel.option_max_length");
                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }


                            }


                            }
                            break;

                    }

                    // InternalDomainModel.g:1237:4: (otherlv_10= ',' ( (lv_parameters_content_type_11_0= ruleoption_content_type ) ) )?
                    int alt15=2;
                    int LA15_0 = input.LA(1);

                    if ( (LA15_0==31) ) {
                        alt15=1;
                    }
                    switch (alt15) {
                        case 1 :
                            // InternalDomainModel.g:1238:5: otherlv_10= ',' ( (lv_parameters_content_type_11_0= ruleoption_content_type ) )
                            {
                            otherlv_10=(Token)match(input,31,FOLLOW_22); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_10, grammarAccess.getParametersListAccess().getCommaKeyword_1_2_0());
                              				
                            }
                            // InternalDomainModel.g:1242:5: ( (lv_parameters_content_type_11_0= ruleoption_content_type ) )
                            // InternalDomainModel.g:1243:6: (lv_parameters_content_type_11_0= ruleoption_content_type )
                            {
                            // InternalDomainModel.g:1243:6: (lv_parameters_content_type_11_0= ruleoption_content_type )
                            // InternalDomainModel.g:1244:7: lv_parameters_content_type_11_0= ruleoption_content_type
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getParametersListAccess().getParameters_content_typeOption_content_typeParserRuleCall_1_2_1_0());
                              						
                            }
                            pushFollow(FOLLOW_2);
                            lv_parameters_content_type_11_0=ruleoption_content_type();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElementForParent(grammarAccess.getParametersListRule());
                              							}
                              							set(
                              								current,
                              								"parameters_content_type",
                              								lv_parameters_content_type_11_0,
                              								"org.xtext.example.mydsl.DomainModel.option_content_type");
                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }


                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalDomainModel.g:1264:3: ( ( (lv_parameters_max_length_12_0= ruleoption_max_length ) ) (otherlv_13= ',' ( (lv_parameters_content_type_14_0= ruleoption_content_type ) ) )? )
                    {
                    // InternalDomainModel.g:1264:3: ( ( (lv_parameters_max_length_12_0= ruleoption_max_length ) ) (otherlv_13= ',' ( (lv_parameters_content_type_14_0= ruleoption_content_type ) ) )? )
                    // InternalDomainModel.g:1265:4: ( (lv_parameters_max_length_12_0= ruleoption_max_length ) ) (otherlv_13= ',' ( (lv_parameters_content_type_14_0= ruleoption_content_type ) ) )?
                    {
                    // InternalDomainModel.g:1265:4: ( (lv_parameters_max_length_12_0= ruleoption_max_length ) )
                    // InternalDomainModel.g:1266:5: (lv_parameters_max_length_12_0= ruleoption_max_length )
                    {
                    // InternalDomainModel.g:1266:5: (lv_parameters_max_length_12_0= ruleoption_max_length )
                    // InternalDomainModel.g:1267:6: lv_parameters_max_length_12_0= ruleoption_max_length
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getParametersListAccess().getParameters_max_lengthOption_max_lengthParserRuleCall_2_0_0());
                      					
                    }
                    pushFollow(FOLLOW_17);
                    lv_parameters_max_length_12_0=ruleoption_max_length();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getParametersListRule());
                      						}
                      						set(
                      							current,
                      							"parameters_max_length",
                      							lv_parameters_max_length_12_0,
                      							"org.xtext.example.mydsl.DomainModel.option_max_length");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:1284:4: (otherlv_13= ',' ( (lv_parameters_content_type_14_0= ruleoption_content_type ) ) )?
                    int alt16=2;
                    int LA16_0 = input.LA(1);

                    if ( (LA16_0==31) ) {
                        alt16=1;
                    }
                    switch (alt16) {
                        case 1 :
                            // InternalDomainModel.g:1285:5: otherlv_13= ',' ( (lv_parameters_content_type_14_0= ruleoption_content_type ) )
                            {
                            otherlv_13=(Token)match(input,31,FOLLOW_22); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_13, grammarAccess.getParametersListAccess().getCommaKeyword_2_1_0());
                              				
                            }
                            // InternalDomainModel.g:1289:5: ( (lv_parameters_content_type_14_0= ruleoption_content_type ) )
                            // InternalDomainModel.g:1290:6: (lv_parameters_content_type_14_0= ruleoption_content_type )
                            {
                            // InternalDomainModel.g:1290:6: (lv_parameters_content_type_14_0= ruleoption_content_type )
                            // InternalDomainModel.g:1291:7: lv_parameters_content_type_14_0= ruleoption_content_type
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getParametersListAccess().getParameters_content_typeOption_content_typeParserRuleCall_2_1_1_0());
                              						
                            }
                            pushFollow(FOLLOW_2);
                            lv_parameters_content_type_14_0=ruleoption_content_type();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElementForParent(grammarAccess.getParametersListRule());
                              							}
                              							set(
                              								current,
                              								"parameters_content_type",
                              								lv_parameters_content_type_14_0,
                              								"org.xtext.example.mydsl.DomainModel.option_content_type");
                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }


                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 4 :
                    // InternalDomainModel.g:1311:3: ( (lv_parameters_content_type_15_0= ruleoption_content_type ) )
                    {
                    // InternalDomainModel.g:1311:3: ( (lv_parameters_content_type_15_0= ruleoption_content_type ) )
                    // InternalDomainModel.g:1312:4: (lv_parameters_content_type_15_0= ruleoption_content_type )
                    {
                    // InternalDomainModel.g:1312:4: (lv_parameters_content_type_15_0= ruleoption_content_type )
                    // InternalDomainModel.g:1313:5: lv_parameters_content_type_15_0= ruleoption_content_type
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getParametersListAccess().getParameters_content_typeOption_content_typeParserRuleCall_3_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_parameters_content_type_15_0=ruleoption_content_type();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getParametersListRule());
                      					}
                      					set(
                      						current,
                      						"parameters_content_type",
                      						lv_parameters_content_type_15_0,
                      						"org.xtext.example.mydsl.DomainModel.option_content_type");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleparametersList"


    // $ANTLR start "entryRuleparametersPermutation"
    // InternalDomainModel.g:1334:1: entryRuleparametersPermutation returns [EObject current=null] : iv_ruleparametersPermutation= ruleparametersPermutation EOF ;
    public final EObject entryRuleparametersPermutation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleparametersPermutation = null;


        try {
            // InternalDomainModel.g:1334:62: (iv_ruleparametersPermutation= ruleparametersPermutation EOF )
            // InternalDomainModel.g:1335:2: iv_ruleparametersPermutation= ruleparametersPermutation EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getParametersPermutationRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleparametersPermutation=ruleparametersPermutation();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleparametersPermutation; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleparametersPermutation"


    // $ANTLR start "ruleparametersPermutation"
    // InternalDomainModel.g:1341:1: ruleparametersPermutation returns [EObject current=null] : ( (lv_id_int_0_0= RULE_INT ) ) ;
    public final EObject ruleparametersPermutation() throws RecognitionException {
        EObject current = null;

        Token lv_id_int_0_0=null;


        	enterRule();

        try {
            // InternalDomainModel.g:1347:2: ( ( (lv_id_int_0_0= RULE_INT ) ) )
            // InternalDomainModel.g:1348:2: ( (lv_id_int_0_0= RULE_INT ) )
            {
            // InternalDomainModel.g:1348:2: ( (lv_id_int_0_0= RULE_INT ) )
            // InternalDomainModel.g:1349:3: (lv_id_int_0_0= RULE_INT )
            {
            // InternalDomainModel.g:1349:3: (lv_id_int_0_0= RULE_INT )
            // InternalDomainModel.g:1350:4: lv_id_int_0_0= RULE_INT
            {
            lv_id_int_0_0=(Token)match(input,RULE_INT,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(lv_id_int_0_0, grammarAccess.getParametersPermutationAccess().getId_intINTTerminalRuleCall_0());
              			
            }
            if ( state.backtracking==0 ) {

              				if (current==null) {
              					current = createModelElement(grammarAccess.getParametersPermutationRule());
              				}
              				setWithLastConsumed(
              					current,
              					"id_int",
              					lv_id_int_0_0,
              					"org.eclipse.xtext.common.Terminals.INT");
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleparametersPermutation"


    // $ANTLR start "entryRuleparametersChar"
    // InternalDomainModel.g:1369:1: entryRuleparametersChar returns [EObject current=null] : iv_ruleparametersChar= ruleparametersChar EOF ;
    public final EObject entryRuleparametersChar() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleparametersChar = null;


        try {
            // InternalDomainModel.g:1369:55: (iv_ruleparametersChar= ruleparametersChar EOF )
            // InternalDomainModel.g:1370:2: iv_ruleparametersChar= ruleparametersChar EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getParametersCharRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleparametersChar=ruleparametersChar();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleparametersChar; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleparametersChar"


    // $ANTLR start "ruleparametersChar"
    // InternalDomainModel.g:1376:1: ruleparametersChar returns [EObject current=null] : ( ( ( (lv_parameters_min_length_0_0= ruleoption_min_length ) ) (otherlv_1= ',' ( (lv_parameters_max_length_2_0= ruleoption_max_length ) ) )? (otherlv_3= ',' ( (lv_parameters_condition_4_0= ruleoption_condition ) ) )? ) | ( ( (lv_parameters_max_length_5_0= ruleoption_max_length ) ) (otherlv_6= ',' ( (lv_parameters_condition_7_0= ruleoption_condition ) ) )? ) | ( (lv_parameters_condition_8_0= ruleoption_condition ) ) ) ;
    public final EObject ruleparametersChar() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_6=null;
        EObject lv_parameters_min_length_0_0 = null;

        EObject lv_parameters_max_length_2_0 = null;

        EObject lv_parameters_condition_4_0 = null;

        EObject lv_parameters_max_length_5_0 = null;

        EObject lv_parameters_condition_7_0 = null;

        EObject lv_parameters_condition_8_0 = null;



        	enterRule();

        try {
            // InternalDomainModel.g:1382:2: ( ( ( ( (lv_parameters_min_length_0_0= ruleoption_min_length ) ) (otherlv_1= ',' ( (lv_parameters_max_length_2_0= ruleoption_max_length ) ) )? (otherlv_3= ',' ( (lv_parameters_condition_4_0= ruleoption_condition ) ) )? ) | ( ( (lv_parameters_max_length_5_0= ruleoption_max_length ) ) (otherlv_6= ',' ( (lv_parameters_condition_7_0= ruleoption_condition ) ) )? ) | ( (lv_parameters_condition_8_0= ruleoption_condition ) ) ) )
            // InternalDomainModel.g:1383:2: ( ( ( (lv_parameters_min_length_0_0= ruleoption_min_length ) ) (otherlv_1= ',' ( (lv_parameters_max_length_2_0= ruleoption_max_length ) ) )? (otherlv_3= ',' ( (lv_parameters_condition_4_0= ruleoption_condition ) ) )? ) | ( ( (lv_parameters_max_length_5_0= ruleoption_max_length ) ) (otherlv_6= ',' ( (lv_parameters_condition_7_0= ruleoption_condition ) ) )? ) | ( (lv_parameters_condition_8_0= ruleoption_condition ) ) )
            {
            // InternalDomainModel.g:1383:2: ( ( ( (lv_parameters_min_length_0_0= ruleoption_min_length ) ) (otherlv_1= ',' ( (lv_parameters_max_length_2_0= ruleoption_max_length ) ) )? (otherlv_3= ',' ( (lv_parameters_condition_4_0= ruleoption_condition ) ) )? ) | ( ( (lv_parameters_max_length_5_0= ruleoption_max_length ) ) (otherlv_6= ',' ( (lv_parameters_condition_7_0= ruleoption_condition ) ) )? ) | ( (lv_parameters_condition_8_0= ruleoption_condition ) ) )
            int alt21=3;
            switch ( input.LA(1) ) {
            case 26:
                {
                alt21=1;
                }
                break;
            case 27:
                {
                alt21=2;
                }
                break;
            case 23:
                {
                alt21=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 21, 0, input);

                throw nvae;
            }

            switch (alt21) {
                case 1 :
                    // InternalDomainModel.g:1384:3: ( ( (lv_parameters_min_length_0_0= ruleoption_min_length ) ) (otherlv_1= ',' ( (lv_parameters_max_length_2_0= ruleoption_max_length ) ) )? (otherlv_3= ',' ( (lv_parameters_condition_4_0= ruleoption_condition ) ) )? )
                    {
                    // InternalDomainModel.g:1384:3: ( ( (lv_parameters_min_length_0_0= ruleoption_min_length ) ) (otherlv_1= ',' ( (lv_parameters_max_length_2_0= ruleoption_max_length ) ) )? (otherlv_3= ',' ( (lv_parameters_condition_4_0= ruleoption_condition ) ) )? )
                    // InternalDomainModel.g:1385:4: ( (lv_parameters_min_length_0_0= ruleoption_min_length ) ) (otherlv_1= ',' ( (lv_parameters_max_length_2_0= ruleoption_max_length ) ) )? (otherlv_3= ',' ( (lv_parameters_condition_4_0= ruleoption_condition ) ) )?
                    {
                    // InternalDomainModel.g:1385:4: ( (lv_parameters_min_length_0_0= ruleoption_min_length ) )
                    // InternalDomainModel.g:1386:5: (lv_parameters_min_length_0_0= ruleoption_min_length )
                    {
                    // InternalDomainModel.g:1386:5: (lv_parameters_min_length_0_0= ruleoption_min_length )
                    // InternalDomainModel.g:1387:6: lv_parameters_min_length_0_0= ruleoption_min_length
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getParametersCharAccess().getParameters_min_lengthOption_min_lengthParserRuleCall_0_0_0());
                      					
                    }
                    pushFollow(FOLLOW_17);
                    lv_parameters_min_length_0_0=ruleoption_min_length();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getParametersCharRule());
                      						}
                      						set(
                      							current,
                      							"parameters_min_length",
                      							lv_parameters_min_length_0_0,
                      							"org.xtext.example.mydsl.DomainModel.option_min_length");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:1404:4: (otherlv_1= ',' ( (lv_parameters_max_length_2_0= ruleoption_max_length ) ) )?
                    int alt18=2;
                    int LA18_0 = input.LA(1);

                    if ( (LA18_0==31) ) {
                        int LA18_1 = input.LA(2);

                        if ( (LA18_1==27) ) {
                            alt18=1;
                        }
                    }
                    switch (alt18) {
                        case 1 :
                            // InternalDomainModel.g:1405:5: otherlv_1= ',' ( (lv_parameters_max_length_2_0= ruleoption_max_length ) )
                            {
                            otherlv_1=(Token)match(input,31,FOLLOW_21); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_1, grammarAccess.getParametersCharAccess().getCommaKeyword_0_1_0());
                              				
                            }
                            // InternalDomainModel.g:1409:5: ( (lv_parameters_max_length_2_0= ruleoption_max_length ) )
                            // InternalDomainModel.g:1410:6: (lv_parameters_max_length_2_0= ruleoption_max_length )
                            {
                            // InternalDomainModel.g:1410:6: (lv_parameters_max_length_2_0= ruleoption_max_length )
                            // InternalDomainModel.g:1411:7: lv_parameters_max_length_2_0= ruleoption_max_length
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getParametersCharAccess().getParameters_max_lengthOption_max_lengthParserRuleCall_0_1_1_0());
                              						
                            }
                            pushFollow(FOLLOW_17);
                            lv_parameters_max_length_2_0=ruleoption_max_length();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElementForParent(grammarAccess.getParametersCharRule());
                              							}
                              							set(
                              								current,
                              								"parameters_max_length",
                              								lv_parameters_max_length_2_0,
                              								"org.xtext.example.mydsl.DomainModel.option_max_length");
                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }


                            }


                            }
                            break;

                    }

                    // InternalDomainModel.g:1429:4: (otherlv_3= ',' ( (lv_parameters_condition_4_0= ruleoption_condition ) ) )?
                    int alt19=2;
                    int LA19_0 = input.LA(1);

                    if ( (LA19_0==31) ) {
                        alt19=1;
                    }
                    switch (alt19) {
                        case 1 :
                            // InternalDomainModel.g:1430:5: otherlv_3= ',' ( (lv_parameters_condition_4_0= ruleoption_condition ) )
                            {
                            otherlv_3=(Token)match(input,31,FOLLOW_8); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_3, grammarAccess.getParametersCharAccess().getCommaKeyword_0_2_0());
                              				
                            }
                            // InternalDomainModel.g:1434:5: ( (lv_parameters_condition_4_0= ruleoption_condition ) )
                            // InternalDomainModel.g:1435:6: (lv_parameters_condition_4_0= ruleoption_condition )
                            {
                            // InternalDomainModel.g:1435:6: (lv_parameters_condition_4_0= ruleoption_condition )
                            // InternalDomainModel.g:1436:7: lv_parameters_condition_4_0= ruleoption_condition
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getParametersCharAccess().getParameters_conditionOption_conditionParserRuleCall_0_2_1_0());
                              						
                            }
                            pushFollow(FOLLOW_2);
                            lv_parameters_condition_4_0=ruleoption_condition();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElementForParent(grammarAccess.getParametersCharRule());
                              							}
                              							set(
                              								current,
                              								"parameters_condition",
                              								lv_parameters_condition_4_0,
                              								"org.xtext.example.mydsl.DomainModel.option_condition");
                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }


                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalDomainModel.g:1456:3: ( ( (lv_parameters_max_length_5_0= ruleoption_max_length ) ) (otherlv_6= ',' ( (lv_parameters_condition_7_0= ruleoption_condition ) ) )? )
                    {
                    // InternalDomainModel.g:1456:3: ( ( (lv_parameters_max_length_5_0= ruleoption_max_length ) ) (otherlv_6= ',' ( (lv_parameters_condition_7_0= ruleoption_condition ) ) )? )
                    // InternalDomainModel.g:1457:4: ( (lv_parameters_max_length_5_0= ruleoption_max_length ) ) (otherlv_6= ',' ( (lv_parameters_condition_7_0= ruleoption_condition ) ) )?
                    {
                    // InternalDomainModel.g:1457:4: ( (lv_parameters_max_length_5_0= ruleoption_max_length ) )
                    // InternalDomainModel.g:1458:5: (lv_parameters_max_length_5_0= ruleoption_max_length )
                    {
                    // InternalDomainModel.g:1458:5: (lv_parameters_max_length_5_0= ruleoption_max_length )
                    // InternalDomainModel.g:1459:6: lv_parameters_max_length_5_0= ruleoption_max_length
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getParametersCharAccess().getParameters_max_lengthOption_max_lengthParserRuleCall_1_0_0());
                      					
                    }
                    pushFollow(FOLLOW_17);
                    lv_parameters_max_length_5_0=ruleoption_max_length();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getParametersCharRule());
                      						}
                      						set(
                      							current,
                      							"parameters_max_length",
                      							lv_parameters_max_length_5_0,
                      							"org.xtext.example.mydsl.DomainModel.option_max_length");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:1476:4: (otherlv_6= ',' ( (lv_parameters_condition_7_0= ruleoption_condition ) ) )?
                    int alt20=2;
                    int LA20_0 = input.LA(1);

                    if ( (LA20_0==31) ) {
                        alt20=1;
                    }
                    switch (alt20) {
                        case 1 :
                            // InternalDomainModel.g:1477:5: otherlv_6= ',' ( (lv_parameters_condition_7_0= ruleoption_condition ) )
                            {
                            otherlv_6=(Token)match(input,31,FOLLOW_8); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_6, grammarAccess.getParametersCharAccess().getCommaKeyword_1_1_0());
                              				
                            }
                            // InternalDomainModel.g:1481:5: ( (lv_parameters_condition_7_0= ruleoption_condition ) )
                            // InternalDomainModel.g:1482:6: (lv_parameters_condition_7_0= ruleoption_condition )
                            {
                            // InternalDomainModel.g:1482:6: (lv_parameters_condition_7_0= ruleoption_condition )
                            // InternalDomainModel.g:1483:7: lv_parameters_condition_7_0= ruleoption_condition
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getParametersCharAccess().getParameters_conditionOption_conditionParserRuleCall_1_1_1_0());
                              						
                            }
                            pushFollow(FOLLOW_2);
                            lv_parameters_condition_7_0=ruleoption_condition();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElementForParent(grammarAccess.getParametersCharRule());
                              							}
                              							set(
                              								current,
                              								"parameters_condition",
                              								lv_parameters_condition_7_0,
                              								"org.xtext.example.mydsl.DomainModel.option_condition");
                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }


                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalDomainModel.g:1503:3: ( (lv_parameters_condition_8_0= ruleoption_condition ) )
                    {
                    // InternalDomainModel.g:1503:3: ( (lv_parameters_condition_8_0= ruleoption_condition ) )
                    // InternalDomainModel.g:1504:4: (lv_parameters_condition_8_0= ruleoption_condition )
                    {
                    // InternalDomainModel.g:1504:4: (lv_parameters_condition_8_0= ruleoption_condition )
                    // InternalDomainModel.g:1505:5: lv_parameters_condition_8_0= ruleoption_condition
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getParametersCharAccess().getParameters_conditionOption_conditionParserRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_parameters_condition_8_0=ruleoption_condition();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getParametersCharRule());
                      					}
                      					set(
                      						current,
                      						"parameters_condition",
                      						lv_parameters_condition_8_0,
                      						"org.xtext.example.mydsl.DomainModel.option_condition");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleparametersChar"


    // $ANTLR start "entryRuleparametersString"
    // InternalDomainModel.g:1526:1: entryRuleparametersString returns [EObject current=null] : iv_ruleparametersString= ruleparametersString EOF ;
    public final EObject entryRuleparametersString() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleparametersString = null;


        try {
            // InternalDomainModel.g:1526:57: (iv_ruleparametersString= ruleparametersString EOF )
            // InternalDomainModel.g:1527:2: iv_ruleparametersString= ruleparametersString EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getParametersStringRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleparametersString=ruleparametersString();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleparametersString; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleparametersString"


    // $ANTLR start "ruleparametersString"
    // InternalDomainModel.g:1533:1: ruleparametersString returns [EObject current=null] : ( ( ( (lv_parameters_content_type_0_0= ruleoption_content_type ) ) (otherlv_1= ',' ( (lv_parameters_min_length_2_0= ruleoption_min_length ) ) )? (otherlv_3= ',' ( (lv_parameters_max_length_4_0= ruleoption_max_length ) ) )? (otherlv_5= ',' ( (lv_parameters_word_set_6_0= ruleoption_word_set ) ) )? (otherlv_7= ',' ( (lv_parameters_condition_8_0= ruleoption_condition ) ) )? ) | ( ( (lv_parameters_min_length_9_0= ruleoption_min_length ) ) (otherlv_10= ',' ( (lv_parameters_max_length_11_0= ruleoption_max_length ) ) )? (otherlv_12= ',' ( (lv_parameters_word_set_13_0= ruleoption_word_set ) ) )? (otherlv_14= ',' ( (lv_parameters_condition_15_0= ruleoption_condition ) ) )? ) | ( ( (lv_parameters_max_length_16_0= ruleoption_max_length ) ) (otherlv_17= ',' ( (lv_parameters_word_set_18_0= ruleoption_word_set ) ) )? (otherlv_19= ',' ( (lv_parameters_condition_20_0= ruleoption_condition ) ) )? ) | ( ( (lv_parameters_word_set_21_0= ruleoption_word_set ) ) (otherlv_22= ',' ( (lv_parameters_condition_23_0= ruleoption_condition ) ) )? ) | ( (lv_parameters_condition_24_0= ruleoption_condition ) ) ) ;
    public final EObject ruleparametersString() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token otherlv_17=null;
        Token otherlv_19=null;
        Token otherlv_22=null;
        EObject lv_parameters_content_type_0_0 = null;

        EObject lv_parameters_min_length_2_0 = null;

        EObject lv_parameters_max_length_4_0 = null;

        EObject lv_parameters_word_set_6_0 = null;

        EObject lv_parameters_condition_8_0 = null;

        EObject lv_parameters_min_length_9_0 = null;

        EObject lv_parameters_max_length_11_0 = null;

        EObject lv_parameters_word_set_13_0 = null;

        EObject lv_parameters_condition_15_0 = null;

        EObject lv_parameters_max_length_16_0 = null;

        EObject lv_parameters_word_set_18_0 = null;

        EObject lv_parameters_condition_20_0 = null;

        EObject lv_parameters_word_set_21_0 = null;

        EObject lv_parameters_condition_23_0 = null;

        EObject lv_parameters_condition_24_0 = null;



        	enterRule();

        try {
            // InternalDomainModel.g:1539:2: ( ( ( ( (lv_parameters_content_type_0_0= ruleoption_content_type ) ) (otherlv_1= ',' ( (lv_parameters_min_length_2_0= ruleoption_min_length ) ) )? (otherlv_3= ',' ( (lv_parameters_max_length_4_0= ruleoption_max_length ) ) )? (otherlv_5= ',' ( (lv_parameters_word_set_6_0= ruleoption_word_set ) ) )? (otherlv_7= ',' ( (lv_parameters_condition_8_0= ruleoption_condition ) ) )? ) | ( ( (lv_parameters_min_length_9_0= ruleoption_min_length ) ) (otherlv_10= ',' ( (lv_parameters_max_length_11_0= ruleoption_max_length ) ) )? (otherlv_12= ',' ( (lv_parameters_word_set_13_0= ruleoption_word_set ) ) )? (otherlv_14= ',' ( (lv_parameters_condition_15_0= ruleoption_condition ) ) )? ) | ( ( (lv_parameters_max_length_16_0= ruleoption_max_length ) ) (otherlv_17= ',' ( (lv_parameters_word_set_18_0= ruleoption_word_set ) ) )? (otherlv_19= ',' ( (lv_parameters_condition_20_0= ruleoption_condition ) ) )? ) | ( ( (lv_parameters_word_set_21_0= ruleoption_word_set ) ) (otherlv_22= ',' ( (lv_parameters_condition_23_0= ruleoption_condition ) ) )? ) | ( (lv_parameters_condition_24_0= ruleoption_condition ) ) ) )
            // InternalDomainModel.g:1540:2: ( ( ( (lv_parameters_content_type_0_0= ruleoption_content_type ) ) (otherlv_1= ',' ( (lv_parameters_min_length_2_0= ruleoption_min_length ) ) )? (otherlv_3= ',' ( (lv_parameters_max_length_4_0= ruleoption_max_length ) ) )? (otherlv_5= ',' ( (lv_parameters_word_set_6_0= ruleoption_word_set ) ) )? (otherlv_7= ',' ( (lv_parameters_condition_8_0= ruleoption_condition ) ) )? ) | ( ( (lv_parameters_min_length_9_0= ruleoption_min_length ) ) (otherlv_10= ',' ( (lv_parameters_max_length_11_0= ruleoption_max_length ) ) )? (otherlv_12= ',' ( (lv_parameters_word_set_13_0= ruleoption_word_set ) ) )? (otherlv_14= ',' ( (lv_parameters_condition_15_0= ruleoption_condition ) ) )? ) | ( ( (lv_parameters_max_length_16_0= ruleoption_max_length ) ) (otherlv_17= ',' ( (lv_parameters_word_set_18_0= ruleoption_word_set ) ) )? (otherlv_19= ',' ( (lv_parameters_condition_20_0= ruleoption_condition ) ) )? ) | ( ( (lv_parameters_word_set_21_0= ruleoption_word_set ) ) (otherlv_22= ',' ( (lv_parameters_condition_23_0= ruleoption_condition ) ) )? ) | ( (lv_parameters_condition_24_0= ruleoption_condition ) ) )
            {
            // InternalDomainModel.g:1540:2: ( ( ( (lv_parameters_content_type_0_0= ruleoption_content_type ) ) (otherlv_1= ',' ( (lv_parameters_min_length_2_0= ruleoption_min_length ) ) )? (otherlv_3= ',' ( (lv_parameters_max_length_4_0= ruleoption_max_length ) ) )? (otherlv_5= ',' ( (lv_parameters_word_set_6_0= ruleoption_word_set ) ) )? (otherlv_7= ',' ( (lv_parameters_condition_8_0= ruleoption_condition ) ) )? ) | ( ( (lv_parameters_min_length_9_0= ruleoption_min_length ) ) (otherlv_10= ',' ( (lv_parameters_max_length_11_0= ruleoption_max_length ) ) )? (otherlv_12= ',' ( (lv_parameters_word_set_13_0= ruleoption_word_set ) ) )? (otherlv_14= ',' ( (lv_parameters_condition_15_0= ruleoption_condition ) ) )? ) | ( ( (lv_parameters_max_length_16_0= ruleoption_max_length ) ) (otherlv_17= ',' ( (lv_parameters_word_set_18_0= ruleoption_word_set ) ) )? (otherlv_19= ',' ( (lv_parameters_condition_20_0= ruleoption_condition ) ) )? ) | ( ( (lv_parameters_word_set_21_0= ruleoption_word_set ) ) (otherlv_22= ',' ( (lv_parameters_condition_23_0= ruleoption_condition ) ) )? ) | ( (lv_parameters_condition_24_0= ruleoption_condition ) ) )
            int alt32=5;
            switch ( input.LA(1) ) {
            case 28:
                {
                alt32=1;
                }
                break;
            case 26:
                {
                alt32=2;
                }
                break;
            case 27:
                {
                alt32=3;
                }
                break;
            case 29:
                {
                alt32=4;
                }
                break;
            case 23:
                {
                alt32=5;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 32, 0, input);

                throw nvae;
            }

            switch (alt32) {
                case 1 :
                    // InternalDomainModel.g:1541:3: ( ( (lv_parameters_content_type_0_0= ruleoption_content_type ) ) (otherlv_1= ',' ( (lv_parameters_min_length_2_0= ruleoption_min_length ) ) )? (otherlv_3= ',' ( (lv_parameters_max_length_4_0= ruleoption_max_length ) ) )? (otherlv_5= ',' ( (lv_parameters_word_set_6_0= ruleoption_word_set ) ) )? (otherlv_7= ',' ( (lv_parameters_condition_8_0= ruleoption_condition ) ) )? )
                    {
                    // InternalDomainModel.g:1541:3: ( ( (lv_parameters_content_type_0_0= ruleoption_content_type ) ) (otherlv_1= ',' ( (lv_parameters_min_length_2_0= ruleoption_min_length ) ) )? (otherlv_3= ',' ( (lv_parameters_max_length_4_0= ruleoption_max_length ) ) )? (otherlv_5= ',' ( (lv_parameters_word_set_6_0= ruleoption_word_set ) ) )? (otherlv_7= ',' ( (lv_parameters_condition_8_0= ruleoption_condition ) ) )? )
                    // InternalDomainModel.g:1542:4: ( (lv_parameters_content_type_0_0= ruleoption_content_type ) ) (otherlv_1= ',' ( (lv_parameters_min_length_2_0= ruleoption_min_length ) ) )? (otherlv_3= ',' ( (lv_parameters_max_length_4_0= ruleoption_max_length ) ) )? (otherlv_5= ',' ( (lv_parameters_word_set_6_0= ruleoption_word_set ) ) )? (otherlv_7= ',' ( (lv_parameters_condition_8_0= ruleoption_condition ) ) )?
                    {
                    // InternalDomainModel.g:1542:4: ( (lv_parameters_content_type_0_0= ruleoption_content_type ) )
                    // InternalDomainModel.g:1543:5: (lv_parameters_content_type_0_0= ruleoption_content_type )
                    {
                    // InternalDomainModel.g:1543:5: (lv_parameters_content_type_0_0= ruleoption_content_type )
                    // InternalDomainModel.g:1544:6: lv_parameters_content_type_0_0= ruleoption_content_type
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getParametersStringAccess().getParameters_content_typeOption_content_typeParserRuleCall_0_0_0());
                      					
                    }
                    pushFollow(FOLLOW_17);
                    lv_parameters_content_type_0_0=ruleoption_content_type();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getParametersStringRule());
                      						}
                      						set(
                      							current,
                      							"parameters_content_type",
                      							lv_parameters_content_type_0_0,
                      							"org.xtext.example.mydsl.DomainModel.option_content_type");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:1561:4: (otherlv_1= ',' ( (lv_parameters_min_length_2_0= ruleoption_min_length ) ) )?
                    int alt22=2;
                    int LA22_0 = input.LA(1);

                    if ( (LA22_0==31) ) {
                        int LA22_1 = input.LA(2);

                        if ( (LA22_1==26) ) {
                            alt22=1;
                        }
                    }
                    switch (alt22) {
                        case 1 :
                            // InternalDomainModel.g:1562:5: otherlv_1= ',' ( (lv_parameters_min_length_2_0= ruleoption_min_length ) )
                            {
                            otherlv_1=(Token)match(input,31,FOLLOW_20); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_1, grammarAccess.getParametersStringAccess().getCommaKeyword_0_1_0());
                              				
                            }
                            // InternalDomainModel.g:1566:5: ( (lv_parameters_min_length_2_0= ruleoption_min_length ) )
                            // InternalDomainModel.g:1567:6: (lv_parameters_min_length_2_0= ruleoption_min_length )
                            {
                            // InternalDomainModel.g:1567:6: (lv_parameters_min_length_2_0= ruleoption_min_length )
                            // InternalDomainModel.g:1568:7: lv_parameters_min_length_2_0= ruleoption_min_length
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getParametersStringAccess().getParameters_min_lengthOption_min_lengthParserRuleCall_0_1_1_0());
                              						
                            }
                            pushFollow(FOLLOW_17);
                            lv_parameters_min_length_2_0=ruleoption_min_length();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElementForParent(grammarAccess.getParametersStringRule());
                              							}
                              							set(
                              								current,
                              								"parameters_min_length",
                              								lv_parameters_min_length_2_0,
                              								"org.xtext.example.mydsl.DomainModel.option_min_length");
                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }


                            }


                            }
                            break;

                    }

                    // InternalDomainModel.g:1586:4: (otherlv_3= ',' ( (lv_parameters_max_length_4_0= ruleoption_max_length ) ) )?
                    int alt23=2;
                    int LA23_0 = input.LA(1);

                    if ( (LA23_0==31) ) {
                        int LA23_1 = input.LA(2);

                        if ( (LA23_1==27) ) {
                            alt23=1;
                        }
                    }
                    switch (alt23) {
                        case 1 :
                            // InternalDomainModel.g:1587:5: otherlv_3= ',' ( (lv_parameters_max_length_4_0= ruleoption_max_length ) )
                            {
                            otherlv_3=(Token)match(input,31,FOLLOW_21); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_3, grammarAccess.getParametersStringAccess().getCommaKeyword_0_2_0());
                              				
                            }
                            // InternalDomainModel.g:1591:5: ( (lv_parameters_max_length_4_0= ruleoption_max_length ) )
                            // InternalDomainModel.g:1592:6: (lv_parameters_max_length_4_0= ruleoption_max_length )
                            {
                            // InternalDomainModel.g:1592:6: (lv_parameters_max_length_4_0= ruleoption_max_length )
                            // InternalDomainModel.g:1593:7: lv_parameters_max_length_4_0= ruleoption_max_length
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getParametersStringAccess().getParameters_max_lengthOption_max_lengthParserRuleCall_0_2_1_0());
                              						
                            }
                            pushFollow(FOLLOW_17);
                            lv_parameters_max_length_4_0=ruleoption_max_length();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElementForParent(grammarAccess.getParametersStringRule());
                              							}
                              							set(
                              								current,
                              								"parameters_max_length",
                              								lv_parameters_max_length_4_0,
                              								"org.xtext.example.mydsl.DomainModel.option_max_length");
                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }


                            }


                            }
                            break;

                    }

                    // InternalDomainModel.g:1611:4: (otherlv_5= ',' ( (lv_parameters_word_set_6_0= ruleoption_word_set ) ) )?
                    int alt24=2;
                    int LA24_0 = input.LA(1);

                    if ( (LA24_0==31) ) {
                        int LA24_1 = input.LA(2);

                        if ( (LA24_1==29) ) {
                            alt24=1;
                        }
                    }
                    switch (alt24) {
                        case 1 :
                            // InternalDomainModel.g:1612:5: otherlv_5= ',' ( (lv_parameters_word_set_6_0= ruleoption_word_set ) )
                            {
                            otherlv_5=(Token)match(input,31,FOLLOW_23); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_5, grammarAccess.getParametersStringAccess().getCommaKeyword_0_3_0());
                              				
                            }
                            // InternalDomainModel.g:1616:5: ( (lv_parameters_word_set_6_0= ruleoption_word_set ) )
                            // InternalDomainModel.g:1617:6: (lv_parameters_word_set_6_0= ruleoption_word_set )
                            {
                            // InternalDomainModel.g:1617:6: (lv_parameters_word_set_6_0= ruleoption_word_set )
                            // InternalDomainModel.g:1618:7: lv_parameters_word_set_6_0= ruleoption_word_set
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getParametersStringAccess().getParameters_word_setOption_word_setParserRuleCall_0_3_1_0());
                              						
                            }
                            pushFollow(FOLLOW_17);
                            lv_parameters_word_set_6_0=ruleoption_word_set();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElementForParent(grammarAccess.getParametersStringRule());
                              							}
                              							set(
                              								current,
                              								"parameters_word_set",
                              								lv_parameters_word_set_6_0,
                              								"org.xtext.example.mydsl.DomainModel.option_word_set");
                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }


                            }


                            }
                            break;

                    }

                    // InternalDomainModel.g:1636:4: (otherlv_7= ',' ( (lv_parameters_condition_8_0= ruleoption_condition ) ) )?
                    int alt25=2;
                    int LA25_0 = input.LA(1);

                    if ( (LA25_0==31) ) {
                        alt25=1;
                    }
                    switch (alt25) {
                        case 1 :
                            // InternalDomainModel.g:1637:5: otherlv_7= ',' ( (lv_parameters_condition_8_0= ruleoption_condition ) )
                            {
                            otherlv_7=(Token)match(input,31,FOLLOW_8); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_7, grammarAccess.getParametersStringAccess().getCommaKeyword_0_4_0());
                              				
                            }
                            // InternalDomainModel.g:1641:5: ( (lv_parameters_condition_8_0= ruleoption_condition ) )
                            // InternalDomainModel.g:1642:6: (lv_parameters_condition_8_0= ruleoption_condition )
                            {
                            // InternalDomainModel.g:1642:6: (lv_parameters_condition_8_0= ruleoption_condition )
                            // InternalDomainModel.g:1643:7: lv_parameters_condition_8_0= ruleoption_condition
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getParametersStringAccess().getParameters_conditionOption_conditionParserRuleCall_0_4_1_0());
                              						
                            }
                            pushFollow(FOLLOW_2);
                            lv_parameters_condition_8_0=ruleoption_condition();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElementForParent(grammarAccess.getParametersStringRule());
                              							}
                              							set(
                              								current,
                              								"parameters_condition",
                              								lv_parameters_condition_8_0,
                              								"org.xtext.example.mydsl.DomainModel.option_condition");
                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }


                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalDomainModel.g:1663:3: ( ( (lv_parameters_min_length_9_0= ruleoption_min_length ) ) (otherlv_10= ',' ( (lv_parameters_max_length_11_0= ruleoption_max_length ) ) )? (otherlv_12= ',' ( (lv_parameters_word_set_13_0= ruleoption_word_set ) ) )? (otherlv_14= ',' ( (lv_parameters_condition_15_0= ruleoption_condition ) ) )? )
                    {
                    // InternalDomainModel.g:1663:3: ( ( (lv_parameters_min_length_9_0= ruleoption_min_length ) ) (otherlv_10= ',' ( (lv_parameters_max_length_11_0= ruleoption_max_length ) ) )? (otherlv_12= ',' ( (lv_parameters_word_set_13_0= ruleoption_word_set ) ) )? (otherlv_14= ',' ( (lv_parameters_condition_15_0= ruleoption_condition ) ) )? )
                    // InternalDomainModel.g:1664:4: ( (lv_parameters_min_length_9_0= ruleoption_min_length ) ) (otherlv_10= ',' ( (lv_parameters_max_length_11_0= ruleoption_max_length ) ) )? (otherlv_12= ',' ( (lv_parameters_word_set_13_0= ruleoption_word_set ) ) )? (otherlv_14= ',' ( (lv_parameters_condition_15_0= ruleoption_condition ) ) )?
                    {
                    // InternalDomainModel.g:1664:4: ( (lv_parameters_min_length_9_0= ruleoption_min_length ) )
                    // InternalDomainModel.g:1665:5: (lv_parameters_min_length_9_0= ruleoption_min_length )
                    {
                    // InternalDomainModel.g:1665:5: (lv_parameters_min_length_9_0= ruleoption_min_length )
                    // InternalDomainModel.g:1666:6: lv_parameters_min_length_9_0= ruleoption_min_length
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getParametersStringAccess().getParameters_min_lengthOption_min_lengthParserRuleCall_1_0_0());
                      					
                    }
                    pushFollow(FOLLOW_17);
                    lv_parameters_min_length_9_0=ruleoption_min_length();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getParametersStringRule());
                      						}
                      						set(
                      							current,
                      							"parameters_min_length",
                      							lv_parameters_min_length_9_0,
                      							"org.xtext.example.mydsl.DomainModel.option_min_length");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:1683:4: (otherlv_10= ',' ( (lv_parameters_max_length_11_0= ruleoption_max_length ) ) )?
                    int alt26=2;
                    int LA26_0 = input.LA(1);

                    if ( (LA26_0==31) ) {
                        int LA26_1 = input.LA(2);

                        if ( (LA26_1==27) ) {
                            alt26=1;
                        }
                    }
                    switch (alt26) {
                        case 1 :
                            // InternalDomainModel.g:1684:5: otherlv_10= ',' ( (lv_parameters_max_length_11_0= ruleoption_max_length ) )
                            {
                            otherlv_10=(Token)match(input,31,FOLLOW_21); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_10, grammarAccess.getParametersStringAccess().getCommaKeyword_1_1_0());
                              				
                            }
                            // InternalDomainModel.g:1688:5: ( (lv_parameters_max_length_11_0= ruleoption_max_length ) )
                            // InternalDomainModel.g:1689:6: (lv_parameters_max_length_11_0= ruleoption_max_length )
                            {
                            // InternalDomainModel.g:1689:6: (lv_parameters_max_length_11_0= ruleoption_max_length )
                            // InternalDomainModel.g:1690:7: lv_parameters_max_length_11_0= ruleoption_max_length
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getParametersStringAccess().getParameters_max_lengthOption_max_lengthParserRuleCall_1_1_1_0());
                              						
                            }
                            pushFollow(FOLLOW_17);
                            lv_parameters_max_length_11_0=ruleoption_max_length();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElementForParent(grammarAccess.getParametersStringRule());
                              							}
                              							set(
                              								current,
                              								"parameters_max_length",
                              								lv_parameters_max_length_11_0,
                              								"org.xtext.example.mydsl.DomainModel.option_max_length");
                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }


                            }


                            }
                            break;

                    }

                    // InternalDomainModel.g:1708:4: (otherlv_12= ',' ( (lv_parameters_word_set_13_0= ruleoption_word_set ) ) )?
                    int alt27=2;
                    int LA27_0 = input.LA(1);

                    if ( (LA27_0==31) ) {
                        int LA27_1 = input.LA(2);

                        if ( (LA27_1==29) ) {
                            alt27=1;
                        }
                    }
                    switch (alt27) {
                        case 1 :
                            // InternalDomainModel.g:1709:5: otherlv_12= ',' ( (lv_parameters_word_set_13_0= ruleoption_word_set ) )
                            {
                            otherlv_12=(Token)match(input,31,FOLLOW_23); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_12, grammarAccess.getParametersStringAccess().getCommaKeyword_1_2_0());
                              				
                            }
                            // InternalDomainModel.g:1713:5: ( (lv_parameters_word_set_13_0= ruleoption_word_set ) )
                            // InternalDomainModel.g:1714:6: (lv_parameters_word_set_13_0= ruleoption_word_set )
                            {
                            // InternalDomainModel.g:1714:6: (lv_parameters_word_set_13_0= ruleoption_word_set )
                            // InternalDomainModel.g:1715:7: lv_parameters_word_set_13_0= ruleoption_word_set
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getParametersStringAccess().getParameters_word_setOption_word_setParserRuleCall_1_2_1_0());
                              						
                            }
                            pushFollow(FOLLOW_17);
                            lv_parameters_word_set_13_0=ruleoption_word_set();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElementForParent(grammarAccess.getParametersStringRule());
                              							}
                              							set(
                              								current,
                              								"parameters_word_set",
                              								lv_parameters_word_set_13_0,
                              								"org.xtext.example.mydsl.DomainModel.option_word_set");
                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }


                            }


                            }
                            break;

                    }

                    // InternalDomainModel.g:1733:4: (otherlv_14= ',' ( (lv_parameters_condition_15_0= ruleoption_condition ) ) )?
                    int alt28=2;
                    int LA28_0 = input.LA(1);

                    if ( (LA28_0==31) ) {
                        alt28=1;
                    }
                    switch (alt28) {
                        case 1 :
                            // InternalDomainModel.g:1734:5: otherlv_14= ',' ( (lv_parameters_condition_15_0= ruleoption_condition ) )
                            {
                            otherlv_14=(Token)match(input,31,FOLLOW_8); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_14, grammarAccess.getParametersStringAccess().getCommaKeyword_1_3_0());
                              				
                            }
                            // InternalDomainModel.g:1738:5: ( (lv_parameters_condition_15_0= ruleoption_condition ) )
                            // InternalDomainModel.g:1739:6: (lv_parameters_condition_15_0= ruleoption_condition )
                            {
                            // InternalDomainModel.g:1739:6: (lv_parameters_condition_15_0= ruleoption_condition )
                            // InternalDomainModel.g:1740:7: lv_parameters_condition_15_0= ruleoption_condition
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getParametersStringAccess().getParameters_conditionOption_conditionParserRuleCall_1_3_1_0());
                              						
                            }
                            pushFollow(FOLLOW_2);
                            lv_parameters_condition_15_0=ruleoption_condition();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElementForParent(grammarAccess.getParametersStringRule());
                              							}
                              							set(
                              								current,
                              								"parameters_condition",
                              								lv_parameters_condition_15_0,
                              								"org.xtext.example.mydsl.DomainModel.option_condition");
                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }


                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalDomainModel.g:1760:3: ( ( (lv_parameters_max_length_16_0= ruleoption_max_length ) ) (otherlv_17= ',' ( (lv_parameters_word_set_18_0= ruleoption_word_set ) ) )? (otherlv_19= ',' ( (lv_parameters_condition_20_0= ruleoption_condition ) ) )? )
                    {
                    // InternalDomainModel.g:1760:3: ( ( (lv_parameters_max_length_16_0= ruleoption_max_length ) ) (otherlv_17= ',' ( (lv_parameters_word_set_18_0= ruleoption_word_set ) ) )? (otherlv_19= ',' ( (lv_parameters_condition_20_0= ruleoption_condition ) ) )? )
                    // InternalDomainModel.g:1761:4: ( (lv_parameters_max_length_16_0= ruleoption_max_length ) ) (otherlv_17= ',' ( (lv_parameters_word_set_18_0= ruleoption_word_set ) ) )? (otherlv_19= ',' ( (lv_parameters_condition_20_0= ruleoption_condition ) ) )?
                    {
                    // InternalDomainModel.g:1761:4: ( (lv_parameters_max_length_16_0= ruleoption_max_length ) )
                    // InternalDomainModel.g:1762:5: (lv_parameters_max_length_16_0= ruleoption_max_length )
                    {
                    // InternalDomainModel.g:1762:5: (lv_parameters_max_length_16_0= ruleoption_max_length )
                    // InternalDomainModel.g:1763:6: lv_parameters_max_length_16_0= ruleoption_max_length
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getParametersStringAccess().getParameters_max_lengthOption_max_lengthParserRuleCall_2_0_0());
                      					
                    }
                    pushFollow(FOLLOW_17);
                    lv_parameters_max_length_16_0=ruleoption_max_length();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getParametersStringRule());
                      						}
                      						set(
                      							current,
                      							"parameters_max_length",
                      							lv_parameters_max_length_16_0,
                      							"org.xtext.example.mydsl.DomainModel.option_max_length");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:1780:4: (otherlv_17= ',' ( (lv_parameters_word_set_18_0= ruleoption_word_set ) ) )?
                    int alt29=2;
                    int LA29_0 = input.LA(1);

                    if ( (LA29_0==31) ) {
                        int LA29_1 = input.LA(2);

                        if ( (LA29_1==29) ) {
                            alt29=1;
                        }
                    }
                    switch (alt29) {
                        case 1 :
                            // InternalDomainModel.g:1781:5: otherlv_17= ',' ( (lv_parameters_word_set_18_0= ruleoption_word_set ) )
                            {
                            otherlv_17=(Token)match(input,31,FOLLOW_23); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_17, grammarAccess.getParametersStringAccess().getCommaKeyword_2_1_0());
                              				
                            }
                            // InternalDomainModel.g:1785:5: ( (lv_parameters_word_set_18_0= ruleoption_word_set ) )
                            // InternalDomainModel.g:1786:6: (lv_parameters_word_set_18_0= ruleoption_word_set )
                            {
                            // InternalDomainModel.g:1786:6: (lv_parameters_word_set_18_0= ruleoption_word_set )
                            // InternalDomainModel.g:1787:7: lv_parameters_word_set_18_0= ruleoption_word_set
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getParametersStringAccess().getParameters_word_setOption_word_setParserRuleCall_2_1_1_0());
                              						
                            }
                            pushFollow(FOLLOW_17);
                            lv_parameters_word_set_18_0=ruleoption_word_set();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElementForParent(grammarAccess.getParametersStringRule());
                              							}
                              							set(
                              								current,
                              								"parameters_word_set",
                              								lv_parameters_word_set_18_0,
                              								"org.xtext.example.mydsl.DomainModel.option_word_set");
                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }


                            }


                            }
                            break;

                    }

                    // InternalDomainModel.g:1805:4: (otherlv_19= ',' ( (lv_parameters_condition_20_0= ruleoption_condition ) ) )?
                    int alt30=2;
                    int LA30_0 = input.LA(1);

                    if ( (LA30_0==31) ) {
                        alt30=1;
                    }
                    switch (alt30) {
                        case 1 :
                            // InternalDomainModel.g:1806:5: otherlv_19= ',' ( (lv_parameters_condition_20_0= ruleoption_condition ) )
                            {
                            otherlv_19=(Token)match(input,31,FOLLOW_8); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_19, grammarAccess.getParametersStringAccess().getCommaKeyword_2_2_0());
                              				
                            }
                            // InternalDomainModel.g:1810:5: ( (lv_parameters_condition_20_0= ruleoption_condition ) )
                            // InternalDomainModel.g:1811:6: (lv_parameters_condition_20_0= ruleoption_condition )
                            {
                            // InternalDomainModel.g:1811:6: (lv_parameters_condition_20_0= ruleoption_condition )
                            // InternalDomainModel.g:1812:7: lv_parameters_condition_20_0= ruleoption_condition
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getParametersStringAccess().getParameters_conditionOption_conditionParserRuleCall_2_2_1_0());
                              						
                            }
                            pushFollow(FOLLOW_2);
                            lv_parameters_condition_20_0=ruleoption_condition();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElementForParent(grammarAccess.getParametersStringRule());
                              							}
                              							set(
                              								current,
                              								"parameters_condition",
                              								lv_parameters_condition_20_0,
                              								"org.xtext.example.mydsl.DomainModel.option_condition");
                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }


                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 4 :
                    // InternalDomainModel.g:1832:3: ( ( (lv_parameters_word_set_21_0= ruleoption_word_set ) ) (otherlv_22= ',' ( (lv_parameters_condition_23_0= ruleoption_condition ) ) )? )
                    {
                    // InternalDomainModel.g:1832:3: ( ( (lv_parameters_word_set_21_0= ruleoption_word_set ) ) (otherlv_22= ',' ( (lv_parameters_condition_23_0= ruleoption_condition ) ) )? )
                    // InternalDomainModel.g:1833:4: ( (lv_parameters_word_set_21_0= ruleoption_word_set ) ) (otherlv_22= ',' ( (lv_parameters_condition_23_0= ruleoption_condition ) ) )?
                    {
                    // InternalDomainModel.g:1833:4: ( (lv_parameters_word_set_21_0= ruleoption_word_set ) )
                    // InternalDomainModel.g:1834:5: (lv_parameters_word_set_21_0= ruleoption_word_set )
                    {
                    // InternalDomainModel.g:1834:5: (lv_parameters_word_set_21_0= ruleoption_word_set )
                    // InternalDomainModel.g:1835:6: lv_parameters_word_set_21_0= ruleoption_word_set
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getParametersStringAccess().getParameters_word_setOption_word_setParserRuleCall_3_0_0());
                      					
                    }
                    pushFollow(FOLLOW_17);
                    lv_parameters_word_set_21_0=ruleoption_word_set();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getParametersStringRule());
                      						}
                      						set(
                      							current,
                      							"parameters_word_set",
                      							lv_parameters_word_set_21_0,
                      							"org.xtext.example.mydsl.DomainModel.option_word_set");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:1852:4: (otherlv_22= ',' ( (lv_parameters_condition_23_0= ruleoption_condition ) ) )?
                    int alt31=2;
                    int LA31_0 = input.LA(1);

                    if ( (LA31_0==31) ) {
                        alt31=1;
                    }
                    switch (alt31) {
                        case 1 :
                            // InternalDomainModel.g:1853:5: otherlv_22= ',' ( (lv_parameters_condition_23_0= ruleoption_condition ) )
                            {
                            otherlv_22=(Token)match(input,31,FOLLOW_8); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_22, grammarAccess.getParametersStringAccess().getCommaKeyword_3_1_0());
                              				
                            }
                            // InternalDomainModel.g:1857:5: ( (lv_parameters_condition_23_0= ruleoption_condition ) )
                            // InternalDomainModel.g:1858:6: (lv_parameters_condition_23_0= ruleoption_condition )
                            {
                            // InternalDomainModel.g:1858:6: (lv_parameters_condition_23_0= ruleoption_condition )
                            // InternalDomainModel.g:1859:7: lv_parameters_condition_23_0= ruleoption_condition
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getParametersStringAccess().getParameters_conditionOption_conditionParserRuleCall_3_1_1_0());
                              						
                            }
                            pushFollow(FOLLOW_2);
                            lv_parameters_condition_23_0=ruleoption_condition();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElementForParent(grammarAccess.getParametersStringRule());
                              							}
                              							set(
                              								current,
                              								"parameters_condition",
                              								lv_parameters_condition_23_0,
                              								"org.xtext.example.mydsl.DomainModel.option_condition");
                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }


                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 5 :
                    // InternalDomainModel.g:1879:3: ( (lv_parameters_condition_24_0= ruleoption_condition ) )
                    {
                    // InternalDomainModel.g:1879:3: ( (lv_parameters_condition_24_0= ruleoption_condition ) )
                    // InternalDomainModel.g:1880:4: (lv_parameters_condition_24_0= ruleoption_condition )
                    {
                    // InternalDomainModel.g:1880:4: (lv_parameters_condition_24_0= ruleoption_condition )
                    // InternalDomainModel.g:1881:5: lv_parameters_condition_24_0= ruleoption_condition
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getParametersStringAccess().getParameters_conditionOption_conditionParserRuleCall_4_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_parameters_condition_24_0=ruleoption_condition();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getParametersStringRule());
                      					}
                      					set(
                      						current,
                      						"parameters_condition",
                      						lv_parameters_condition_24_0,
                      						"org.xtext.example.mydsl.DomainModel.option_condition");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleparametersString"


    // $ANTLR start "entryRuleconditional"
    // InternalDomainModel.g:1902:1: entryRuleconditional returns [EObject current=null] : iv_ruleconditional= ruleconditional EOF ;
    public final EObject entryRuleconditional() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleconditional = null;


        try {
            // InternalDomainModel.g:1902:52: (iv_ruleconditional= ruleconditional EOF )
            // InternalDomainModel.g:1903:2: iv_ruleconditional= ruleconditional EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getConditionalRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleconditional=ruleconditional();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleconditional; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleconditional"


    // $ANTLR start "ruleconditional"
    // InternalDomainModel.g:1909:1: ruleconditional returns [EObject current=null] : ( ( ( (lv_igual_0_0= ruleigual_1 ) ) ( (lv_statement_conditionals_1_1_0= ruleconditionals_1 ) ) ) | ( ( (lv_diff_2_0= rulediff_1 ) ) ( (lv_statement_conditionals_1_3_0= ruleconditionals_1 ) ) ) | ( ( (lv_menor_4_0= rulemenor_1 ) ) ( (lv_statement_conditionals_1_5_0= ruleconditionals_1 ) ) ) | ( ( (lv_mayor_6_0= rulemayor_1 ) ) ( (lv_statement_conditionals_1_7_0= ruleconditionals_1 ) ) ) | ( ( (lv_menor_igual_8_0= rulemenor_igual_1 ) ) ( (lv_statement_conditionals_1_9_0= ruleconditionals_1 ) ) ) | ( ( (lv_mayor_igual_10_0= rulemayor_igual_1 ) ) ( (lv_statement_conditionals_1_11_0= ruleconditionals_1 ) ) ) | ( ( (lv_statement_conectores_12_0= ruleconectores ) ) ( (lv_statement_condexpr_13_0= rulecondexpr ) ) ) ) ;
    public final EObject ruleconditional() throws RecognitionException {
        EObject current = null;

        AntlrDatatypeRuleToken lv_igual_0_0 = null;

        EObject lv_statement_conditionals_1_1_0 = null;

        AntlrDatatypeRuleToken lv_diff_2_0 = null;

        EObject lv_statement_conditionals_1_3_0 = null;

        AntlrDatatypeRuleToken lv_menor_4_0 = null;

        EObject lv_statement_conditionals_1_5_0 = null;

        AntlrDatatypeRuleToken lv_mayor_6_0 = null;

        EObject lv_statement_conditionals_1_7_0 = null;

        AntlrDatatypeRuleToken lv_menor_igual_8_0 = null;

        EObject lv_statement_conditionals_1_9_0 = null;

        AntlrDatatypeRuleToken lv_mayor_igual_10_0 = null;

        EObject lv_statement_conditionals_1_11_0 = null;

        EObject lv_statement_conectores_12_0 = null;

        EObject lv_statement_condexpr_13_0 = null;



        	enterRule();

        try {
            // InternalDomainModel.g:1915:2: ( ( ( ( (lv_igual_0_0= ruleigual_1 ) ) ( (lv_statement_conditionals_1_1_0= ruleconditionals_1 ) ) ) | ( ( (lv_diff_2_0= rulediff_1 ) ) ( (lv_statement_conditionals_1_3_0= ruleconditionals_1 ) ) ) | ( ( (lv_menor_4_0= rulemenor_1 ) ) ( (lv_statement_conditionals_1_5_0= ruleconditionals_1 ) ) ) | ( ( (lv_mayor_6_0= rulemayor_1 ) ) ( (lv_statement_conditionals_1_7_0= ruleconditionals_1 ) ) ) | ( ( (lv_menor_igual_8_0= rulemenor_igual_1 ) ) ( (lv_statement_conditionals_1_9_0= ruleconditionals_1 ) ) ) | ( ( (lv_mayor_igual_10_0= rulemayor_igual_1 ) ) ( (lv_statement_conditionals_1_11_0= ruleconditionals_1 ) ) ) | ( ( (lv_statement_conectores_12_0= ruleconectores ) ) ( (lv_statement_condexpr_13_0= rulecondexpr ) ) ) ) )
            // InternalDomainModel.g:1916:2: ( ( ( (lv_igual_0_0= ruleigual_1 ) ) ( (lv_statement_conditionals_1_1_0= ruleconditionals_1 ) ) ) | ( ( (lv_diff_2_0= rulediff_1 ) ) ( (lv_statement_conditionals_1_3_0= ruleconditionals_1 ) ) ) | ( ( (lv_menor_4_0= rulemenor_1 ) ) ( (lv_statement_conditionals_1_5_0= ruleconditionals_1 ) ) ) | ( ( (lv_mayor_6_0= rulemayor_1 ) ) ( (lv_statement_conditionals_1_7_0= ruleconditionals_1 ) ) ) | ( ( (lv_menor_igual_8_0= rulemenor_igual_1 ) ) ( (lv_statement_conditionals_1_9_0= ruleconditionals_1 ) ) ) | ( ( (lv_mayor_igual_10_0= rulemayor_igual_1 ) ) ( (lv_statement_conditionals_1_11_0= ruleconditionals_1 ) ) ) | ( ( (lv_statement_conectores_12_0= ruleconectores ) ) ( (lv_statement_condexpr_13_0= rulecondexpr ) ) ) )
            {
            // InternalDomainModel.g:1916:2: ( ( ( (lv_igual_0_0= ruleigual_1 ) ) ( (lv_statement_conditionals_1_1_0= ruleconditionals_1 ) ) ) | ( ( (lv_diff_2_0= rulediff_1 ) ) ( (lv_statement_conditionals_1_3_0= ruleconditionals_1 ) ) ) | ( ( (lv_menor_4_0= rulemenor_1 ) ) ( (lv_statement_conditionals_1_5_0= ruleconditionals_1 ) ) ) | ( ( (lv_mayor_6_0= rulemayor_1 ) ) ( (lv_statement_conditionals_1_7_0= ruleconditionals_1 ) ) ) | ( ( (lv_menor_igual_8_0= rulemenor_igual_1 ) ) ( (lv_statement_conditionals_1_9_0= ruleconditionals_1 ) ) ) | ( ( (lv_mayor_igual_10_0= rulemayor_igual_1 ) ) ( (lv_statement_conditionals_1_11_0= ruleconditionals_1 ) ) ) | ( ( (lv_statement_conectores_12_0= ruleconectores ) ) ( (lv_statement_condexpr_13_0= rulecondexpr ) ) ) )
            int alt33=7;
            switch ( input.LA(1) ) {
            case 33:
                {
                alt33=1;
                }
                break;
            case 34:
                {
                alt33=2;
                }
                break;
            case 35:
                {
                alt33=3;
                }
                break;
            case 36:
                {
                alt33=4;
                }
                break;
            case 37:
                {
                alt33=5;
                }
                break;
            case 38:
                {
                alt33=6;
                }
                break;
            case 40:
            case 41:
                {
                alt33=7;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 33, 0, input);

                throw nvae;
            }

            switch (alt33) {
                case 1 :
                    // InternalDomainModel.g:1917:3: ( ( (lv_igual_0_0= ruleigual_1 ) ) ( (lv_statement_conditionals_1_1_0= ruleconditionals_1 ) ) )
                    {
                    // InternalDomainModel.g:1917:3: ( ( (lv_igual_0_0= ruleigual_1 ) ) ( (lv_statement_conditionals_1_1_0= ruleconditionals_1 ) ) )
                    // InternalDomainModel.g:1918:4: ( (lv_igual_0_0= ruleigual_1 ) ) ( (lv_statement_conditionals_1_1_0= ruleconditionals_1 ) )
                    {
                    // InternalDomainModel.g:1918:4: ( (lv_igual_0_0= ruleigual_1 ) )
                    // InternalDomainModel.g:1919:5: (lv_igual_0_0= ruleigual_1 )
                    {
                    // InternalDomainModel.g:1919:5: (lv_igual_0_0= ruleigual_1 )
                    // InternalDomainModel.g:1920:6: lv_igual_0_0= ruleigual_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionalAccess().getIgualIgual_1ParserRuleCall_0_0_0());
                      					
                    }
                    pushFollow(FOLLOW_24);
                    lv_igual_0_0=ruleigual_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionalRule());
                      						}
                      						set(
                      							current,
                      							"igual",
                      							lv_igual_0_0,
                      							"org.xtext.example.mydsl.DomainModel.igual_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:1937:4: ( (lv_statement_conditionals_1_1_0= ruleconditionals_1 ) )
                    // InternalDomainModel.g:1938:5: (lv_statement_conditionals_1_1_0= ruleconditionals_1 )
                    {
                    // InternalDomainModel.g:1938:5: (lv_statement_conditionals_1_1_0= ruleconditionals_1 )
                    // InternalDomainModel.g:1939:6: lv_statement_conditionals_1_1_0= ruleconditionals_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionalAccess().getStatement_conditionals_1Conditionals_1ParserRuleCall_0_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_conditionals_1_1_0=ruleconditionals_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionalRule());
                      						}
                      						set(
                      							current,
                      							"statement_conditionals_1",
                      							lv_statement_conditionals_1_1_0,
                      							"org.xtext.example.mydsl.DomainModel.conditionals_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalDomainModel.g:1958:3: ( ( (lv_diff_2_0= rulediff_1 ) ) ( (lv_statement_conditionals_1_3_0= ruleconditionals_1 ) ) )
                    {
                    // InternalDomainModel.g:1958:3: ( ( (lv_diff_2_0= rulediff_1 ) ) ( (lv_statement_conditionals_1_3_0= ruleconditionals_1 ) ) )
                    // InternalDomainModel.g:1959:4: ( (lv_diff_2_0= rulediff_1 ) ) ( (lv_statement_conditionals_1_3_0= ruleconditionals_1 ) )
                    {
                    // InternalDomainModel.g:1959:4: ( (lv_diff_2_0= rulediff_1 ) )
                    // InternalDomainModel.g:1960:5: (lv_diff_2_0= rulediff_1 )
                    {
                    // InternalDomainModel.g:1960:5: (lv_diff_2_0= rulediff_1 )
                    // InternalDomainModel.g:1961:6: lv_diff_2_0= rulediff_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionalAccess().getDiffDiff_1ParserRuleCall_1_0_0());
                      					
                    }
                    pushFollow(FOLLOW_24);
                    lv_diff_2_0=rulediff_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionalRule());
                      						}
                      						set(
                      							current,
                      							"diff",
                      							lv_diff_2_0,
                      							"org.xtext.example.mydsl.DomainModel.diff_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:1978:4: ( (lv_statement_conditionals_1_3_0= ruleconditionals_1 ) )
                    // InternalDomainModel.g:1979:5: (lv_statement_conditionals_1_3_0= ruleconditionals_1 )
                    {
                    // InternalDomainModel.g:1979:5: (lv_statement_conditionals_1_3_0= ruleconditionals_1 )
                    // InternalDomainModel.g:1980:6: lv_statement_conditionals_1_3_0= ruleconditionals_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionalAccess().getStatement_conditionals_1Conditionals_1ParserRuleCall_1_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_conditionals_1_3_0=ruleconditionals_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionalRule());
                      						}
                      						set(
                      							current,
                      							"statement_conditionals_1",
                      							lv_statement_conditionals_1_3_0,
                      							"org.xtext.example.mydsl.DomainModel.conditionals_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalDomainModel.g:1999:3: ( ( (lv_menor_4_0= rulemenor_1 ) ) ( (lv_statement_conditionals_1_5_0= ruleconditionals_1 ) ) )
                    {
                    // InternalDomainModel.g:1999:3: ( ( (lv_menor_4_0= rulemenor_1 ) ) ( (lv_statement_conditionals_1_5_0= ruleconditionals_1 ) ) )
                    // InternalDomainModel.g:2000:4: ( (lv_menor_4_0= rulemenor_1 ) ) ( (lv_statement_conditionals_1_5_0= ruleconditionals_1 ) )
                    {
                    // InternalDomainModel.g:2000:4: ( (lv_menor_4_0= rulemenor_1 ) )
                    // InternalDomainModel.g:2001:5: (lv_menor_4_0= rulemenor_1 )
                    {
                    // InternalDomainModel.g:2001:5: (lv_menor_4_0= rulemenor_1 )
                    // InternalDomainModel.g:2002:6: lv_menor_4_0= rulemenor_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionalAccess().getMenorMenor_1ParserRuleCall_2_0_0());
                      					
                    }
                    pushFollow(FOLLOW_24);
                    lv_menor_4_0=rulemenor_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionalRule());
                      						}
                      						set(
                      							current,
                      							"menor",
                      							lv_menor_4_0,
                      							"org.xtext.example.mydsl.DomainModel.menor_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2019:4: ( (lv_statement_conditionals_1_5_0= ruleconditionals_1 ) )
                    // InternalDomainModel.g:2020:5: (lv_statement_conditionals_1_5_0= ruleconditionals_1 )
                    {
                    // InternalDomainModel.g:2020:5: (lv_statement_conditionals_1_5_0= ruleconditionals_1 )
                    // InternalDomainModel.g:2021:6: lv_statement_conditionals_1_5_0= ruleconditionals_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionalAccess().getStatement_conditionals_1Conditionals_1ParserRuleCall_2_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_conditionals_1_5_0=ruleconditionals_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionalRule());
                      						}
                      						set(
                      							current,
                      							"statement_conditionals_1",
                      							lv_statement_conditionals_1_5_0,
                      							"org.xtext.example.mydsl.DomainModel.conditionals_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 4 :
                    // InternalDomainModel.g:2040:3: ( ( (lv_mayor_6_0= rulemayor_1 ) ) ( (lv_statement_conditionals_1_7_0= ruleconditionals_1 ) ) )
                    {
                    // InternalDomainModel.g:2040:3: ( ( (lv_mayor_6_0= rulemayor_1 ) ) ( (lv_statement_conditionals_1_7_0= ruleconditionals_1 ) ) )
                    // InternalDomainModel.g:2041:4: ( (lv_mayor_6_0= rulemayor_1 ) ) ( (lv_statement_conditionals_1_7_0= ruleconditionals_1 ) )
                    {
                    // InternalDomainModel.g:2041:4: ( (lv_mayor_6_0= rulemayor_1 ) )
                    // InternalDomainModel.g:2042:5: (lv_mayor_6_0= rulemayor_1 )
                    {
                    // InternalDomainModel.g:2042:5: (lv_mayor_6_0= rulemayor_1 )
                    // InternalDomainModel.g:2043:6: lv_mayor_6_0= rulemayor_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionalAccess().getMayorMayor_1ParserRuleCall_3_0_0());
                      					
                    }
                    pushFollow(FOLLOW_24);
                    lv_mayor_6_0=rulemayor_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionalRule());
                      						}
                      						set(
                      							current,
                      							"mayor",
                      							lv_mayor_6_0,
                      							"org.xtext.example.mydsl.DomainModel.mayor_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2060:4: ( (lv_statement_conditionals_1_7_0= ruleconditionals_1 ) )
                    // InternalDomainModel.g:2061:5: (lv_statement_conditionals_1_7_0= ruleconditionals_1 )
                    {
                    // InternalDomainModel.g:2061:5: (lv_statement_conditionals_1_7_0= ruleconditionals_1 )
                    // InternalDomainModel.g:2062:6: lv_statement_conditionals_1_7_0= ruleconditionals_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionalAccess().getStatement_conditionals_1Conditionals_1ParserRuleCall_3_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_conditionals_1_7_0=ruleconditionals_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionalRule());
                      						}
                      						set(
                      							current,
                      							"statement_conditionals_1",
                      							lv_statement_conditionals_1_7_0,
                      							"org.xtext.example.mydsl.DomainModel.conditionals_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 5 :
                    // InternalDomainModel.g:2081:3: ( ( (lv_menor_igual_8_0= rulemenor_igual_1 ) ) ( (lv_statement_conditionals_1_9_0= ruleconditionals_1 ) ) )
                    {
                    // InternalDomainModel.g:2081:3: ( ( (lv_menor_igual_8_0= rulemenor_igual_1 ) ) ( (lv_statement_conditionals_1_9_0= ruleconditionals_1 ) ) )
                    // InternalDomainModel.g:2082:4: ( (lv_menor_igual_8_0= rulemenor_igual_1 ) ) ( (lv_statement_conditionals_1_9_0= ruleconditionals_1 ) )
                    {
                    // InternalDomainModel.g:2082:4: ( (lv_menor_igual_8_0= rulemenor_igual_1 ) )
                    // InternalDomainModel.g:2083:5: (lv_menor_igual_8_0= rulemenor_igual_1 )
                    {
                    // InternalDomainModel.g:2083:5: (lv_menor_igual_8_0= rulemenor_igual_1 )
                    // InternalDomainModel.g:2084:6: lv_menor_igual_8_0= rulemenor_igual_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionalAccess().getMenor_igualMenor_igual_1ParserRuleCall_4_0_0());
                      					
                    }
                    pushFollow(FOLLOW_24);
                    lv_menor_igual_8_0=rulemenor_igual_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionalRule());
                      						}
                      						set(
                      							current,
                      							"menor_igual",
                      							lv_menor_igual_8_0,
                      							"org.xtext.example.mydsl.DomainModel.menor_igual_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2101:4: ( (lv_statement_conditionals_1_9_0= ruleconditionals_1 ) )
                    // InternalDomainModel.g:2102:5: (lv_statement_conditionals_1_9_0= ruleconditionals_1 )
                    {
                    // InternalDomainModel.g:2102:5: (lv_statement_conditionals_1_9_0= ruleconditionals_1 )
                    // InternalDomainModel.g:2103:6: lv_statement_conditionals_1_9_0= ruleconditionals_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionalAccess().getStatement_conditionals_1Conditionals_1ParserRuleCall_4_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_conditionals_1_9_0=ruleconditionals_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionalRule());
                      						}
                      						set(
                      							current,
                      							"statement_conditionals_1",
                      							lv_statement_conditionals_1_9_0,
                      							"org.xtext.example.mydsl.DomainModel.conditionals_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 6 :
                    // InternalDomainModel.g:2122:3: ( ( (lv_mayor_igual_10_0= rulemayor_igual_1 ) ) ( (lv_statement_conditionals_1_11_0= ruleconditionals_1 ) ) )
                    {
                    // InternalDomainModel.g:2122:3: ( ( (lv_mayor_igual_10_0= rulemayor_igual_1 ) ) ( (lv_statement_conditionals_1_11_0= ruleconditionals_1 ) ) )
                    // InternalDomainModel.g:2123:4: ( (lv_mayor_igual_10_0= rulemayor_igual_1 ) ) ( (lv_statement_conditionals_1_11_0= ruleconditionals_1 ) )
                    {
                    // InternalDomainModel.g:2123:4: ( (lv_mayor_igual_10_0= rulemayor_igual_1 ) )
                    // InternalDomainModel.g:2124:5: (lv_mayor_igual_10_0= rulemayor_igual_1 )
                    {
                    // InternalDomainModel.g:2124:5: (lv_mayor_igual_10_0= rulemayor_igual_1 )
                    // InternalDomainModel.g:2125:6: lv_mayor_igual_10_0= rulemayor_igual_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionalAccess().getMayor_igualMayor_igual_1ParserRuleCall_5_0_0());
                      					
                    }
                    pushFollow(FOLLOW_24);
                    lv_mayor_igual_10_0=rulemayor_igual_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionalRule());
                      						}
                      						set(
                      							current,
                      							"mayor_igual",
                      							lv_mayor_igual_10_0,
                      							"org.xtext.example.mydsl.DomainModel.mayor_igual_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2142:4: ( (lv_statement_conditionals_1_11_0= ruleconditionals_1 ) )
                    // InternalDomainModel.g:2143:5: (lv_statement_conditionals_1_11_0= ruleconditionals_1 )
                    {
                    // InternalDomainModel.g:2143:5: (lv_statement_conditionals_1_11_0= ruleconditionals_1 )
                    // InternalDomainModel.g:2144:6: lv_statement_conditionals_1_11_0= ruleconditionals_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionalAccess().getStatement_conditionals_1Conditionals_1ParserRuleCall_5_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_conditionals_1_11_0=ruleconditionals_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionalRule());
                      						}
                      						set(
                      							current,
                      							"statement_conditionals_1",
                      							lv_statement_conditionals_1_11_0,
                      							"org.xtext.example.mydsl.DomainModel.conditionals_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 7 :
                    // InternalDomainModel.g:2163:3: ( ( (lv_statement_conectores_12_0= ruleconectores ) ) ( (lv_statement_condexpr_13_0= rulecondexpr ) ) )
                    {
                    // InternalDomainModel.g:2163:3: ( ( (lv_statement_conectores_12_0= ruleconectores ) ) ( (lv_statement_condexpr_13_0= rulecondexpr ) ) )
                    // InternalDomainModel.g:2164:4: ( (lv_statement_conectores_12_0= ruleconectores ) ) ( (lv_statement_condexpr_13_0= rulecondexpr ) )
                    {
                    // InternalDomainModel.g:2164:4: ( (lv_statement_conectores_12_0= ruleconectores ) )
                    // InternalDomainModel.g:2165:5: (lv_statement_conectores_12_0= ruleconectores )
                    {
                    // InternalDomainModel.g:2165:5: (lv_statement_conectores_12_0= ruleconectores )
                    // InternalDomainModel.g:2166:6: lv_statement_conectores_12_0= ruleconectores
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionalAccess().getStatement_conectoresConectoresParserRuleCall_6_0_0());
                      					
                    }
                    pushFollow(FOLLOW_24);
                    lv_statement_conectores_12_0=ruleconectores();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionalRule());
                      						}
                      						set(
                      							current,
                      							"statement_conectores",
                      							lv_statement_conectores_12_0,
                      							"org.xtext.example.mydsl.DomainModel.conectores");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2183:4: ( (lv_statement_condexpr_13_0= rulecondexpr ) )
                    // InternalDomainModel.g:2184:5: (lv_statement_condexpr_13_0= rulecondexpr )
                    {
                    // InternalDomainModel.g:2184:5: (lv_statement_condexpr_13_0= rulecondexpr )
                    // InternalDomainModel.g:2185:6: lv_statement_condexpr_13_0= rulecondexpr
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionalAccess().getStatement_condexprCondexprParserRuleCall_6_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_condexpr_13_0=rulecondexpr();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionalRule());
                      						}
                      						set(
                      							current,
                      							"statement_condexpr",
                      							lv_statement_condexpr_13_0,
                      							"org.xtext.example.mydsl.DomainModel.condexpr");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleconditional"


    // $ANTLR start "entryRuleigual_1"
    // InternalDomainModel.g:2207:1: entryRuleigual_1 returns [String current=null] : iv_ruleigual_1= ruleigual_1 EOF ;
    public final String entryRuleigual_1() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleigual_1 = null;


        try {
            // InternalDomainModel.g:2207:47: (iv_ruleigual_1= ruleigual_1 EOF )
            // InternalDomainModel.g:2208:2: iv_ruleigual_1= ruleigual_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getIgual_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleigual_1=ruleigual_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleigual_1.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleigual_1"


    // $ANTLR start "ruleigual_1"
    // InternalDomainModel.g:2214:1: ruleigual_1 returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= '==' ;
    public final AntlrDatatypeRuleToken ruleigual_1() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalDomainModel.g:2220:2: (kw= '==' )
            // InternalDomainModel.g:2221:2: kw= '=='
            {
            kw=(Token)match(input,33,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current.merge(kw);
              		newLeafNode(kw, grammarAccess.getIgual_1Access().getEqualsSignEqualsSignKeyword());
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleigual_1"


    // $ANTLR start "entryRulediff_1"
    // InternalDomainModel.g:2229:1: entryRulediff_1 returns [String current=null] : iv_rulediff_1= rulediff_1 EOF ;
    public final String entryRulediff_1() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_rulediff_1 = null;


        try {
            // InternalDomainModel.g:2229:46: (iv_rulediff_1= rulediff_1 EOF )
            // InternalDomainModel.g:2230:2: iv_rulediff_1= rulediff_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getDiff_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulediff_1=rulediff_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulediff_1.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulediff_1"


    // $ANTLR start "rulediff_1"
    // InternalDomainModel.g:2236:1: rulediff_1 returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= '!=' ;
    public final AntlrDatatypeRuleToken rulediff_1() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalDomainModel.g:2242:2: (kw= '!=' )
            // InternalDomainModel.g:2243:2: kw= '!='
            {
            kw=(Token)match(input,34,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current.merge(kw);
              		newLeafNode(kw, grammarAccess.getDiff_1Access().getExclamationMarkEqualsSignKeyword());
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulediff_1"


    // $ANTLR start "entryRulemenor_1"
    // InternalDomainModel.g:2251:1: entryRulemenor_1 returns [String current=null] : iv_rulemenor_1= rulemenor_1 EOF ;
    public final String entryRulemenor_1() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_rulemenor_1 = null;


        try {
            // InternalDomainModel.g:2251:47: (iv_rulemenor_1= rulemenor_1 EOF )
            // InternalDomainModel.g:2252:2: iv_rulemenor_1= rulemenor_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getMenor_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulemenor_1=rulemenor_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulemenor_1.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulemenor_1"


    // $ANTLR start "rulemenor_1"
    // InternalDomainModel.g:2258:1: rulemenor_1 returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= '<' ;
    public final AntlrDatatypeRuleToken rulemenor_1() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalDomainModel.g:2264:2: (kw= '<' )
            // InternalDomainModel.g:2265:2: kw= '<'
            {
            kw=(Token)match(input,35,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current.merge(kw);
              		newLeafNode(kw, grammarAccess.getMenor_1Access().getLessThanSignKeyword());
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulemenor_1"


    // $ANTLR start "entryRulemayor_1"
    // InternalDomainModel.g:2273:1: entryRulemayor_1 returns [String current=null] : iv_rulemayor_1= rulemayor_1 EOF ;
    public final String entryRulemayor_1() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_rulemayor_1 = null;


        try {
            // InternalDomainModel.g:2273:47: (iv_rulemayor_1= rulemayor_1 EOF )
            // InternalDomainModel.g:2274:2: iv_rulemayor_1= rulemayor_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getMayor_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulemayor_1=rulemayor_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulemayor_1.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulemayor_1"


    // $ANTLR start "rulemayor_1"
    // InternalDomainModel.g:2280:1: rulemayor_1 returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= '>' ;
    public final AntlrDatatypeRuleToken rulemayor_1() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalDomainModel.g:2286:2: (kw= '>' )
            // InternalDomainModel.g:2287:2: kw= '>'
            {
            kw=(Token)match(input,36,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current.merge(kw);
              		newLeafNode(kw, grammarAccess.getMayor_1Access().getGreaterThanSignKeyword());
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulemayor_1"


    // $ANTLR start "entryRulemenor_igual_1"
    // InternalDomainModel.g:2295:1: entryRulemenor_igual_1 returns [String current=null] : iv_rulemenor_igual_1= rulemenor_igual_1 EOF ;
    public final String entryRulemenor_igual_1() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_rulemenor_igual_1 = null;


        try {
            // InternalDomainModel.g:2295:53: (iv_rulemenor_igual_1= rulemenor_igual_1 EOF )
            // InternalDomainModel.g:2296:2: iv_rulemenor_igual_1= rulemenor_igual_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getMenor_igual_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulemenor_igual_1=rulemenor_igual_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulemenor_igual_1.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulemenor_igual_1"


    // $ANTLR start "rulemenor_igual_1"
    // InternalDomainModel.g:2302:1: rulemenor_igual_1 returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= '<=' ;
    public final AntlrDatatypeRuleToken rulemenor_igual_1() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalDomainModel.g:2308:2: (kw= '<=' )
            // InternalDomainModel.g:2309:2: kw= '<='
            {
            kw=(Token)match(input,37,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current.merge(kw);
              		newLeafNode(kw, grammarAccess.getMenor_igual_1Access().getLessThanSignEqualsSignKeyword());
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulemenor_igual_1"


    // $ANTLR start "entryRulemayor_igual_1"
    // InternalDomainModel.g:2317:1: entryRulemayor_igual_1 returns [String current=null] : iv_rulemayor_igual_1= rulemayor_igual_1 EOF ;
    public final String entryRulemayor_igual_1() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_rulemayor_igual_1 = null;


        try {
            // InternalDomainModel.g:2317:53: (iv_rulemayor_igual_1= rulemayor_igual_1 EOF )
            // InternalDomainModel.g:2318:2: iv_rulemayor_igual_1= rulemayor_igual_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getMayor_igual_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulemayor_igual_1=rulemayor_igual_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulemayor_igual_1.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulemayor_igual_1"


    // $ANTLR start "rulemayor_igual_1"
    // InternalDomainModel.g:2324:1: rulemayor_igual_1 returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= '>=' ;
    public final AntlrDatatypeRuleToken rulemayor_igual_1() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalDomainModel.g:2330:2: (kw= '>=' )
            // InternalDomainModel.g:2331:2: kw= '>='
            {
            kw=(Token)match(input,38,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current.merge(kw);
              		newLeafNode(kw, grammarAccess.getMayor_igual_1Access().getGreaterThanSignEqualsSignKeyword());
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulemayor_igual_1"


    // $ANTLR start "entryRulecondexpr"
    // InternalDomainModel.g:2339:1: entryRulecondexpr returns [EObject current=null] : iv_rulecondexpr= rulecondexpr EOF ;
    public final EObject entryRulecondexpr() throws RecognitionException {
        EObject current = null;

        EObject iv_rulecondexpr = null;


        try {
            // InternalDomainModel.g:2339:49: (iv_rulecondexpr= rulecondexpr EOF )
            // InternalDomainModel.g:2340:2: iv_rulecondexpr= rulecondexpr EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getCondexprRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulecondexpr=rulecondexpr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulecondexpr; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulecondexpr"


    // $ANTLR start "rulecondexpr"
    // InternalDomainModel.g:2346:1: rulecondexpr returns [EObject current=null] : ( ( ( (lv_not_0_0= rulenot_1 ) ) ( (lv_open_1_0= ruleopen_1 ) ) ( (lv_statement_condexprs_2_0= rulecondexpr ) ) ( (lv_close_3_0= ruleclose_1 ) ) ( (lv_statement_conditional_4_0= ruleconditional ) )? ) | ( ( (lv_open_5_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) ) ) | ( ( (lv_statement_arith_7_0= rulearith ) ) ( (lv_statement_conditional_8_0= ruleconditional ) ) ) ) ;
    public final EObject rulecondexpr() throws RecognitionException {
        EObject current = null;

        AntlrDatatypeRuleToken lv_not_0_0 = null;

        AntlrDatatypeRuleToken lv_open_1_0 = null;

        EObject lv_statement_condexprs_2_0 = null;

        AntlrDatatypeRuleToken lv_close_3_0 = null;

        EObject lv_statement_conditional_4_0 = null;

        AntlrDatatypeRuleToken lv_open_5_0 = null;

        EObject lv_statement_aux_condexpr_6_0 = null;

        EObject lv_statement_arith_7_0 = null;

        EObject lv_statement_conditional_8_0 = null;



        	enterRule();

        try {
            // InternalDomainModel.g:2352:2: ( ( ( ( (lv_not_0_0= rulenot_1 ) ) ( (lv_open_1_0= ruleopen_1 ) ) ( (lv_statement_condexprs_2_0= rulecondexpr ) ) ( (lv_close_3_0= ruleclose_1 ) ) ( (lv_statement_conditional_4_0= ruleconditional ) )? ) | ( ( (lv_open_5_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) ) ) | ( ( (lv_statement_arith_7_0= rulearith ) ) ( (lv_statement_conditional_8_0= ruleconditional ) ) ) ) )
            // InternalDomainModel.g:2353:2: ( ( ( (lv_not_0_0= rulenot_1 ) ) ( (lv_open_1_0= ruleopen_1 ) ) ( (lv_statement_condexprs_2_0= rulecondexpr ) ) ( (lv_close_3_0= ruleclose_1 ) ) ( (lv_statement_conditional_4_0= ruleconditional ) )? ) | ( ( (lv_open_5_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) ) ) | ( ( (lv_statement_arith_7_0= rulearith ) ) ( (lv_statement_conditional_8_0= ruleconditional ) ) ) )
            {
            // InternalDomainModel.g:2353:2: ( ( ( (lv_not_0_0= rulenot_1 ) ) ( (lv_open_1_0= ruleopen_1 ) ) ( (lv_statement_condexprs_2_0= rulecondexpr ) ) ( (lv_close_3_0= ruleclose_1 ) ) ( (lv_statement_conditional_4_0= ruleconditional ) )? ) | ( ( (lv_open_5_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) ) ) | ( ( (lv_statement_arith_7_0= rulearith ) ) ( (lv_statement_conditional_8_0= ruleconditional ) ) ) )
            int alt35=3;
            switch ( input.LA(1) ) {
            case 39:
                {
                alt35=1;
                }
                break;
            case 13:
                {
                int LA35_2 = input.LA(2);

                if ( (synpred52_InternalDomainModel()) ) {
                    alt35=2;
                }
                else if ( (true) ) {
                    alt35=3;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 35, 2, input);

                    throw nvae;
                }
                }
                break;
            case RULE_ID:
            case RULE_INT:
            case RULE_DOUBLE:
            case 44:
            case 45:
                {
                alt35=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 35, 0, input);

                throw nvae;
            }

            switch (alt35) {
                case 1 :
                    // InternalDomainModel.g:2354:3: ( ( (lv_not_0_0= rulenot_1 ) ) ( (lv_open_1_0= ruleopen_1 ) ) ( (lv_statement_condexprs_2_0= rulecondexpr ) ) ( (lv_close_3_0= ruleclose_1 ) ) ( (lv_statement_conditional_4_0= ruleconditional ) )? )
                    {
                    // InternalDomainModel.g:2354:3: ( ( (lv_not_0_0= rulenot_1 ) ) ( (lv_open_1_0= ruleopen_1 ) ) ( (lv_statement_condexprs_2_0= rulecondexpr ) ) ( (lv_close_3_0= ruleclose_1 ) ) ( (lv_statement_conditional_4_0= ruleconditional ) )? )
                    // InternalDomainModel.g:2355:4: ( (lv_not_0_0= rulenot_1 ) ) ( (lv_open_1_0= ruleopen_1 ) ) ( (lv_statement_condexprs_2_0= rulecondexpr ) ) ( (lv_close_3_0= ruleclose_1 ) ) ( (lv_statement_conditional_4_0= ruleconditional ) )?
                    {
                    // InternalDomainModel.g:2355:4: ( (lv_not_0_0= rulenot_1 ) )
                    // InternalDomainModel.g:2356:5: (lv_not_0_0= rulenot_1 )
                    {
                    // InternalDomainModel.g:2356:5: (lv_not_0_0= rulenot_1 )
                    // InternalDomainModel.g:2357:6: lv_not_0_0= rulenot_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getCondexprAccess().getNotNot_1ParserRuleCall_0_0_0());
                      					
                    }
                    pushFollow(FOLLOW_4);
                    lv_not_0_0=rulenot_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getCondexprRule());
                      						}
                      						set(
                      							current,
                      							"not",
                      							lv_not_0_0,
                      							"org.xtext.example.mydsl.DomainModel.not_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2374:4: ( (lv_open_1_0= ruleopen_1 ) )
                    // InternalDomainModel.g:2375:5: (lv_open_1_0= ruleopen_1 )
                    {
                    // InternalDomainModel.g:2375:5: (lv_open_1_0= ruleopen_1 )
                    // InternalDomainModel.g:2376:6: lv_open_1_0= ruleopen_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getCondexprAccess().getOpenOpen_1ParserRuleCall_0_1_0());
                      					
                    }
                    pushFollow(FOLLOW_24);
                    lv_open_1_0=ruleopen_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getCondexprRule());
                      						}
                      						set(
                      							current,
                      							"open",
                      							lv_open_1_0,
                      							"org.xtext.example.mydsl.DomainModel.open_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2393:4: ( (lv_statement_condexprs_2_0= rulecondexpr ) )
                    // InternalDomainModel.g:2394:5: (lv_statement_condexprs_2_0= rulecondexpr )
                    {
                    // InternalDomainModel.g:2394:5: (lv_statement_condexprs_2_0= rulecondexpr )
                    // InternalDomainModel.g:2395:6: lv_statement_condexprs_2_0= rulecondexpr
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getCondexprAccess().getStatement_condexprsCondexprParserRuleCall_0_2_0());
                      					
                    }
                    pushFollow(FOLLOW_6);
                    lv_statement_condexprs_2_0=rulecondexpr();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getCondexprRule());
                      						}
                      						set(
                      							current,
                      							"statement_condexprs",
                      							lv_statement_condexprs_2_0,
                      							"org.xtext.example.mydsl.DomainModel.condexpr");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2412:4: ( (lv_close_3_0= ruleclose_1 ) )
                    // InternalDomainModel.g:2413:5: (lv_close_3_0= ruleclose_1 )
                    {
                    // InternalDomainModel.g:2413:5: (lv_close_3_0= ruleclose_1 )
                    // InternalDomainModel.g:2414:6: lv_close_3_0= ruleclose_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getCondexprAccess().getCloseClose_1ParserRuleCall_0_3_0());
                      					
                    }
                    pushFollow(FOLLOW_25);
                    lv_close_3_0=ruleclose_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getCondexprRule());
                      						}
                      						set(
                      							current,
                      							"close",
                      							lv_close_3_0,
                      							"org.xtext.example.mydsl.DomainModel.close_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2431:4: ( (lv_statement_conditional_4_0= ruleconditional ) )?
                    int alt34=2;
                    alt34 = dfa34.predict(input);
                    switch (alt34) {
                        case 1 :
                            // InternalDomainModel.g:2432:5: (lv_statement_conditional_4_0= ruleconditional )
                            {
                            // InternalDomainModel.g:2432:5: (lv_statement_conditional_4_0= ruleconditional )
                            // InternalDomainModel.g:2433:6: lv_statement_conditional_4_0= ruleconditional
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getCondexprAccess().getStatement_conditionalConditionalParserRuleCall_0_4_0());
                              					
                            }
                            pushFollow(FOLLOW_2);
                            lv_statement_conditional_4_0=ruleconditional();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElementForParent(grammarAccess.getCondexprRule());
                              						}
                              						set(
                              							current,
                              							"statement_conditional",
                              							lv_statement_conditional_4_0,
                              							"org.xtext.example.mydsl.DomainModel.conditional");
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalDomainModel.g:2452:3: ( ( (lv_open_5_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) ) )
                    {
                    // InternalDomainModel.g:2452:3: ( ( (lv_open_5_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) ) )
                    // InternalDomainModel.g:2453:4: ( (lv_open_5_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) )
                    {
                    // InternalDomainModel.g:2453:4: ( (lv_open_5_0= ruleopen_1 ) )
                    // InternalDomainModel.g:2454:5: (lv_open_5_0= ruleopen_1 )
                    {
                    // InternalDomainModel.g:2454:5: (lv_open_5_0= ruleopen_1 )
                    // InternalDomainModel.g:2455:6: lv_open_5_0= ruleopen_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getCondexprAccess().getOpenOpen_1ParserRuleCall_1_0_0());
                      					
                    }
                    pushFollow(FOLLOW_24);
                    lv_open_5_0=ruleopen_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getCondexprRule());
                      						}
                      						set(
                      							current,
                      							"open",
                      							lv_open_5_0,
                      							"org.xtext.example.mydsl.DomainModel.open_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2472:4: ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) )
                    // InternalDomainModel.g:2473:5: (lv_statement_aux_condexpr_6_0= ruleaux_condexpr )
                    {
                    // InternalDomainModel.g:2473:5: (lv_statement_aux_condexpr_6_0= ruleaux_condexpr )
                    // InternalDomainModel.g:2474:6: lv_statement_aux_condexpr_6_0= ruleaux_condexpr
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getCondexprAccess().getStatement_aux_condexprAux_condexprParserRuleCall_1_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_aux_condexpr_6_0=ruleaux_condexpr();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getCondexprRule());
                      						}
                      						set(
                      							current,
                      							"statement_aux_condexpr",
                      							lv_statement_aux_condexpr_6_0,
                      							"org.xtext.example.mydsl.DomainModel.aux_condexpr");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalDomainModel.g:2493:3: ( ( (lv_statement_arith_7_0= rulearith ) ) ( (lv_statement_conditional_8_0= ruleconditional ) ) )
                    {
                    // InternalDomainModel.g:2493:3: ( ( (lv_statement_arith_7_0= rulearith ) ) ( (lv_statement_conditional_8_0= ruleconditional ) ) )
                    // InternalDomainModel.g:2494:4: ( (lv_statement_arith_7_0= rulearith ) ) ( (lv_statement_conditional_8_0= ruleconditional ) )
                    {
                    // InternalDomainModel.g:2494:4: ( (lv_statement_arith_7_0= rulearith ) )
                    // InternalDomainModel.g:2495:5: (lv_statement_arith_7_0= rulearith )
                    {
                    // InternalDomainModel.g:2495:5: (lv_statement_arith_7_0= rulearith )
                    // InternalDomainModel.g:2496:6: lv_statement_arith_7_0= rulearith
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getCondexprAccess().getStatement_arithArithParserRuleCall_2_0_0());
                      					
                    }
                    pushFollow(FOLLOW_26);
                    lv_statement_arith_7_0=rulearith();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getCondexprRule());
                      						}
                      						set(
                      							current,
                      							"statement_arith",
                      							lv_statement_arith_7_0,
                      							"org.xtext.example.mydsl.DomainModel.arith");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2513:4: ( (lv_statement_conditional_8_0= ruleconditional ) )
                    // InternalDomainModel.g:2514:5: (lv_statement_conditional_8_0= ruleconditional )
                    {
                    // InternalDomainModel.g:2514:5: (lv_statement_conditional_8_0= ruleconditional )
                    // InternalDomainModel.g:2515:6: lv_statement_conditional_8_0= ruleconditional
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getCondexprAccess().getStatement_conditionalConditionalParserRuleCall_2_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_conditional_8_0=ruleconditional();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getCondexprRule());
                      						}
                      						set(
                      							current,
                      							"statement_conditional",
                      							lv_statement_conditional_8_0,
                      							"org.xtext.example.mydsl.DomainModel.conditional");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulecondexpr"


    // $ANTLR start "entryRuleconditionals_1"
    // InternalDomainModel.g:2537:1: entryRuleconditionals_1 returns [EObject current=null] : iv_ruleconditionals_1= ruleconditionals_1 EOF ;
    public final EObject entryRuleconditionals_1() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleconditionals_1 = null;


        try {
            // InternalDomainModel.g:2537:55: (iv_ruleconditionals_1= ruleconditionals_1 EOF )
            // InternalDomainModel.g:2538:2: iv_ruleconditionals_1= ruleconditionals_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getConditionals_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleconditionals_1=ruleconditionals_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleconditionals_1; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleconditionals_1"


    // $ANTLR start "ruleconditionals_1"
    // InternalDomainModel.g:2544:1: ruleconditionals_1 returns [EObject current=null] : ( ( ( (lv_open_0_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ) | ( ( (lv_statement_arith_2_0= rulearith ) ) ( (lv_statement_conditional_3_0= ruleconditional ) )? ) | ( ( (lv_not_4_0= rulenot_1 ) ) ( (lv_open_5_0= ruleopen_1 ) ) ( (lv_statement_condexpr_6_0= rulecondexpr ) ) ( (lv_close_7_0= ruleclose_1 ) ) ) ) ;
    public final EObject ruleconditionals_1() throws RecognitionException {
        EObject current = null;

        AntlrDatatypeRuleToken lv_open_0_0 = null;

        EObject lv_statement_aux_condexpr_1_0 = null;

        EObject lv_statement_arith_2_0 = null;

        EObject lv_statement_conditional_3_0 = null;

        AntlrDatatypeRuleToken lv_not_4_0 = null;

        AntlrDatatypeRuleToken lv_open_5_0 = null;

        EObject lv_statement_condexpr_6_0 = null;

        AntlrDatatypeRuleToken lv_close_7_0 = null;



        	enterRule();

        try {
            // InternalDomainModel.g:2550:2: ( ( ( ( (lv_open_0_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ) | ( ( (lv_statement_arith_2_0= rulearith ) ) ( (lv_statement_conditional_3_0= ruleconditional ) )? ) | ( ( (lv_not_4_0= rulenot_1 ) ) ( (lv_open_5_0= ruleopen_1 ) ) ( (lv_statement_condexpr_6_0= rulecondexpr ) ) ( (lv_close_7_0= ruleclose_1 ) ) ) ) )
            // InternalDomainModel.g:2551:2: ( ( ( (lv_open_0_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ) | ( ( (lv_statement_arith_2_0= rulearith ) ) ( (lv_statement_conditional_3_0= ruleconditional ) )? ) | ( ( (lv_not_4_0= rulenot_1 ) ) ( (lv_open_5_0= ruleopen_1 ) ) ( (lv_statement_condexpr_6_0= rulecondexpr ) ) ( (lv_close_7_0= ruleclose_1 ) ) ) )
            {
            // InternalDomainModel.g:2551:2: ( ( ( (lv_open_0_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ) | ( ( (lv_statement_arith_2_0= rulearith ) ) ( (lv_statement_conditional_3_0= ruleconditional ) )? ) | ( ( (lv_not_4_0= rulenot_1 ) ) ( (lv_open_5_0= ruleopen_1 ) ) ( (lv_statement_condexpr_6_0= rulecondexpr ) ) ( (lv_close_7_0= ruleclose_1 ) ) ) )
            int alt37=3;
            switch ( input.LA(1) ) {
            case 13:
                {
                int LA37_1 = input.LA(2);

                if ( (synpred53_InternalDomainModel()) ) {
                    alt37=1;
                }
                else if ( (synpred55_InternalDomainModel()) ) {
                    alt37=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 37, 1, input);

                    throw nvae;
                }
                }
                break;
            case RULE_ID:
            case RULE_INT:
            case RULE_DOUBLE:
            case 44:
            case 45:
                {
                alt37=2;
                }
                break;
            case 39:
                {
                alt37=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 37, 0, input);

                throw nvae;
            }

            switch (alt37) {
                case 1 :
                    // InternalDomainModel.g:2552:3: ( ( (lv_open_0_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) )
                    {
                    // InternalDomainModel.g:2552:3: ( ( (lv_open_0_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) )
                    // InternalDomainModel.g:2553:4: ( (lv_open_0_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) )
                    {
                    // InternalDomainModel.g:2553:4: ( (lv_open_0_0= ruleopen_1 ) )
                    // InternalDomainModel.g:2554:5: (lv_open_0_0= ruleopen_1 )
                    {
                    // InternalDomainModel.g:2554:5: (lv_open_0_0= ruleopen_1 )
                    // InternalDomainModel.g:2555:6: lv_open_0_0= ruleopen_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionals_1Access().getOpenOpen_1ParserRuleCall_0_0_0());
                      					
                    }
                    pushFollow(FOLLOW_24);
                    lv_open_0_0=ruleopen_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionals_1Rule());
                      						}
                      						set(
                      							current,
                      							"open",
                      							lv_open_0_0,
                      							"org.xtext.example.mydsl.DomainModel.open_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2572:4: ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) )
                    // InternalDomainModel.g:2573:5: (lv_statement_aux_condexpr_1_0= ruleaux_condexpr )
                    {
                    // InternalDomainModel.g:2573:5: (lv_statement_aux_condexpr_1_0= ruleaux_condexpr )
                    // InternalDomainModel.g:2574:6: lv_statement_aux_condexpr_1_0= ruleaux_condexpr
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionals_1Access().getStatement_aux_condexprAux_condexprParserRuleCall_0_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_aux_condexpr_1_0=ruleaux_condexpr();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionals_1Rule());
                      						}
                      						set(
                      							current,
                      							"statement_aux_condexpr",
                      							lv_statement_aux_condexpr_1_0,
                      							"org.xtext.example.mydsl.DomainModel.aux_condexpr");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalDomainModel.g:2593:3: ( ( (lv_statement_arith_2_0= rulearith ) ) ( (lv_statement_conditional_3_0= ruleconditional ) )? )
                    {
                    // InternalDomainModel.g:2593:3: ( ( (lv_statement_arith_2_0= rulearith ) ) ( (lv_statement_conditional_3_0= ruleconditional ) )? )
                    // InternalDomainModel.g:2594:4: ( (lv_statement_arith_2_0= rulearith ) ) ( (lv_statement_conditional_3_0= ruleconditional ) )?
                    {
                    // InternalDomainModel.g:2594:4: ( (lv_statement_arith_2_0= rulearith ) )
                    // InternalDomainModel.g:2595:5: (lv_statement_arith_2_0= rulearith )
                    {
                    // InternalDomainModel.g:2595:5: (lv_statement_arith_2_0= rulearith )
                    // InternalDomainModel.g:2596:6: lv_statement_arith_2_0= rulearith
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionals_1Access().getStatement_arithArithParserRuleCall_1_0_0());
                      					
                    }
                    pushFollow(FOLLOW_25);
                    lv_statement_arith_2_0=rulearith();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionals_1Rule());
                      						}
                      						set(
                      							current,
                      							"statement_arith",
                      							lv_statement_arith_2_0,
                      							"org.xtext.example.mydsl.DomainModel.arith");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2613:4: ( (lv_statement_conditional_3_0= ruleconditional ) )?
                    int alt36=2;
                    alt36 = dfa36.predict(input);
                    switch (alt36) {
                        case 1 :
                            // InternalDomainModel.g:2614:5: (lv_statement_conditional_3_0= ruleconditional )
                            {
                            // InternalDomainModel.g:2614:5: (lv_statement_conditional_3_0= ruleconditional )
                            // InternalDomainModel.g:2615:6: lv_statement_conditional_3_0= ruleconditional
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getConditionals_1Access().getStatement_conditionalConditionalParserRuleCall_1_1_0());
                              					
                            }
                            pushFollow(FOLLOW_2);
                            lv_statement_conditional_3_0=ruleconditional();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElementForParent(grammarAccess.getConditionals_1Rule());
                              						}
                              						set(
                              							current,
                              							"statement_conditional",
                              							lv_statement_conditional_3_0,
                              							"org.xtext.example.mydsl.DomainModel.conditional");
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalDomainModel.g:2634:3: ( ( (lv_not_4_0= rulenot_1 ) ) ( (lv_open_5_0= ruleopen_1 ) ) ( (lv_statement_condexpr_6_0= rulecondexpr ) ) ( (lv_close_7_0= ruleclose_1 ) ) )
                    {
                    // InternalDomainModel.g:2634:3: ( ( (lv_not_4_0= rulenot_1 ) ) ( (lv_open_5_0= ruleopen_1 ) ) ( (lv_statement_condexpr_6_0= rulecondexpr ) ) ( (lv_close_7_0= ruleclose_1 ) ) )
                    // InternalDomainModel.g:2635:4: ( (lv_not_4_0= rulenot_1 ) ) ( (lv_open_5_0= ruleopen_1 ) ) ( (lv_statement_condexpr_6_0= rulecondexpr ) ) ( (lv_close_7_0= ruleclose_1 ) )
                    {
                    // InternalDomainModel.g:2635:4: ( (lv_not_4_0= rulenot_1 ) )
                    // InternalDomainModel.g:2636:5: (lv_not_4_0= rulenot_1 )
                    {
                    // InternalDomainModel.g:2636:5: (lv_not_4_0= rulenot_1 )
                    // InternalDomainModel.g:2637:6: lv_not_4_0= rulenot_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionals_1Access().getNotNot_1ParserRuleCall_2_0_0());
                      					
                    }
                    pushFollow(FOLLOW_4);
                    lv_not_4_0=rulenot_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionals_1Rule());
                      						}
                      						set(
                      							current,
                      							"not",
                      							lv_not_4_0,
                      							"org.xtext.example.mydsl.DomainModel.not_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2654:4: ( (lv_open_5_0= ruleopen_1 ) )
                    // InternalDomainModel.g:2655:5: (lv_open_5_0= ruleopen_1 )
                    {
                    // InternalDomainModel.g:2655:5: (lv_open_5_0= ruleopen_1 )
                    // InternalDomainModel.g:2656:6: lv_open_5_0= ruleopen_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionals_1Access().getOpenOpen_1ParserRuleCall_2_1_0());
                      					
                    }
                    pushFollow(FOLLOW_24);
                    lv_open_5_0=ruleopen_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionals_1Rule());
                      						}
                      						set(
                      							current,
                      							"open",
                      							lv_open_5_0,
                      							"org.xtext.example.mydsl.DomainModel.open_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2673:4: ( (lv_statement_condexpr_6_0= rulecondexpr ) )
                    // InternalDomainModel.g:2674:5: (lv_statement_condexpr_6_0= rulecondexpr )
                    {
                    // InternalDomainModel.g:2674:5: (lv_statement_condexpr_6_0= rulecondexpr )
                    // InternalDomainModel.g:2675:6: lv_statement_condexpr_6_0= rulecondexpr
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionals_1Access().getStatement_condexprCondexprParserRuleCall_2_2_0());
                      					
                    }
                    pushFollow(FOLLOW_6);
                    lv_statement_condexpr_6_0=rulecondexpr();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionals_1Rule());
                      						}
                      						set(
                      							current,
                      							"statement_condexpr",
                      							lv_statement_condexpr_6_0,
                      							"org.xtext.example.mydsl.DomainModel.condexpr");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2692:4: ( (lv_close_7_0= ruleclose_1 ) )
                    // InternalDomainModel.g:2693:5: (lv_close_7_0= ruleclose_1 )
                    {
                    // InternalDomainModel.g:2693:5: (lv_close_7_0= ruleclose_1 )
                    // InternalDomainModel.g:2694:6: lv_close_7_0= ruleclose_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getConditionals_1Access().getCloseClose_1ParserRuleCall_2_3_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_close_7_0=ruleclose_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getConditionals_1Rule());
                      						}
                      						set(
                      							current,
                      							"close",
                      							lv_close_7_0,
                      							"org.xtext.example.mydsl.DomainModel.close_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleconditionals_1"


    // $ANTLR start "entryRuleaux_condexpr"
    // InternalDomainModel.g:2716:1: entryRuleaux_condexpr returns [EObject current=null] : iv_ruleaux_condexpr= ruleaux_condexpr EOF ;
    public final EObject entryRuleaux_condexpr() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleaux_condexpr = null;


        try {
            // InternalDomainModel.g:2716:53: (iv_ruleaux_condexpr= ruleaux_condexpr EOF )
            // InternalDomainModel.g:2717:2: iv_ruleaux_condexpr= ruleaux_condexpr EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getAux_condexprRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleaux_condexpr=ruleaux_condexpr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleaux_condexpr; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleaux_condexpr"


    // $ANTLR start "ruleaux_condexpr"
    // InternalDomainModel.g:2723:1: ruleaux_condexpr returns [EObject current=null] : ( ( ( (lv_open_0_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) ) ) | ( ( (lv_statement_arith_3_0= rulearith ) ) ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) ) ) | ( ( (lv_not_5_0= rulenot_1 ) ) ( (lv_open_6_0= ruleopen_1 ) ) ( (lv_statement_condexpr_7_0= rulecondexpr ) ) ( (lv_close_8_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_not_9_0= ruleoptional_parentesis_not ) ) ) ) ;
    public final EObject ruleaux_condexpr() throws RecognitionException {
        EObject current = null;

        AntlrDatatypeRuleToken lv_open_0_0 = null;

        EObject lv_statement_aux_condexpr_1_0 = null;

        EObject lv_statement_optional_parentesis_2_0 = null;

        EObject lv_statement_arith_3_0 = null;

        EObject lv_statement_optional_parentesis_4_0 = null;

        AntlrDatatypeRuleToken lv_not_5_0 = null;

        AntlrDatatypeRuleToken lv_open_6_0 = null;

        EObject lv_statement_condexpr_7_0 = null;

        AntlrDatatypeRuleToken lv_close_8_0 = null;

        EObject lv_statement_optional_parentesis_not_9_0 = null;



        	enterRule();

        try {
            // InternalDomainModel.g:2729:2: ( ( ( ( (lv_open_0_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) ) ) | ( ( (lv_statement_arith_3_0= rulearith ) ) ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) ) ) | ( ( (lv_not_5_0= rulenot_1 ) ) ( (lv_open_6_0= ruleopen_1 ) ) ( (lv_statement_condexpr_7_0= rulecondexpr ) ) ( (lv_close_8_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_not_9_0= ruleoptional_parentesis_not ) ) ) ) )
            // InternalDomainModel.g:2730:2: ( ( ( (lv_open_0_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) ) ) | ( ( (lv_statement_arith_3_0= rulearith ) ) ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) ) ) | ( ( (lv_not_5_0= rulenot_1 ) ) ( (lv_open_6_0= ruleopen_1 ) ) ( (lv_statement_condexpr_7_0= rulecondexpr ) ) ( (lv_close_8_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_not_9_0= ruleoptional_parentesis_not ) ) ) )
            {
            // InternalDomainModel.g:2730:2: ( ( ( (lv_open_0_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) ) ) | ( ( (lv_statement_arith_3_0= rulearith ) ) ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) ) ) | ( ( (lv_not_5_0= rulenot_1 ) ) ( (lv_open_6_0= ruleopen_1 ) ) ( (lv_statement_condexpr_7_0= rulecondexpr ) ) ( (lv_close_8_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_not_9_0= ruleoptional_parentesis_not ) ) ) )
            int alt38=3;
            switch ( input.LA(1) ) {
            case 13:
                {
                int LA38_1 = input.LA(2);

                if ( (synpred56_InternalDomainModel()) ) {
                    alt38=1;
                }
                else if ( (synpred57_InternalDomainModel()) ) {
                    alt38=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 38, 1, input);

                    throw nvae;
                }
                }
                break;
            case RULE_ID:
            case RULE_INT:
            case RULE_DOUBLE:
            case 44:
            case 45:
                {
                alt38=2;
                }
                break;
            case 39:
                {
                alt38=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 38, 0, input);

                throw nvae;
            }

            switch (alt38) {
                case 1 :
                    // InternalDomainModel.g:2731:3: ( ( (lv_open_0_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) ) )
                    {
                    // InternalDomainModel.g:2731:3: ( ( (lv_open_0_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) ) )
                    // InternalDomainModel.g:2732:4: ( (lv_open_0_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) )
                    {
                    // InternalDomainModel.g:2732:4: ( (lv_open_0_0= ruleopen_1 ) )
                    // InternalDomainModel.g:2733:5: (lv_open_0_0= ruleopen_1 )
                    {
                    // InternalDomainModel.g:2733:5: (lv_open_0_0= ruleopen_1 )
                    // InternalDomainModel.g:2734:6: lv_open_0_0= ruleopen_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getAux_condexprAccess().getOpenOpen_1ParserRuleCall_0_0_0());
                      					
                    }
                    pushFollow(FOLLOW_24);
                    lv_open_0_0=ruleopen_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getAux_condexprRule());
                      						}
                      						set(
                      							current,
                      							"open",
                      							lv_open_0_0,
                      							"org.xtext.example.mydsl.DomainModel.open_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2751:4: ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) )
                    // InternalDomainModel.g:2752:5: (lv_statement_aux_condexpr_1_0= ruleaux_condexpr )
                    {
                    // InternalDomainModel.g:2752:5: (lv_statement_aux_condexpr_1_0= ruleaux_condexpr )
                    // InternalDomainModel.g:2753:6: lv_statement_aux_condexpr_1_0= ruleaux_condexpr
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getAux_condexprAccess().getStatement_aux_condexprAux_condexprParserRuleCall_0_1_0());
                      					
                    }
                    pushFollow(FOLLOW_27);
                    lv_statement_aux_condexpr_1_0=ruleaux_condexpr();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getAux_condexprRule());
                      						}
                      						set(
                      							current,
                      							"statement_aux_condexpr",
                      							lv_statement_aux_condexpr_1_0,
                      							"org.xtext.example.mydsl.DomainModel.aux_condexpr");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2770:4: ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) )
                    // InternalDomainModel.g:2771:5: (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis )
                    {
                    // InternalDomainModel.g:2771:5: (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis )
                    // InternalDomainModel.g:2772:6: lv_statement_optional_parentesis_2_0= ruleoptional_parentesis
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getAux_condexprAccess().getStatement_optional_parentesisOptional_parentesisParserRuleCall_0_2_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_optional_parentesis_2_0=ruleoptional_parentesis();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getAux_condexprRule());
                      						}
                      						set(
                      							current,
                      							"statement_optional_parentesis",
                      							lv_statement_optional_parentesis_2_0,
                      							"org.xtext.example.mydsl.DomainModel.optional_parentesis");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalDomainModel.g:2791:3: ( ( (lv_statement_arith_3_0= rulearith ) ) ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) ) )
                    {
                    // InternalDomainModel.g:2791:3: ( ( (lv_statement_arith_3_0= rulearith ) ) ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) ) )
                    // InternalDomainModel.g:2792:4: ( (lv_statement_arith_3_0= rulearith ) ) ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) )
                    {
                    // InternalDomainModel.g:2792:4: ( (lv_statement_arith_3_0= rulearith ) )
                    // InternalDomainModel.g:2793:5: (lv_statement_arith_3_0= rulearith )
                    {
                    // InternalDomainModel.g:2793:5: (lv_statement_arith_3_0= rulearith )
                    // InternalDomainModel.g:2794:6: lv_statement_arith_3_0= rulearith
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getAux_condexprAccess().getStatement_arithArithParserRuleCall_1_0_0());
                      					
                    }
                    pushFollow(FOLLOW_27);
                    lv_statement_arith_3_0=rulearith();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getAux_condexprRule());
                      						}
                      						set(
                      							current,
                      							"statement_arith",
                      							lv_statement_arith_3_0,
                      							"org.xtext.example.mydsl.DomainModel.arith");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2811:4: ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) )
                    // InternalDomainModel.g:2812:5: (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis )
                    {
                    // InternalDomainModel.g:2812:5: (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis )
                    // InternalDomainModel.g:2813:6: lv_statement_optional_parentesis_4_0= ruleoptional_parentesis
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getAux_condexprAccess().getStatement_optional_parentesisOptional_parentesisParserRuleCall_1_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_optional_parentesis_4_0=ruleoptional_parentesis();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getAux_condexprRule());
                      						}
                      						set(
                      							current,
                      							"statement_optional_parentesis",
                      							lv_statement_optional_parentesis_4_0,
                      							"org.xtext.example.mydsl.DomainModel.optional_parentesis");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalDomainModel.g:2832:3: ( ( (lv_not_5_0= rulenot_1 ) ) ( (lv_open_6_0= ruleopen_1 ) ) ( (lv_statement_condexpr_7_0= rulecondexpr ) ) ( (lv_close_8_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_not_9_0= ruleoptional_parentesis_not ) ) )
                    {
                    // InternalDomainModel.g:2832:3: ( ( (lv_not_5_0= rulenot_1 ) ) ( (lv_open_6_0= ruleopen_1 ) ) ( (lv_statement_condexpr_7_0= rulecondexpr ) ) ( (lv_close_8_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_not_9_0= ruleoptional_parentesis_not ) ) )
                    // InternalDomainModel.g:2833:4: ( (lv_not_5_0= rulenot_1 ) ) ( (lv_open_6_0= ruleopen_1 ) ) ( (lv_statement_condexpr_7_0= rulecondexpr ) ) ( (lv_close_8_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_not_9_0= ruleoptional_parentesis_not ) )
                    {
                    // InternalDomainModel.g:2833:4: ( (lv_not_5_0= rulenot_1 ) )
                    // InternalDomainModel.g:2834:5: (lv_not_5_0= rulenot_1 )
                    {
                    // InternalDomainModel.g:2834:5: (lv_not_5_0= rulenot_1 )
                    // InternalDomainModel.g:2835:6: lv_not_5_0= rulenot_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getAux_condexprAccess().getNotNot_1ParserRuleCall_2_0_0());
                      					
                    }
                    pushFollow(FOLLOW_4);
                    lv_not_5_0=rulenot_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getAux_condexprRule());
                      						}
                      						set(
                      							current,
                      							"not",
                      							lv_not_5_0,
                      							"org.xtext.example.mydsl.DomainModel.not_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2852:4: ( (lv_open_6_0= ruleopen_1 ) )
                    // InternalDomainModel.g:2853:5: (lv_open_6_0= ruleopen_1 )
                    {
                    // InternalDomainModel.g:2853:5: (lv_open_6_0= ruleopen_1 )
                    // InternalDomainModel.g:2854:6: lv_open_6_0= ruleopen_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getAux_condexprAccess().getOpenOpen_1ParserRuleCall_2_1_0());
                      					
                    }
                    pushFollow(FOLLOW_24);
                    lv_open_6_0=ruleopen_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getAux_condexprRule());
                      						}
                      						set(
                      							current,
                      							"open",
                      							lv_open_6_0,
                      							"org.xtext.example.mydsl.DomainModel.open_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2871:4: ( (lv_statement_condexpr_7_0= rulecondexpr ) )
                    // InternalDomainModel.g:2872:5: (lv_statement_condexpr_7_0= rulecondexpr )
                    {
                    // InternalDomainModel.g:2872:5: (lv_statement_condexpr_7_0= rulecondexpr )
                    // InternalDomainModel.g:2873:6: lv_statement_condexpr_7_0= rulecondexpr
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getAux_condexprAccess().getStatement_condexprCondexprParserRuleCall_2_2_0());
                      					
                    }
                    pushFollow(FOLLOW_6);
                    lv_statement_condexpr_7_0=rulecondexpr();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getAux_condexprRule());
                      						}
                      						set(
                      							current,
                      							"statement_condexpr",
                      							lv_statement_condexpr_7_0,
                      							"org.xtext.example.mydsl.DomainModel.condexpr");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2890:4: ( (lv_close_8_0= ruleclose_1 ) )
                    // InternalDomainModel.g:2891:5: (lv_close_8_0= ruleclose_1 )
                    {
                    // InternalDomainModel.g:2891:5: (lv_close_8_0= ruleclose_1 )
                    // InternalDomainModel.g:2892:6: lv_close_8_0= ruleclose_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getAux_condexprAccess().getCloseClose_1ParserRuleCall_2_3_0());
                      					
                    }
                    pushFollow(FOLLOW_27);
                    lv_close_8_0=ruleclose_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getAux_condexprRule());
                      						}
                      						set(
                      							current,
                      							"close",
                      							lv_close_8_0,
                      							"org.xtext.example.mydsl.DomainModel.close_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2909:4: ( (lv_statement_optional_parentesis_not_9_0= ruleoptional_parentesis_not ) )
                    // InternalDomainModel.g:2910:5: (lv_statement_optional_parentesis_not_9_0= ruleoptional_parentesis_not )
                    {
                    // InternalDomainModel.g:2910:5: (lv_statement_optional_parentesis_not_9_0= ruleoptional_parentesis_not )
                    // InternalDomainModel.g:2911:6: lv_statement_optional_parentesis_not_9_0= ruleoptional_parentesis_not
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getAux_condexprAccess().getStatement_optional_parentesis_notOptional_parentesis_notParserRuleCall_2_4_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_optional_parentesis_not_9_0=ruleoptional_parentesis_not();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getAux_condexprRule());
                      						}
                      						set(
                      							current,
                      							"statement_optional_parentesis_not",
                      							lv_statement_optional_parentesis_not_9_0,
                      							"org.xtext.example.mydsl.DomainModel.optional_parentesis_not");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleaux_condexpr"


    // $ANTLR start "entryRulenot_1"
    // InternalDomainModel.g:2933:1: entryRulenot_1 returns [String current=null] : iv_rulenot_1= rulenot_1 EOF ;
    public final String entryRulenot_1() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_rulenot_1 = null;


        try {
            // InternalDomainModel.g:2933:45: (iv_rulenot_1= rulenot_1 EOF )
            // InternalDomainModel.g:2934:2: iv_rulenot_1= rulenot_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getNot_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulenot_1=rulenot_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulenot_1.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulenot_1"


    // $ANTLR start "rulenot_1"
    // InternalDomainModel.g:2940:1: rulenot_1 returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= 'not' ;
    public final AntlrDatatypeRuleToken rulenot_1() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalDomainModel.g:2946:2: (kw= 'not' )
            // InternalDomainModel.g:2947:2: kw= 'not'
            {
            kw=(Token)match(input,39,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current.merge(kw);
              		newLeafNode(kw, grammarAccess.getNot_1Access().getNotKeyword());
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulenot_1"


    // $ANTLR start "entryRuleoptional_parentesis"
    // InternalDomainModel.g:2955:1: entryRuleoptional_parentesis returns [EObject current=null] : iv_ruleoptional_parentesis= ruleoptional_parentesis EOF ;
    public final EObject entryRuleoptional_parentesis() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleoptional_parentesis = null;


        try {
            // InternalDomainModel.g:2955:60: (iv_ruleoptional_parentesis= ruleoptional_parentesis EOF )
            // InternalDomainModel.g:2956:2: iv_ruleoptional_parentesis= ruleoptional_parentesis EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getOptional_parentesisRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleoptional_parentesis=ruleoptional_parentesis();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleoptional_parentesis; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleoptional_parentesis"


    // $ANTLR start "ruleoptional_parentesis"
    // InternalDomainModel.g:2962:1: ruleoptional_parentesis returns [EObject current=null] : ( ( ( (lv_close_0_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 ) ) ) | ( ( (lv_statement_conditional_2_0= ruleconditional ) )? ( (lv_close_3_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_1_4_0= ruleoptional_parentesis_1 ) ) ) ) ;
    public final EObject ruleoptional_parentesis() throws RecognitionException {
        EObject current = null;

        AntlrDatatypeRuleToken lv_close_0_0 = null;

        EObject lv_statement_optional_parentesis_1_1_0 = null;

        EObject lv_statement_conditional_2_0 = null;

        AntlrDatatypeRuleToken lv_close_3_0 = null;

        EObject lv_statement_optional_parentesis_1_4_0 = null;



        	enterRule();

        try {
            // InternalDomainModel.g:2968:2: ( ( ( ( (lv_close_0_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 ) ) ) | ( ( (lv_statement_conditional_2_0= ruleconditional ) )? ( (lv_close_3_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_1_4_0= ruleoptional_parentesis_1 ) ) ) ) )
            // InternalDomainModel.g:2969:2: ( ( ( (lv_close_0_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 ) ) ) | ( ( (lv_statement_conditional_2_0= ruleconditional ) )? ( (lv_close_3_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_1_4_0= ruleoptional_parentesis_1 ) ) ) )
            {
            // InternalDomainModel.g:2969:2: ( ( ( (lv_close_0_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 ) ) ) | ( ( (lv_statement_conditional_2_0= ruleconditional ) )? ( (lv_close_3_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_1_4_0= ruleoptional_parentesis_1 ) ) ) )
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==14) ) {
                int LA40_1 = input.LA(2);

                if ( (synpred58_InternalDomainModel()) ) {
                    alt40=1;
                }
                else if ( (true) ) {
                    alt40=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 40, 1, input);

                    throw nvae;
                }
            }
            else if ( ((LA40_0>=33 && LA40_0<=38)||(LA40_0>=40 && LA40_0<=41)) ) {
                alt40=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 40, 0, input);

                throw nvae;
            }
            switch (alt40) {
                case 1 :
                    // InternalDomainModel.g:2970:3: ( ( (lv_close_0_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 ) ) )
                    {
                    // InternalDomainModel.g:2970:3: ( ( (lv_close_0_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 ) ) )
                    // InternalDomainModel.g:2971:4: ( (lv_close_0_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 ) )
                    {
                    // InternalDomainModel.g:2971:4: ( (lv_close_0_0= ruleclose_1 ) )
                    // InternalDomainModel.g:2972:5: (lv_close_0_0= ruleclose_1 )
                    {
                    // InternalDomainModel.g:2972:5: (lv_close_0_0= ruleclose_1 )
                    // InternalDomainModel.g:2973:6: lv_close_0_0= ruleclose_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getOptional_parentesisAccess().getCloseClose_1ParserRuleCall_0_0_0());
                      					
                    }
                    pushFollow(FOLLOW_28);
                    lv_close_0_0=ruleclose_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getOptional_parentesisRule());
                      						}
                      						set(
                      							current,
                      							"close",
                      							lv_close_0_0,
                      							"org.xtext.example.mydsl.DomainModel.close_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:2990:4: ( (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 ) )
                    // InternalDomainModel.g:2991:5: (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 )
                    {
                    // InternalDomainModel.g:2991:5: (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 )
                    // InternalDomainModel.g:2992:6: lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getOptional_parentesisAccess().getStatement_optional_parentesis_1Optional_parentesis_1ParserRuleCall_0_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_optional_parentesis_1_1_0=ruleoptional_parentesis_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getOptional_parentesisRule());
                      						}
                      						set(
                      							current,
                      							"statement_optional_parentesis_1",
                      							lv_statement_optional_parentesis_1_1_0,
                      							"org.xtext.example.mydsl.DomainModel.optional_parentesis_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalDomainModel.g:3011:3: ( ( (lv_statement_conditional_2_0= ruleconditional ) )? ( (lv_close_3_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_1_4_0= ruleoptional_parentesis_1 ) ) )
                    {
                    // InternalDomainModel.g:3011:3: ( ( (lv_statement_conditional_2_0= ruleconditional ) )? ( (lv_close_3_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_1_4_0= ruleoptional_parentesis_1 ) ) )
                    // InternalDomainModel.g:3012:4: ( (lv_statement_conditional_2_0= ruleconditional ) )? ( (lv_close_3_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_1_4_0= ruleoptional_parentesis_1 ) )
                    {
                    // InternalDomainModel.g:3012:4: ( (lv_statement_conditional_2_0= ruleconditional ) )?
                    int alt39=2;
                    int LA39_0 = input.LA(1);

                    if ( ((LA39_0>=33 && LA39_0<=38)||(LA39_0>=40 && LA39_0<=41)) ) {
                        alt39=1;
                    }
                    switch (alt39) {
                        case 1 :
                            // InternalDomainModel.g:3013:5: (lv_statement_conditional_2_0= ruleconditional )
                            {
                            // InternalDomainModel.g:3013:5: (lv_statement_conditional_2_0= ruleconditional )
                            // InternalDomainModel.g:3014:6: lv_statement_conditional_2_0= ruleconditional
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getOptional_parentesisAccess().getStatement_conditionalConditionalParserRuleCall_1_0_0());
                              					
                            }
                            pushFollow(FOLLOW_6);
                            lv_statement_conditional_2_0=ruleconditional();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElementForParent(grammarAccess.getOptional_parentesisRule());
                              						}
                              						set(
                              							current,
                              							"statement_conditional",
                              							lv_statement_conditional_2_0,
                              							"org.xtext.example.mydsl.DomainModel.conditional");
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }


                            }
                            break;

                    }

                    // InternalDomainModel.g:3031:4: ( (lv_close_3_0= ruleclose_1 ) )
                    // InternalDomainModel.g:3032:5: (lv_close_3_0= ruleclose_1 )
                    {
                    // InternalDomainModel.g:3032:5: (lv_close_3_0= ruleclose_1 )
                    // InternalDomainModel.g:3033:6: lv_close_3_0= ruleclose_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getOptional_parentesisAccess().getCloseClose_1ParserRuleCall_1_1_0());
                      					
                    }
                    pushFollow(FOLLOW_28);
                    lv_close_3_0=ruleclose_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getOptional_parentesisRule());
                      						}
                      						set(
                      							current,
                      							"close",
                      							lv_close_3_0,
                      							"org.xtext.example.mydsl.DomainModel.close_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:3050:4: ( (lv_statement_optional_parentesis_1_4_0= ruleoptional_parentesis_1 ) )
                    // InternalDomainModel.g:3051:5: (lv_statement_optional_parentesis_1_4_0= ruleoptional_parentesis_1 )
                    {
                    // InternalDomainModel.g:3051:5: (lv_statement_optional_parentesis_1_4_0= ruleoptional_parentesis_1 )
                    // InternalDomainModel.g:3052:6: lv_statement_optional_parentesis_1_4_0= ruleoptional_parentesis_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getOptional_parentesisAccess().getStatement_optional_parentesis_1Optional_parentesis_1ParserRuleCall_1_2_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_optional_parentesis_1_4_0=ruleoptional_parentesis_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getOptional_parentesisRule());
                      						}
                      						set(
                      							current,
                      							"statement_optional_parentesis_1",
                      							lv_statement_optional_parentesis_1_4_0,
                      							"org.xtext.example.mydsl.DomainModel.optional_parentesis_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleoptional_parentesis"


    // $ANTLR start "entryRuleoptional_parentesis_not"
    // InternalDomainModel.g:3074:1: entryRuleoptional_parentesis_not returns [EObject current=null] : iv_ruleoptional_parentesis_not= ruleoptional_parentesis_not EOF ;
    public final EObject entryRuleoptional_parentesis_not() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleoptional_parentesis_not = null;


        try {
            // InternalDomainModel.g:3074:64: (iv_ruleoptional_parentesis_not= ruleoptional_parentesis_not EOF )
            // InternalDomainModel.g:3075:2: iv_ruleoptional_parentesis_not= ruleoptional_parentesis_not EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getOptional_parentesis_notRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleoptional_parentesis_not=ruleoptional_parentesis_not();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleoptional_parentesis_not; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleoptional_parentesis_not"


    // $ANTLR start "ruleoptional_parentesis_not"
    // InternalDomainModel.g:3081:1: ruleoptional_parentesis_not returns [EObject current=null] : ( ( ( (lv_close_0_0= ruleclose_1 ) ) ( (lv_statement_conditional_1_0= ruleconditional ) )? ) | ( ( (lv_statement_conditional_2_0= ruleconditional ) )? ( (lv_close_3_0= ruleclose_1 ) ) ( (lv_statement_prueba_conditional_4_0= ruleprueba_conditional ) )? ) ) ;
    public final EObject ruleoptional_parentesis_not() throws RecognitionException {
        EObject current = null;

        AntlrDatatypeRuleToken lv_close_0_0 = null;

        EObject lv_statement_conditional_1_0 = null;

        EObject lv_statement_conditional_2_0 = null;

        AntlrDatatypeRuleToken lv_close_3_0 = null;

        EObject lv_statement_prueba_conditional_4_0 = null;



        	enterRule();

        try {
            // InternalDomainModel.g:3087:2: ( ( ( ( (lv_close_0_0= ruleclose_1 ) ) ( (lv_statement_conditional_1_0= ruleconditional ) )? ) | ( ( (lv_statement_conditional_2_0= ruleconditional ) )? ( (lv_close_3_0= ruleclose_1 ) ) ( (lv_statement_prueba_conditional_4_0= ruleprueba_conditional ) )? ) ) )
            // InternalDomainModel.g:3088:2: ( ( ( (lv_close_0_0= ruleclose_1 ) ) ( (lv_statement_conditional_1_0= ruleconditional ) )? ) | ( ( (lv_statement_conditional_2_0= ruleconditional ) )? ( (lv_close_3_0= ruleclose_1 ) ) ( (lv_statement_prueba_conditional_4_0= ruleprueba_conditional ) )? ) )
            {
            // InternalDomainModel.g:3088:2: ( ( ( (lv_close_0_0= ruleclose_1 ) ) ( (lv_statement_conditional_1_0= ruleconditional ) )? ) | ( ( (lv_statement_conditional_2_0= ruleconditional ) )? ( (lv_close_3_0= ruleclose_1 ) ) ( (lv_statement_prueba_conditional_4_0= ruleprueba_conditional ) )? ) )
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==14) ) {
                int LA44_1 = input.LA(2);

                if ( (synpred61_InternalDomainModel()) ) {
                    alt44=1;
                }
                else if ( (true) ) {
                    alt44=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 44, 1, input);

                    throw nvae;
                }
            }
            else if ( ((LA44_0>=33 && LA44_0<=38)||(LA44_0>=40 && LA44_0<=41)) ) {
                alt44=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 44, 0, input);

                throw nvae;
            }
            switch (alt44) {
                case 1 :
                    // InternalDomainModel.g:3089:3: ( ( (lv_close_0_0= ruleclose_1 ) ) ( (lv_statement_conditional_1_0= ruleconditional ) )? )
                    {
                    // InternalDomainModel.g:3089:3: ( ( (lv_close_0_0= ruleclose_1 ) ) ( (lv_statement_conditional_1_0= ruleconditional ) )? )
                    // InternalDomainModel.g:3090:4: ( (lv_close_0_0= ruleclose_1 ) ) ( (lv_statement_conditional_1_0= ruleconditional ) )?
                    {
                    // InternalDomainModel.g:3090:4: ( (lv_close_0_0= ruleclose_1 ) )
                    // InternalDomainModel.g:3091:5: (lv_close_0_0= ruleclose_1 )
                    {
                    // InternalDomainModel.g:3091:5: (lv_close_0_0= ruleclose_1 )
                    // InternalDomainModel.g:3092:6: lv_close_0_0= ruleclose_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getOptional_parentesis_notAccess().getCloseClose_1ParserRuleCall_0_0_0());
                      					
                    }
                    pushFollow(FOLLOW_25);
                    lv_close_0_0=ruleclose_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getOptional_parentesis_notRule());
                      						}
                      						set(
                      							current,
                      							"close",
                      							lv_close_0_0,
                      							"org.xtext.example.mydsl.DomainModel.close_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:3109:4: ( (lv_statement_conditional_1_0= ruleconditional ) )?
                    int alt41=2;
                    alt41 = dfa41.predict(input);
                    switch (alt41) {
                        case 1 :
                            // InternalDomainModel.g:3110:5: (lv_statement_conditional_1_0= ruleconditional )
                            {
                            // InternalDomainModel.g:3110:5: (lv_statement_conditional_1_0= ruleconditional )
                            // InternalDomainModel.g:3111:6: lv_statement_conditional_1_0= ruleconditional
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getOptional_parentesis_notAccess().getStatement_conditionalConditionalParserRuleCall_0_1_0());
                              					
                            }
                            pushFollow(FOLLOW_2);
                            lv_statement_conditional_1_0=ruleconditional();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElementForParent(grammarAccess.getOptional_parentesis_notRule());
                              						}
                              						set(
                              							current,
                              							"statement_conditional",
                              							lv_statement_conditional_1_0,
                              							"org.xtext.example.mydsl.DomainModel.conditional");
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalDomainModel.g:3130:3: ( ( (lv_statement_conditional_2_0= ruleconditional ) )? ( (lv_close_3_0= ruleclose_1 ) ) ( (lv_statement_prueba_conditional_4_0= ruleprueba_conditional ) )? )
                    {
                    // InternalDomainModel.g:3130:3: ( ( (lv_statement_conditional_2_0= ruleconditional ) )? ( (lv_close_3_0= ruleclose_1 ) ) ( (lv_statement_prueba_conditional_4_0= ruleprueba_conditional ) )? )
                    // InternalDomainModel.g:3131:4: ( (lv_statement_conditional_2_0= ruleconditional ) )? ( (lv_close_3_0= ruleclose_1 ) ) ( (lv_statement_prueba_conditional_4_0= ruleprueba_conditional ) )?
                    {
                    // InternalDomainModel.g:3131:4: ( (lv_statement_conditional_2_0= ruleconditional ) )?
                    int alt42=2;
                    int LA42_0 = input.LA(1);

                    if ( ((LA42_0>=33 && LA42_0<=38)||(LA42_0>=40 && LA42_0<=41)) ) {
                        alt42=1;
                    }
                    switch (alt42) {
                        case 1 :
                            // InternalDomainModel.g:3132:5: (lv_statement_conditional_2_0= ruleconditional )
                            {
                            // InternalDomainModel.g:3132:5: (lv_statement_conditional_2_0= ruleconditional )
                            // InternalDomainModel.g:3133:6: lv_statement_conditional_2_0= ruleconditional
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getOptional_parentesis_notAccess().getStatement_conditionalConditionalParserRuleCall_1_0_0());
                              					
                            }
                            pushFollow(FOLLOW_6);
                            lv_statement_conditional_2_0=ruleconditional();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElementForParent(grammarAccess.getOptional_parentesis_notRule());
                              						}
                              						set(
                              							current,
                              							"statement_conditional",
                              							lv_statement_conditional_2_0,
                              							"org.xtext.example.mydsl.DomainModel.conditional");
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }


                            }
                            break;

                    }

                    // InternalDomainModel.g:3150:4: ( (lv_close_3_0= ruleclose_1 ) )
                    // InternalDomainModel.g:3151:5: (lv_close_3_0= ruleclose_1 )
                    {
                    // InternalDomainModel.g:3151:5: (lv_close_3_0= ruleclose_1 )
                    // InternalDomainModel.g:3152:6: lv_close_3_0= ruleclose_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getOptional_parentesis_notAccess().getCloseClose_1ParserRuleCall_1_1_0());
                      					
                    }
                    pushFollow(FOLLOW_25);
                    lv_close_3_0=ruleclose_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getOptional_parentesis_notRule());
                      						}
                      						set(
                      							current,
                      							"close",
                      							lv_close_3_0,
                      							"org.xtext.example.mydsl.DomainModel.close_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:3169:4: ( (lv_statement_prueba_conditional_4_0= ruleprueba_conditional ) )?
                    int alt43=2;
                    alt43 = dfa43.predict(input);
                    switch (alt43) {
                        case 1 :
                            // InternalDomainModel.g:3170:5: (lv_statement_prueba_conditional_4_0= ruleprueba_conditional )
                            {
                            // InternalDomainModel.g:3170:5: (lv_statement_prueba_conditional_4_0= ruleprueba_conditional )
                            // InternalDomainModel.g:3171:6: lv_statement_prueba_conditional_4_0= ruleprueba_conditional
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getOptional_parentesis_notAccess().getStatement_prueba_conditionalPrueba_conditionalParserRuleCall_1_2_0());
                              					
                            }
                            pushFollow(FOLLOW_2);
                            lv_statement_prueba_conditional_4_0=ruleprueba_conditional();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElementForParent(grammarAccess.getOptional_parentesis_notRule());
                              						}
                              						set(
                              							current,
                              							"statement_prueba_conditional",
                              							lv_statement_prueba_conditional_4_0,
                              							"org.xtext.example.mydsl.DomainModel.prueba_conditional");
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }


                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleoptional_parentesis_not"


    // $ANTLR start "entryRuleoptional_parentesis_1"
    // InternalDomainModel.g:3193:1: entryRuleoptional_parentesis_1 returns [EObject current=null] : iv_ruleoptional_parentesis_1= ruleoptional_parentesis_1 EOF ;
    public final EObject entryRuleoptional_parentesis_1() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleoptional_parentesis_1 = null;


        try {
            // InternalDomainModel.g:3193:62: (iv_ruleoptional_parentesis_1= ruleoptional_parentesis_1 EOF )
            // InternalDomainModel.g:3194:2: iv_ruleoptional_parentesis_1= ruleoptional_parentesis_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getOptional_parentesis_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleoptional_parentesis_1=ruleoptional_parentesis_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleoptional_parentesis_1; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleoptional_parentesis_1"


    // $ANTLR start "ruleoptional_parentesis_1"
    // InternalDomainModel.g:3200:1: ruleoptional_parentesis_1 returns [EObject current=null] : ( ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) ) ) | ( (lv_statement_conditional_2_0= ruleconditional ) )? ) ;
    public final EObject ruleoptional_parentesis_1() throws RecognitionException {
        EObject current = null;

        EObject lv_statement_operation_0_0 = null;

        EObject lv_statement_condexpr_1_0 = null;

        EObject lv_statement_conditional_2_0 = null;



        	enterRule();

        try {
            // InternalDomainModel.g:3206:2: ( ( ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) ) ) | ( (lv_statement_conditional_2_0= ruleconditional ) )? ) )
            // InternalDomainModel.g:3207:2: ( ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) ) ) | ( (lv_statement_conditional_2_0= ruleconditional ) )? )
            {
            // InternalDomainModel.g:3207:2: ( ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) ) ) | ( (lv_statement_conditional_2_0= ruleconditional ) )? )
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( ((LA46_0>=44 && LA46_0<=48)) ) {
                alt46=1;
            }
            else if ( (LA46_0==EOF||LA46_0==14||(LA46_0>=33 && LA46_0<=38)||(LA46_0>=40 && LA46_0<=41)) ) {
                alt46=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 46, 0, input);

                throw nvae;
            }
            switch (alt46) {
                case 1 :
                    // InternalDomainModel.g:3208:3: ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) ) )
                    {
                    // InternalDomainModel.g:3208:3: ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) ) )
                    // InternalDomainModel.g:3209:4: ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) )
                    {
                    // InternalDomainModel.g:3209:4: ( (lv_statement_operation_0_0= ruleoperation ) )
                    // InternalDomainModel.g:3210:5: (lv_statement_operation_0_0= ruleoperation )
                    {
                    // InternalDomainModel.g:3210:5: (lv_statement_operation_0_0= ruleoperation )
                    // InternalDomainModel.g:3211:6: lv_statement_operation_0_0= ruleoperation
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getOptional_parentesis_1Access().getStatement_operationOperationParserRuleCall_0_0_0());
                      					
                    }
                    pushFollow(FOLLOW_24);
                    lv_statement_operation_0_0=ruleoperation();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getOptional_parentesis_1Rule());
                      						}
                      						set(
                      							current,
                      							"statement_operation",
                      							lv_statement_operation_0_0,
                      							"org.xtext.example.mydsl.DomainModel.operation");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:3228:4: ( (lv_statement_condexpr_1_0= rulecondexpr ) )
                    // InternalDomainModel.g:3229:5: (lv_statement_condexpr_1_0= rulecondexpr )
                    {
                    // InternalDomainModel.g:3229:5: (lv_statement_condexpr_1_0= rulecondexpr )
                    // InternalDomainModel.g:3230:6: lv_statement_condexpr_1_0= rulecondexpr
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getOptional_parentesis_1Access().getStatement_condexprCondexprParserRuleCall_0_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_condexpr_1_0=rulecondexpr();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getOptional_parentesis_1Rule());
                      						}
                      						set(
                      							current,
                      							"statement_condexpr",
                      							lv_statement_condexpr_1_0,
                      							"org.xtext.example.mydsl.DomainModel.condexpr");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalDomainModel.g:3249:3: ( (lv_statement_conditional_2_0= ruleconditional ) )?
                    {
                    // InternalDomainModel.g:3249:3: ( (lv_statement_conditional_2_0= ruleconditional ) )?
                    int alt45=2;
                    alt45 = dfa45.predict(input);
                    switch (alt45) {
                        case 1 :
                            // InternalDomainModel.g:3250:4: (lv_statement_conditional_2_0= ruleconditional )
                            {
                            // InternalDomainModel.g:3250:4: (lv_statement_conditional_2_0= ruleconditional )
                            // InternalDomainModel.g:3251:5: lv_statement_conditional_2_0= ruleconditional
                            {
                            if ( state.backtracking==0 ) {

                              					newCompositeNode(grammarAccess.getOptional_parentesis_1Access().getStatement_conditionalConditionalParserRuleCall_1_0());
                              				
                            }
                            pushFollow(FOLLOW_2);
                            lv_statement_conditional_2_0=ruleconditional();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					if (current==null) {
                              						current = createModelElementForParent(grammarAccess.getOptional_parentesis_1Rule());
                              					}
                              					set(
                              						current,
                              						"statement_conditional",
                              						lv_statement_conditional_2_0,
                              						"org.xtext.example.mydsl.DomainModel.conditional");
                              					afterParserOrEnumRuleCall();
                              				
                            }

                            }


                            }
                            break;

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleoptional_parentesis_1"


    // $ANTLR start "entryRuleprueba_conditional"
    // InternalDomainModel.g:3272:1: entryRuleprueba_conditional returns [EObject current=null] : iv_ruleprueba_conditional= ruleprueba_conditional EOF ;
    public final EObject entryRuleprueba_conditional() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleprueba_conditional = null;


        try {
            // InternalDomainModel.g:3272:59: (iv_ruleprueba_conditional= ruleprueba_conditional EOF )
            // InternalDomainModel.g:3273:2: iv_ruleprueba_conditional= ruleprueba_conditional EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPrueba_conditionalRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleprueba_conditional=ruleprueba_conditional();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleprueba_conditional; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleprueba_conditional"


    // $ANTLR start "ruleprueba_conditional"
    // InternalDomainModel.g:3279:1: ruleprueba_conditional returns [EObject current=null] : ( ( (lv_statement_conectores_0_0= ruleconectores ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) ) ) ;
    public final EObject ruleprueba_conditional() throws RecognitionException {
        EObject current = null;

        EObject lv_statement_conectores_0_0 = null;

        EObject lv_statement_condexpr_1_0 = null;



        	enterRule();

        try {
            // InternalDomainModel.g:3285:2: ( ( ( (lv_statement_conectores_0_0= ruleconectores ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) ) ) )
            // InternalDomainModel.g:3286:2: ( ( (lv_statement_conectores_0_0= ruleconectores ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) ) )
            {
            // InternalDomainModel.g:3286:2: ( ( (lv_statement_conectores_0_0= ruleconectores ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) ) )
            // InternalDomainModel.g:3287:3: ( (lv_statement_conectores_0_0= ruleconectores ) ) ( (lv_statement_condexpr_1_0= rulecondexpr ) )
            {
            // InternalDomainModel.g:3287:3: ( (lv_statement_conectores_0_0= ruleconectores ) )
            // InternalDomainModel.g:3288:4: (lv_statement_conectores_0_0= ruleconectores )
            {
            // InternalDomainModel.g:3288:4: (lv_statement_conectores_0_0= ruleconectores )
            // InternalDomainModel.g:3289:5: lv_statement_conectores_0_0= ruleconectores
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getPrueba_conditionalAccess().getStatement_conectoresConectoresParserRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_24);
            lv_statement_conectores_0_0=ruleconectores();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getPrueba_conditionalRule());
              					}
              					set(
              						current,
              						"statement_conectores",
              						lv_statement_conectores_0_0,
              						"org.xtext.example.mydsl.DomainModel.conectores");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalDomainModel.g:3306:3: ( (lv_statement_condexpr_1_0= rulecondexpr ) )
            // InternalDomainModel.g:3307:4: (lv_statement_condexpr_1_0= rulecondexpr )
            {
            // InternalDomainModel.g:3307:4: (lv_statement_condexpr_1_0= rulecondexpr )
            // InternalDomainModel.g:3308:5: lv_statement_condexpr_1_0= rulecondexpr
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getPrueba_conditionalAccess().getStatement_condexprCondexprParserRuleCall_1_0());
              				
            }
            pushFollow(FOLLOW_2);
            lv_statement_condexpr_1_0=rulecondexpr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getPrueba_conditionalRule());
              					}
              					set(
              						current,
              						"statement_condexpr",
              						lv_statement_condexpr_1_0,
              						"org.xtext.example.mydsl.DomainModel.condexpr");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleprueba_conditional"


    // $ANTLR start "entryRuleconectores"
    // InternalDomainModel.g:3329:1: entryRuleconectores returns [EObject current=null] : iv_ruleconectores= ruleconectores EOF ;
    public final EObject entryRuleconectores() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleconectores = null;


        try {
            // InternalDomainModel.g:3329:51: (iv_ruleconectores= ruleconectores EOF )
            // InternalDomainModel.g:3330:2: iv_ruleconectores= ruleconectores EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getConectoresRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleconectores=ruleconectores();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleconectores; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleconectores"


    // $ANTLR start "ruleconectores"
    // InternalDomainModel.g:3336:1: ruleconectores returns [EObject current=null] : ( ( (lv_and_0_0= ruleand_1 ) ) | ( (lv_or_1_0= ruleor_1 ) ) ) ;
    public final EObject ruleconectores() throws RecognitionException {
        EObject current = null;

        AntlrDatatypeRuleToken lv_and_0_0 = null;

        AntlrDatatypeRuleToken lv_or_1_0 = null;



        	enterRule();

        try {
            // InternalDomainModel.g:3342:2: ( ( ( (lv_and_0_0= ruleand_1 ) ) | ( (lv_or_1_0= ruleor_1 ) ) ) )
            // InternalDomainModel.g:3343:2: ( ( (lv_and_0_0= ruleand_1 ) ) | ( (lv_or_1_0= ruleor_1 ) ) )
            {
            // InternalDomainModel.g:3343:2: ( ( (lv_and_0_0= ruleand_1 ) ) | ( (lv_or_1_0= ruleor_1 ) ) )
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==40) ) {
                alt47=1;
            }
            else if ( (LA47_0==41) ) {
                alt47=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 47, 0, input);

                throw nvae;
            }
            switch (alt47) {
                case 1 :
                    // InternalDomainModel.g:3344:3: ( (lv_and_0_0= ruleand_1 ) )
                    {
                    // InternalDomainModel.g:3344:3: ( (lv_and_0_0= ruleand_1 ) )
                    // InternalDomainModel.g:3345:4: (lv_and_0_0= ruleand_1 )
                    {
                    // InternalDomainModel.g:3345:4: (lv_and_0_0= ruleand_1 )
                    // InternalDomainModel.g:3346:5: lv_and_0_0= ruleand_1
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getConectoresAccess().getAndAnd_1ParserRuleCall_0_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_and_0_0=ruleand_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getConectoresRule());
                      					}
                      					set(
                      						current,
                      						"and",
                      						lv_and_0_0,
                      						"org.xtext.example.mydsl.DomainModel.and_1");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalDomainModel.g:3364:3: ( (lv_or_1_0= ruleor_1 ) )
                    {
                    // InternalDomainModel.g:3364:3: ( (lv_or_1_0= ruleor_1 ) )
                    // InternalDomainModel.g:3365:4: (lv_or_1_0= ruleor_1 )
                    {
                    // InternalDomainModel.g:3365:4: (lv_or_1_0= ruleor_1 )
                    // InternalDomainModel.g:3366:5: lv_or_1_0= ruleor_1
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getConectoresAccess().getOrOr_1ParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_or_1_0=ruleor_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getConectoresRule());
                      					}
                      					set(
                      						current,
                      						"or",
                      						lv_or_1_0,
                      						"org.xtext.example.mydsl.DomainModel.or_1");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleconectores"


    // $ANTLR start "entryRuleand_1"
    // InternalDomainModel.g:3387:1: entryRuleand_1 returns [String current=null] : iv_ruleand_1= ruleand_1 EOF ;
    public final String entryRuleand_1() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleand_1 = null;


        try {
            // InternalDomainModel.g:3387:45: (iv_ruleand_1= ruleand_1 EOF )
            // InternalDomainModel.g:3388:2: iv_ruleand_1= ruleand_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getAnd_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleand_1=ruleand_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleand_1.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleand_1"


    // $ANTLR start "ruleand_1"
    // InternalDomainModel.g:3394:1: ruleand_1 returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= 'and' ;
    public final AntlrDatatypeRuleToken ruleand_1() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalDomainModel.g:3400:2: (kw= 'and' )
            // InternalDomainModel.g:3401:2: kw= 'and'
            {
            kw=(Token)match(input,40,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current.merge(kw);
              		newLeafNode(kw, grammarAccess.getAnd_1Access().getAndKeyword());
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleand_1"


    // $ANTLR start "entryRuleor_1"
    // InternalDomainModel.g:3409:1: entryRuleor_1 returns [String current=null] : iv_ruleor_1= ruleor_1 EOF ;
    public final String entryRuleor_1() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleor_1 = null;


        try {
            // InternalDomainModel.g:3409:44: (iv_ruleor_1= ruleor_1 EOF )
            // InternalDomainModel.g:3410:2: iv_ruleor_1= ruleor_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getOr_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleor_1=ruleor_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleor_1.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleor_1"


    // $ANTLR start "ruleor_1"
    // InternalDomainModel.g:3416:1: ruleor_1 returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= 'or' ;
    public final AntlrDatatypeRuleToken ruleor_1() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalDomainModel.g:3422:2: (kw= 'or' )
            // InternalDomainModel.g:3423:2: kw= 'or'
            {
            kw=(Token)match(input,41,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current.merge(kw);
              		newLeafNode(kw, grammarAccess.getOr_1Access().getOrKeyword());
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleor_1"


    // $ANTLR start "entryRulearith"
    // InternalDomainModel.g:3431:1: entryRulearith returns [EObject current=null] : iv_rulearith= rulearith EOF ;
    public final EObject entryRulearith() throws RecognitionException {
        EObject current = null;

        EObject iv_rulearith = null;


        try {
            // InternalDomainModel.g:3431:46: (iv_rulearith= rulearith EOF )
            // InternalDomainModel.g:3432:2: iv_rulearith= rulearith EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getArithRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulearith=rulearith();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulearith; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulearith"


    // $ANTLR start "rulearith"
    // InternalDomainModel.g:3438:1: rulearith returns [EObject current=null] : ( ( ( (lv_statement_id_arithmetic_0_0= ruleid_arithmetic ) ) ( (lv_statement_arithmetic_1_0= rulearithmetic ) )? ) | ( ( (lv_plus_2_0= ruleplus_1 ) ) ( (lv_statement_arith_3_0= rulearith ) ) ) | ( ( (lv_minus_4_0= ruleminus_1 ) ) ( (lv_statement_arith_5_0= rulearith ) ) ) | ( ( (lv_open_6_0= ruleopen_1 ) ) ( (lv_statement_arith_7_0= rulearith ) ) ( (lv_close_8_0= ruleclose_1 ) ) ( (lv_statement_next_parentesis_9_0= rulenext_parentesis ) ) ) ) ;
    public final EObject rulearith() throws RecognitionException {
        EObject current = null;

        EObject lv_statement_id_arithmetic_0_0 = null;

        EObject lv_statement_arithmetic_1_0 = null;

        AntlrDatatypeRuleToken lv_plus_2_0 = null;

        EObject lv_statement_arith_3_0 = null;

        AntlrDatatypeRuleToken lv_minus_4_0 = null;

        EObject lv_statement_arith_5_0 = null;

        AntlrDatatypeRuleToken lv_open_6_0 = null;

        EObject lv_statement_arith_7_0 = null;

        AntlrDatatypeRuleToken lv_close_8_0 = null;

        EObject lv_statement_next_parentesis_9_0 = null;



        	enterRule();

        try {
            // InternalDomainModel.g:3444:2: ( ( ( ( (lv_statement_id_arithmetic_0_0= ruleid_arithmetic ) ) ( (lv_statement_arithmetic_1_0= rulearithmetic ) )? ) | ( ( (lv_plus_2_0= ruleplus_1 ) ) ( (lv_statement_arith_3_0= rulearith ) ) ) | ( ( (lv_minus_4_0= ruleminus_1 ) ) ( (lv_statement_arith_5_0= rulearith ) ) ) | ( ( (lv_open_6_0= ruleopen_1 ) ) ( (lv_statement_arith_7_0= rulearith ) ) ( (lv_close_8_0= ruleclose_1 ) ) ( (lv_statement_next_parentesis_9_0= rulenext_parentesis ) ) ) ) )
            // InternalDomainModel.g:3445:2: ( ( ( (lv_statement_id_arithmetic_0_0= ruleid_arithmetic ) ) ( (lv_statement_arithmetic_1_0= rulearithmetic ) )? ) | ( ( (lv_plus_2_0= ruleplus_1 ) ) ( (lv_statement_arith_3_0= rulearith ) ) ) | ( ( (lv_minus_4_0= ruleminus_1 ) ) ( (lv_statement_arith_5_0= rulearith ) ) ) | ( ( (lv_open_6_0= ruleopen_1 ) ) ( (lv_statement_arith_7_0= rulearith ) ) ( (lv_close_8_0= ruleclose_1 ) ) ( (lv_statement_next_parentesis_9_0= rulenext_parentesis ) ) ) )
            {
            // InternalDomainModel.g:3445:2: ( ( ( (lv_statement_id_arithmetic_0_0= ruleid_arithmetic ) ) ( (lv_statement_arithmetic_1_0= rulearithmetic ) )? ) | ( ( (lv_plus_2_0= ruleplus_1 ) ) ( (lv_statement_arith_3_0= rulearith ) ) ) | ( ( (lv_minus_4_0= ruleminus_1 ) ) ( (lv_statement_arith_5_0= rulearith ) ) ) | ( ( (lv_open_6_0= ruleopen_1 ) ) ( (lv_statement_arith_7_0= rulearith ) ) ( (lv_close_8_0= ruleclose_1 ) ) ( (lv_statement_next_parentesis_9_0= rulenext_parentesis ) ) ) )
            int alt49=4;
            switch ( input.LA(1) ) {
            case RULE_ID:
            case RULE_INT:
            case RULE_DOUBLE:
                {
                alt49=1;
                }
                break;
            case 44:
                {
                alt49=2;
                }
                break;
            case 45:
                {
                alt49=3;
                }
                break;
            case 13:
                {
                alt49=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 49, 0, input);

                throw nvae;
            }

            switch (alt49) {
                case 1 :
                    // InternalDomainModel.g:3446:3: ( ( (lv_statement_id_arithmetic_0_0= ruleid_arithmetic ) ) ( (lv_statement_arithmetic_1_0= rulearithmetic ) )? )
                    {
                    // InternalDomainModel.g:3446:3: ( ( (lv_statement_id_arithmetic_0_0= ruleid_arithmetic ) ) ( (lv_statement_arithmetic_1_0= rulearithmetic ) )? )
                    // InternalDomainModel.g:3447:4: ( (lv_statement_id_arithmetic_0_0= ruleid_arithmetic ) ) ( (lv_statement_arithmetic_1_0= rulearithmetic ) )?
                    {
                    // InternalDomainModel.g:3447:4: ( (lv_statement_id_arithmetic_0_0= ruleid_arithmetic ) )
                    // InternalDomainModel.g:3448:5: (lv_statement_id_arithmetic_0_0= ruleid_arithmetic )
                    {
                    // InternalDomainModel.g:3448:5: (lv_statement_id_arithmetic_0_0= ruleid_arithmetic )
                    // InternalDomainModel.g:3449:6: lv_statement_id_arithmetic_0_0= ruleid_arithmetic
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithAccess().getStatement_id_arithmeticId_arithmeticParserRuleCall_0_0_0());
                      					
                    }
                    pushFollow(FOLLOW_29);
                    lv_statement_id_arithmetic_0_0=ruleid_arithmetic();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithRule());
                      						}
                      						set(
                      							current,
                      							"statement_id_arithmetic",
                      							lv_statement_id_arithmetic_0_0,
                      							"org.xtext.example.mydsl.DomainModel.id_arithmetic");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:3466:4: ( (lv_statement_arithmetic_1_0= rulearithmetic ) )?
                    int alt48=2;
                    int LA48_0 = input.LA(1);

                    if ( ((LA48_0>=44 && LA48_0<=48)) ) {
                        alt48=1;
                    }
                    switch (alt48) {
                        case 1 :
                            // InternalDomainModel.g:3467:5: (lv_statement_arithmetic_1_0= rulearithmetic )
                            {
                            // InternalDomainModel.g:3467:5: (lv_statement_arithmetic_1_0= rulearithmetic )
                            // InternalDomainModel.g:3468:6: lv_statement_arithmetic_1_0= rulearithmetic
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getArithAccess().getStatement_arithmeticArithmeticParserRuleCall_0_1_0());
                              					
                            }
                            pushFollow(FOLLOW_2);
                            lv_statement_arithmetic_1_0=rulearithmetic();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElementForParent(grammarAccess.getArithRule());
                              						}
                              						set(
                              							current,
                              							"statement_arithmetic",
                              							lv_statement_arithmetic_1_0,
                              							"org.xtext.example.mydsl.DomainModel.arithmetic");
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalDomainModel.g:3487:3: ( ( (lv_plus_2_0= ruleplus_1 ) ) ( (lv_statement_arith_3_0= rulearith ) ) )
                    {
                    // InternalDomainModel.g:3487:3: ( ( (lv_plus_2_0= ruleplus_1 ) ) ( (lv_statement_arith_3_0= rulearith ) ) )
                    // InternalDomainModel.g:3488:4: ( (lv_plus_2_0= ruleplus_1 ) ) ( (lv_statement_arith_3_0= rulearith ) )
                    {
                    // InternalDomainModel.g:3488:4: ( (lv_plus_2_0= ruleplus_1 ) )
                    // InternalDomainModel.g:3489:5: (lv_plus_2_0= ruleplus_1 )
                    {
                    // InternalDomainModel.g:3489:5: (lv_plus_2_0= ruleplus_1 )
                    // InternalDomainModel.g:3490:6: lv_plus_2_0= ruleplus_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithAccess().getPlusPlus_1ParserRuleCall_1_0_0());
                      					
                    }
                    pushFollow(FOLLOW_30);
                    lv_plus_2_0=ruleplus_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithRule());
                      						}
                      						set(
                      							current,
                      							"plus",
                      							lv_plus_2_0,
                      							"org.xtext.example.mydsl.DomainModel.plus_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:3507:4: ( (lv_statement_arith_3_0= rulearith ) )
                    // InternalDomainModel.g:3508:5: (lv_statement_arith_3_0= rulearith )
                    {
                    // InternalDomainModel.g:3508:5: (lv_statement_arith_3_0= rulearith )
                    // InternalDomainModel.g:3509:6: lv_statement_arith_3_0= rulearith
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithAccess().getStatement_arithArithParserRuleCall_1_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_arith_3_0=rulearith();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithRule());
                      						}
                      						set(
                      							current,
                      							"statement_arith",
                      							lv_statement_arith_3_0,
                      							"org.xtext.example.mydsl.DomainModel.arith");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalDomainModel.g:3528:3: ( ( (lv_minus_4_0= ruleminus_1 ) ) ( (lv_statement_arith_5_0= rulearith ) ) )
                    {
                    // InternalDomainModel.g:3528:3: ( ( (lv_minus_4_0= ruleminus_1 ) ) ( (lv_statement_arith_5_0= rulearith ) ) )
                    // InternalDomainModel.g:3529:4: ( (lv_minus_4_0= ruleminus_1 ) ) ( (lv_statement_arith_5_0= rulearith ) )
                    {
                    // InternalDomainModel.g:3529:4: ( (lv_minus_4_0= ruleminus_1 ) )
                    // InternalDomainModel.g:3530:5: (lv_minus_4_0= ruleminus_1 )
                    {
                    // InternalDomainModel.g:3530:5: (lv_minus_4_0= ruleminus_1 )
                    // InternalDomainModel.g:3531:6: lv_minus_4_0= ruleminus_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithAccess().getMinusMinus_1ParserRuleCall_2_0_0());
                      					
                    }
                    pushFollow(FOLLOW_30);
                    lv_minus_4_0=ruleminus_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithRule());
                      						}
                      						set(
                      							current,
                      							"minus",
                      							lv_minus_4_0,
                      							"org.xtext.example.mydsl.DomainModel.minus_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:3548:4: ( (lv_statement_arith_5_0= rulearith ) )
                    // InternalDomainModel.g:3549:5: (lv_statement_arith_5_0= rulearith )
                    {
                    // InternalDomainModel.g:3549:5: (lv_statement_arith_5_0= rulearith )
                    // InternalDomainModel.g:3550:6: lv_statement_arith_5_0= rulearith
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithAccess().getStatement_arithArithParserRuleCall_2_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_arith_5_0=rulearith();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithRule());
                      						}
                      						set(
                      							current,
                      							"statement_arith",
                      							lv_statement_arith_5_0,
                      							"org.xtext.example.mydsl.DomainModel.arith");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 4 :
                    // InternalDomainModel.g:3569:3: ( ( (lv_open_6_0= ruleopen_1 ) ) ( (lv_statement_arith_7_0= rulearith ) ) ( (lv_close_8_0= ruleclose_1 ) ) ( (lv_statement_next_parentesis_9_0= rulenext_parentesis ) ) )
                    {
                    // InternalDomainModel.g:3569:3: ( ( (lv_open_6_0= ruleopen_1 ) ) ( (lv_statement_arith_7_0= rulearith ) ) ( (lv_close_8_0= ruleclose_1 ) ) ( (lv_statement_next_parentesis_9_0= rulenext_parentesis ) ) )
                    // InternalDomainModel.g:3570:4: ( (lv_open_6_0= ruleopen_1 ) ) ( (lv_statement_arith_7_0= rulearith ) ) ( (lv_close_8_0= ruleclose_1 ) ) ( (lv_statement_next_parentesis_9_0= rulenext_parentesis ) )
                    {
                    // InternalDomainModel.g:3570:4: ( (lv_open_6_0= ruleopen_1 ) )
                    // InternalDomainModel.g:3571:5: (lv_open_6_0= ruleopen_1 )
                    {
                    // InternalDomainModel.g:3571:5: (lv_open_6_0= ruleopen_1 )
                    // InternalDomainModel.g:3572:6: lv_open_6_0= ruleopen_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithAccess().getOpenOpen_1ParserRuleCall_3_0_0());
                      					
                    }
                    pushFollow(FOLLOW_30);
                    lv_open_6_0=ruleopen_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithRule());
                      						}
                      						set(
                      							current,
                      							"open",
                      							lv_open_6_0,
                      							"org.xtext.example.mydsl.DomainModel.open_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:3589:4: ( (lv_statement_arith_7_0= rulearith ) )
                    // InternalDomainModel.g:3590:5: (lv_statement_arith_7_0= rulearith )
                    {
                    // InternalDomainModel.g:3590:5: (lv_statement_arith_7_0= rulearith )
                    // InternalDomainModel.g:3591:6: lv_statement_arith_7_0= rulearith
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithAccess().getStatement_arithArithParserRuleCall_3_1_0());
                      					
                    }
                    pushFollow(FOLLOW_6);
                    lv_statement_arith_7_0=rulearith();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithRule());
                      						}
                      						set(
                      							current,
                      							"statement_arith",
                      							lv_statement_arith_7_0,
                      							"org.xtext.example.mydsl.DomainModel.arith");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:3608:4: ( (lv_close_8_0= ruleclose_1 ) )
                    // InternalDomainModel.g:3609:5: (lv_close_8_0= ruleclose_1 )
                    {
                    // InternalDomainModel.g:3609:5: (lv_close_8_0= ruleclose_1 )
                    // InternalDomainModel.g:3610:6: lv_close_8_0= ruleclose_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithAccess().getCloseClose_1ParserRuleCall_3_2_0());
                      					
                    }
                    pushFollow(FOLLOW_31);
                    lv_close_8_0=ruleclose_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithRule());
                      						}
                      						set(
                      							current,
                      							"close",
                      							lv_close_8_0,
                      							"org.xtext.example.mydsl.DomainModel.close_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:3627:4: ( (lv_statement_next_parentesis_9_0= rulenext_parentesis ) )
                    // InternalDomainModel.g:3628:5: (lv_statement_next_parentesis_9_0= rulenext_parentesis )
                    {
                    // InternalDomainModel.g:3628:5: (lv_statement_next_parentesis_9_0= rulenext_parentesis )
                    // InternalDomainModel.g:3629:6: lv_statement_next_parentesis_9_0= rulenext_parentesis
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithAccess().getStatement_next_parentesisNext_parentesisParserRuleCall_3_3_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_next_parentesis_9_0=rulenext_parentesis();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithRule());
                      						}
                      						set(
                      							current,
                      							"statement_next_parentesis",
                      							lv_statement_next_parentesis_9_0,
                      							"org.xtext.example.mydsl.DomainModel.next_parentesis");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulearith"


    // $ANTLR start "entryRuleopen_1"
    // InternalDomainModel.g:3651:1: entryRuleopen_1 returns [String current=null] : iv_ruleopen_1= ruleopen_1 EOF ;
    public final String entryRuleopen_1() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleopen_1 = null;


        try {
            // InternalDomainModel.g:3651:46: (iv_ruleopen_1= ruleopen_1 EOF )
            // InternalDomainModel.g:3652:2: iv_ruleopen_1= ruleopen_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getOpen_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleopen_1=ruleopen_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleopen_1.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleopen_1"


    // $ANTLR start "ruleopen_1"
    // InternalDomainModel.g:3658:1: ruleopen_1 returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= '(' ;
    public final AntlrDatatypeRuleToken ruleopen_1() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalDomainModel.g:3664:2: (kw= '(' )
            // InternalDomainModel.g:3665:2: kw= '('
            {
            kw=(Token)match(input,13,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current.merge(kw);
              		newLeafNode(kw, grammarAccess.getOpen_1Access().getLeftParenthesisKeyword());
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleopen_1"


    // $ANTLR start "entryRuleclose_1"
    // InternalDomainModel.g:3673:1: entryRuleclose_1 returns [String current=null] : iv_ruleclose_1= ruleclose_1 EOF ;
    public final String entryRuleclose_1() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleclose_1 = null;


        try {
            // InternalDomainModel.g:3673:47: (iv_ruleclose_1= ruleclose_1 EOF )
            // InternalDomainModel.g:3674:2: iv_ruleclose_1= ruleclose_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getClose_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleclose_1=ruleclose_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleclose_1.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleclose_1"


    // $ANTLR start "ruleclose_1"
    // InternalDomainModel.g:3680:1: ruleclose_1 returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= ')' ;
    public final AntlrDatatypeRuleToken ruleclose_1() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalDomainModel.g:3686:2: (kw= ')' )
            // InternalDomainModel.g:3687:2: kw= ')'
            {
            kw=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current.merge(kw);
              		newLeafNode(kw, grammarAccess.getClose_1Access().getRightParenthesisKeyword());
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleclose_1"


    // $ANTLR start "entryRulenext_parentesis"
    // InternalDomainModel.g:3695:1: entryRulenext_parentesis returns [EObject current=null] : iv_rulenext_parentesis= rulenext_parentesis EOF ;
    public final EObject entryRulenext_parentesis() throws RecognitionException {
        EObject current = null;

        EObject iv_rulenext_parentesis = null;


        try {
            // InternalDomainModel.g:3695:56: (iv_rulenext_parentesis= rulenext_parentesis EOF )
            // InternalDomainModel.g:3696:2: iv_rulenext_parentesis= rulenext_parentesis EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getNext_parentesisRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulenext_parentesis=rulenext_parentesis();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulenext_parentesis; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulenext_parentesis"


    // $ANTLR start "rulenext_parentesis"
    // InternalDomainModel.g:3702:1: rulenext_parentesis returns [EObject current=null] : ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_arith_1_0= rulearith ) ) ) ;
    public final EObject rulenext_parentesis() throws RecognitionException {
        EObject current = null;

        EObject lv_statement_operation_0_0 = null;

        EObject lv_statement_arith_1_0 = null;



        	enterRule();

        try {
            // InternalDomainModel.g:3708:2: ( ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_arith_1_0= rulearith ) ) ) )
            // InternalDomainModel.g:3709:2: ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_arith_1_0= rulearith ) ) )
            {
            // InternalDomainModel.g:3709:2: ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_arith_1_0= rulearith ) ) )
            // InternalDomainModel.g:3710:3: ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_arith_1_0= rulearith ) )
            {
            // InternalDomainModel.g:3710:3: ( (lv_statement_operation_0_0= ruleoperation ) )
            // InternalDomainModel.g:3711:4: (lv_statement_operation_0_0= ruleoperation )
            {
            // InternalDomainModel.g:3711:4: (lv_statement_operation_0_0= ruleoperation )
            // InternalDomainModel.g:3712:5: lv_statement_operation_0_0= ruleoperation
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getNext_parentesisAccess().getStatement_operationOperationParserRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_30);
            lv_statement_operation_0_0=ruleoperation();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getNext_parentesisRule());
              					}
              					set(
              						current,
              						"statement_operation",
              						lv_statement_operation_0_0,
              						"org.xtext.example.mydsl.DomainModel.operation");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalDomainModel.g:3729:3: ( (lv_statement_arith_1_0= rulearith ) )
            // InternalDomainModel.g:3730:4: (lv_statement_arith_1_0= rulearith )
            {
            // InternalDomainModel.g:3730:4: (lv_statement_arith_1_0= rulearith )
            // InternalDomainModel.g:3731:5: lv_statement_arith_1_0= rulearith
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getNext_parentesisAccess().getStatement_arithArithParserRuleCall_1_0());
              				
            }
            pushFollow(FOLLOW_2);
            lv_statement_arith_1_0=rulearith();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getNext_parentesisRule());
              					}
              					set(
              						current,
              						"statement_arith",
              						lv_statement_arith_1_0,
              						"org.xtext.example.mydsl.DomainModel.arith");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulenext_parentesis"


    // $ANTLR start "entryRulearithmetic"
    // InternalDomainModel.g:3752:1: entryRulearithmetic returns [EObject current=null] : iv_rulearithmetic= rulearithmetic EOF ;
    public final EObject entryRulearithmetic() throws RecognitionException {
        EObject current = null;

        EObject iv_rulearithmetic = null;


        try {
            // InternalDomainModel.g:3752:51: (iv_rulearithmetic= rulearithmetic EOF )
            // InternalDomainModel.g:3753:2: iv_rulearithmetic= rulearithmetic EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getArithmeticRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulearithmetic=rulearithmetic();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulearithmetic; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulearithmetic"


    // $ANTLR start "rulearithmetic"
    // InternalDomainModel.g:3759:1: rulearithmetic returns [EObject current=null] : ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_arith_1_0= rulearith ) ) ) ;
    public final EObject rulearithmetic() throws RecognitionException {
        EObject current = null;

        EObject lv_statement_operation_0_0 = null;

        EObject lv_statement_arith_1_0 = null;



        	enterRule();

        try {
            // InternalDomainModel.g:3765:2: ( ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_arith_1_0= rulearith ) ) ) )
            // InternalDomainModel.g:3766:2: ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_arith_1_0= rulearith ) ) )
            {
            // InternalDomainModel.g:3766:2: ( ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_arith_1_0= rulearith ) ) )
            // InternalDomainModel.g:3767:3: ( (lv_statement_operation_0_0= ruleoperation ) ) ( (lv_statement_arith_1_0= rulearith ) )
            {
            // InternalDomainModel.g:3767:3: ( (lv_statement_operation_0_0= ruleoperation ) )
            // InternalDomainModel.g:3768:4: (lv_statement_operation_0_0= ruleoperation )
            {
            // InternalDomainModel.g:3768:4: (lv_statement_operation_0_0= ruleoperation )
            // InternalDomainModel.g:3769:5: lv_statement_operation_0_0= ruleoperation
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getArithmeticAccess().getStatement_operationOperationParserRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_30);
            lv_statement_operation_0_0=ruleoperation();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getArithmeticRule());
              					}
              					set(
              						current,
              						"statement_operation",
              						lv_statement_operation_0_0,
              						"org.xtext.example.mydsl.DomainModel.operation");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalDomainModel.g:3786:3: ( (lv_statement_arith_1_0= rulearith ) )
            // InternalDomainModel.g:3787:4: (lv_statement_arith_1_0= rulearith )
            {
            // InternalDomainModel.g:3787:4: (lv_statement_arith_1_0= rulearith )
            // InternalDomainModel.g:3788:5: lv_statement_arith_1_0= rulearith
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getArithmeticAccess().getStatement_arithArithParserRuleCall_1_0());
              				
            }
            pushFollow(FOLLOW_2);
            lv_statement_arith_1_0=rulearith();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getArithmeticRule());
              					}
              					set(
              						current,
              						"statement_arith",
              						lv_statement_arith_1_0,
              						"org.xtext.example.mydsl.DomainModel.arith");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulearithmetic"


    // $ANTLR start "entryRuleid_arithmetic"
    // InternalDomainModel.g:3809:1: entryRuleid_arithmetic returns [EObject current=null] : iv_ruleid_arithmetic= ruleid_arithmetic EOF ;
    public final EObject entryRuleid_arithmetic() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleid_arithmetic = null;


        try {
            // InternalDomainModel.g:3809:54: (iv_ruleid_arithmetic= ruleid_arithmetic EOF )
            // InternalDomainModel.g:3810:2: iv_ruleid_arithmetic= ruleid_arithmetic EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getId_arithmeticRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleid_arithmetic=ruleid_arithmetic();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleid_arithmetic; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleid_arithmetic"


    // $ANTLR start "ruleid_arithmetic"
    // InternalDomainModel.g:3816:1: ruleid_arithmetic returns [EObject current=null] : ( ( ( (lv_id_0_0= ruleid_1 ) ) ( (lv_statement_function_arith_1_0= rulefunction_arith ) )? ) | ( (lv_int_value_2_0= ruleint_value_1 ) ) | ( (lv_double_value_3_0= ruledouble_value_1 ) ) ) ;
    public final EObject ruleid_arithmetic() throws RecognitionException {
        EObject current = null;

        AntlrDatatypeRuleToken lv_id_0_0 = null;

        EObject lv_statement_function_arith_1_0 = null;

        AntlrDatatypeRuleToken lv_int_value_2_0 = null;

        AntlrDatatypeRuleToken lv_double_value_3_0 = null;



        	enterRule();

        try {
            // InternalDomainModel.g:3822:2: ( ( ( ( (lv_id_0_0= ruleid_1 ) ) ( (lv_statement_function_arith_1_0= rulefunction_arith ) )? ) | ( (lv_int_value_2_0= ruleint_value_1 ) ) | ( (lv_double_value_3_0= ruledouble_value_1 ) ) ) )
            // InternalDomainModel.g:3823:2: ( ( ( (lv_id_0_0= ruleid_1 ) ) ( (lv_statement_function_arith_1_0= rulefunction_arith ) )? ) | ( (lv_int_value_2_0= ruleint_value_1 ) ) | ( (lv_double_value_3_0= ruledouble_value_1 ) ) )
            {
            // InternalDomainModel.g:3823:2: ( ( ( (lv_id_0_0= ruleid_1 ) ) ( (lv_statement_function_arith_1_0= rulefunction_arith ) )? ) | ( (lv_int_value_2_0= ruleint_value_1 ) ) | ( (lv_double_value_3_0= ruledouble_value_1 ) ) )
            int alt51=3;
            switch ( input.LA(1) ) {
            case RULE_ID:
                {
                alt51=1;
                }
                break;
            case RULE_INT:
                {
                alt51=2;
                }
                break;
            case RULE_DOUBLE:
                {
                alt51=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 51, 0, input);

                throw nvae;
            }

            switch (alt51) {
                case 1 :
                    // InternalDomainModel.g:3824:3: ( ( (lv_id_0_0= ruleid_1 ) ) ( (lv_statement_function_arith_1_0= rulefunction_arith ) )? )
                    {
                    // InternalDomainModel.g:3824:3: ( ( (lv_id_0_0= ruleid_1 ) ) ( (lv_statement_function_arith_1_0= rulefunction_arith ) )? )
                    // InternalDomainModel.g:3825:4: ( (lv_id_0_0= ruleid_1 ) ) ( (lv_statement_function_arith_1_0= rulefunction_arith ) )?
                    {
                    // InternalDomainModel.g:3825:4: ( (lv_id_0_0= ruleid_1 ) )
                    // InternalDomainModel.g:3826:5: (lv_id_0_0= ruleid_1 )
                    {
                    // InternalDomainModel.g:3826:5: (lv_id_0_0= ruleid_1 )
                    // InternalDomainModel.g:3827:6: lv_id_0_0= ruleid_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getId_arithmeticAccess().getIdId_1ParserRuleCall_0_0_0());
                      					
                    }
                    pushFollow(FOLLOW_32);
                    lv_id_0_0=ruleid_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getId_arithmeticRule());
                      						}
                      						set(
                      							current,
                      							"id",
                      							lv_id_0_0,
                      							"org.xtext.example.mydsl.DomainModel.id_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:3844:4: ( (lv_statement_function_arith_1_0= rulefunction_arith ) )?
                    int alt50=2;
                    int LA50_0 = input.LA(1);

                    if ( (LA50_0==30||LA50_0==42) ) {
                        alt50=1;
                    }
                    switch (alt50) {
                        case 1 :
                            // InternalDomainModel.g:3845:5: (lv_statement_function_arith_1_0= rulefunction_arith )
                            {
                            // InternalDomainModel.g:3845:5: (lv_statement_function_arith_1_0= rulefunction_arith )
                            // InternalDomainModel.g:3846:6: lv_statement_function_arith_1_0= rulefunction_arith
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getId_arithmeticAccess().getStatement_function_arithFunction_arithParserRuleCall_0_1_0());
                              					
                            }
                            pushFollow(FOLLOW_2);
                            lv_statement_function_arith_1_0=rulefunction_arith();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElementForParent(grammarAccess.getId_arithmeticRule());
                              						}
                              						set(
                              							current,
                              							"statement_function_arith",
                              							lv_statement_function_arith_1_0,
                              							"org.xtext.example.mydsl.DomainModel.function_arith");
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalDomainModel.g:3865:3: ( (lv_int_value_2_0= ruleint_value_1 ) )
                    {
                    // InternalDomainModel.g:3865:3: ( (lv_int_value_2_0= ruleint_value_1 ) )
                    // InternalDomainModel.g:3866:4: (lv_int_value_2_0= ruleint_value_1 )
                    {
                    // InternalDomainModel.g:3866:4: (lv_int_value_2_0= ruleint_value_1 )
                    // InternalDomainModel.g:3867:5: lv_int_value_2_0= ruleint_value_1
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getId_arithmeticAccess().getInt_valueInt_value_1ParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_int_value_2_0=ruleint_value_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getId_arithmeticRule());
                      					}
                      					set(
                      						current,
                      						"int_value",
                      						lv_int_value_2_0,
                      						"org.xtext.example.mydsl.DomainModel.int_value_1");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalDomainModel.g:3885:3: ( (lv_double_value_3_0= ruledouble_value_1 ) )
                    {
                    // InternalDomainModel.g:3885:3: ( (lv_double_value_3_0= ruledouble_value_1 ) )
                    // InternalDomainModel.g:3886:4: (lv_double_value_3_0= ruledouble_value_1 )
                    {
                    // InternalDomainModel.g:3886:4: (lv_double_value_3_0= ruledouble_value_1 )
                    // InternalDomainModel.g:3887:5: lv_double_value_3_0= ruledouble_value_1
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getId_arithmeticAccess().getDouble_valueDouble_value_1ParserRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_double_value_3_0=ruledouble_value_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getId_arithmeticRule());
                      					}
                      					set(
                      						current,
                      						"double_value",
                      						lv_double_value_3_0,
                      						"org.xtext.example.mydsl.DomainModel.double_value_1");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleid_arithmetic"


    // $ANTLR start "entryRulefunction_arith"
    // InternalDomainModel.g:3908:1: entryRulefunction_arith returns [EObject current=null] : iv_rulefunction_arith= rulefunction_arith EOF ;
    public final EObject entryRulefunction_arith() throws RecognitionException {
        EObject current = null;

        EObject iv_rulefunction_arith = null;


        try {
            // InternalDomainModel.g:3908:55: (iv_rulefunction_arith= rulefunction_arith EOF )
            // InternalDomainModel.g:3909:2: iv_rulefunction_arith= rulefunction_arith EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getFunction_arithRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulefunction_arith=rulefunction_arith();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulefunction_arith; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulefunction_arith"


    // $ANTLR start "rulefunction_arith"
    // InternalDomainModel.g:3915:1: rulefunction_arith returns [EObject current=null] : ( ( ( (lv_ope_bra_0_0= ruleopen_bra_1 ) ) ( (lv_statement_arith_1_0= rulearith ) ) ( (lv_close_bra_2_0= ruleclose_bra_1 ) ) ) | ( ( (lv_point_3_0= rulepoint_1 ) ) ( (lv_size_4_0= rulesize_1 ) ) ) ) ;
    public final EObject rulefunction_arith() throws RecognitionException {
        EObject current = null;

        AntlrDatatypeRuleToken lv_ope_bra_0_0 = null;

        EObject lv_statement_arith_1_0 = null;

        AntlrDatatypeRuleToken lv_close_bra_2_0 = null;

        AntlrDatatypeRuleToken lv_point_3_0 = null;

        AntlrDatatypeRuleToken lv_size_4_0 = null;



        	enterRule();

        try {
            // InternalDomainModel.g:3921:2: ( ( ( ( (lv_ope_bra_0_0= ruleopen_bra_1 ) ) ( (lv_statement_arith_1_0= rulearith ) ) ( (lv_close_bra_2_0= ruleclose_bra_1 ) ) ) | ( ( (lv_point_3_0= rulepoint_1 ) ) ( (lv_size_4_0= rulesize_1 ) ) ) ) )
            // InternalDomainModel.g:3922:2: ( ( ( (lv_ope_bra_0_0= ruleopen_bra_1 ) ) ( (lv_statement_arith_1_0= rulearith ) ) ( (lv_close_bra_2_0= ruleclose_bra_1 ) ) ) | ( ( (lv_point_3_0= rulepoint_1 ) ) ( (lv_size_4_0= rulesize_1 ) ) ) )
            {
            // InternalDomainModel.g:3922:2: ( ( ( (lv_ope_bra_0_0= ruleopen_bra_1 ) ) ( (lv_statement_arith_1_0= rulearith ) ) ( (lv_close_bra_2_0= ruleclose_bra_1 ) ) ) | ( ( (lv_point_3_0= rulepoint_1 ) ) ( (lv_size_4_0= rulesize_1 ) ) ) )
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( (LA52_0==30) ) {
                alt52=1;
            }
            else if ( (LA52_0==42) ) {
                alt52=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 52, 0, input);

                throw nvae;
            }
            switch (alt52) {
                case 1 :
                    // InternalDomainModel.g:3923:3: ( ( (lv_ope_bra_0_0= ruleopen_bra_1 ) ) ( (lv_statement_arith_1_0= rulearith ) ) ( (lv_close_bra_2_0= ruleclose_bra_1 ) ) )
                    {
                    // InternalDomainModel.g:3923:3: ( ( (lv_ope_bra_0_0= ruleopen_bra_1 ) ) ( (lv_statement_arith_1_0= rulearith ) ) ( (lv_close_bra_2_0= ruleclose_bra_1 ) ) )
                    // InternalDomainModel.g:3924:4: ( (lv_ope_bra_0_0= ruleopen_bra_1 ) ) ( (lv_statement_arith_1_0= rulearith ) ) ( (lv_close_bra_2_0= ruleclose_bra_1 ) )
                    {
                    // InternalDomainModel.g:3924:4: ( (lv_ope_bra_0_0= ruleopen_bra_1 ) )
                    // InternalDomainModel.g:3925:5: (lv_ope_bra_0_0= ruleopen_bra_1 )
                    {
                    // InternalDomainModel.g:3925:5: (lv_ope_bra_0_0= ruleopen_bra_1 )
                    // InternalDomainModel.g:3926:6: lv_ope_bra_0_0= ruleopen_bra_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getFunction_arithAccess().getOpe_braOpen_bra_1ParserRuleCall_0_0_0());
                      					
                    }
                    pushFollow(FOLLOW_30);
                    lv_ope_bra_0_0=ruleopen_bra_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getFunction_arithRule());
                      						}
                      						set(
                      							current,
                      							"ope_bra",
                      							lv_ope_bra_0_0,
                      							"org.xtext.example.mydsl.DomainModel.open_bra_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:3943:4: ( (lv_statement_arith_1_0= rulearith ) )
                    // InternalDomainModel.g:3944:5: (lv_statement_arith_1_0= rulearith )
                    {
                    // InternalDomainModel.g:3944:5: (lv_statement_arith_1_0= rulearith )
                    // InternalDomainModel.g:3945:6: lv_statement_arith_1_0= rulearith
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getFunction_arithAccess().getStatement_arithArithParserRuleCall_0_1_0());
                      					
                    }
                    pushFollow(FOLLOW_33);
                    lv_statement_arith_1_0=rulearith();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getFunction_arithRule());
                      						}
                      						set(
                      							current,
                      							"statement_arith",
                      							lv_statement_arith_1_0,
                      							"org.xtext.example.mydsl.DomainModel.arith");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:3962:4: ( (lv_close_bra_2_0= ruleclose_bra_1 ) )
                    // InternalDomainModel.g:3963:5: (lv_close_bra_2_0= ruleclose_bra_1 )
                    {
                    // InternalDomainModel.g:3963:5: (lv_close_bra_2_0= ruleclose_bra_1 )
                    // InternalDomainModel.g:3964:6: lv_close_bra_2_0= ruleclose_bra_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getFunction_arithAccess().getClose_braClose_bra_1ParserRuleCall_0_2_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_close_bra_2_0=ruleclose_bra_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getFunction_arithRule());
                      						}
                      						set(
                      							current,
                      							"close_bra",
                      							lv_close_bra_2_0,
                      							"org.xtext.example.mydsl.DomainModel.close_bra_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalDomainModel.g:3983:3: ( ( (lv_point_3_0= rulepoint_1 ) ) ( (lv_size_4_0= rulesize_1 ) ) )
                    {
                    // InternalDomainModel.g:3983:3: ( ( (lv_point_3_0= rulepoint_1 ) ) ( (lv_size_4_0= rulesize_1 ) ) )
                    // InternalDomainModel.g:3984:4: ( (lv_point_3_0= rulepoint_1 ) ) ( (lv_size_4_0= rulesize_1 ) )
                    {
                    // InternalDomainModel.g:3984:4: ( (lv_point_3_0= rulepoint_1 ) )
                    // InternalDomainModel.g:3985:5: (lv_point_3_0= rulepoint_1 )
                    {
                    // InternalDomainModel.g:3985:5: (lv_point_3_0= rulepoint_1 )
                    // InternalDomainModel.g:3986:6: lv_point_3_0= rulepoint_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getFunction_arithAccess().getPointPoint_1ParserRuleCall_1_0_0());
                      					
                    }
                    pushFollow(FOLLOW_34);
                    lv_point_3_0=rulepoint_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getFunction_arithRule());
                      						}
                      						set(
                      							current,
                      							"point",
                      							lv_point_3_0,
                      							"org.xtext.example.mydsl.DomainModel.point_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalDomainModel.g:4003:4: ( (lv_size_4_0= rulesize_1 ) )
                    // InternalDomainModel.g:4004:5: (lv_size_4_0= rulesize_1 )
                    {
                    // InternalDomainModel.g:4004:5: (lv_size_4_0= rulesize_1 )
                    // InternalDomainModel.g:4005:6: lv_size_4_0= rulesize_1
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getFunction_arithAccess().getSizeSize_1ParserRuleCall_1_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_size_4_0=rulesize_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getFunction_arithRule());
                      						}
                      						set(
                      							current,
                      							"size",
                      							lv_size_4_0,
                      							"org.xtext.example.mydsl.DomainModel.size_1");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulefunction_arith"


    // $ANTLR start "entryRuleoperation"
    // InternalDomainModel.g:4027:1: entryRuleoperation returns [EObject current=null] : iv_ruleoperation= ruleoperation EOF ;
    public final EObject entryRuleoperation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleoperation = null;


        try {
            // InternalDomainModel.g:4027:50: (iv_ruleoperation= ruleoperation EOF )
            // InternalDomainModel.g:4028:2: iv_ruleoperation= ruleoperation EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getOperationRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleoperation=ruleoperation();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleoperation; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleoperation"


    // $ANTLR start "ruleoperation"
    // InternalDomainModel.g:4034:1: ruleoperation returns [EObject current=null] : ( ( (lv_plus_0_0= ruleplus_1 ) ) | ( (lv_minus_1_0= ruleminus_1 ) ) | ( (lv_multiplication_2_0= rulemultiplication_1 ) ) | ( (lv_div_3_0= rulediv_1 ) ) | ( (lv_mod_4_0= rulemod_1 ) ) ) ;
    public final EObject ruleoperation() throws RecognitionException {
        EObject current = null;

        AntlrDatatypeRuleToken lv_plus_0_0 = null;

        AntlrDatatypeRuleToken lv_minus_1_0 = null;

        AntlrDatatypeRuleToken lv_multiplication_2_0 = null;

        AntlrDatatypeRuleToken lv_div_3_0 = null;

        AntlrDatatypeRuleToken lv_mod_4_0 = null;



        	enterRule();

        try {
            // InternalDomainModel.g:4040:2: ( ( ( (lv_plus_0_0= ruleplus_1 ) ) | ( (lv_minus_1_0= ruleminus_1 ) ) | ( (lv_multiplication_2_0= rulemultiplication_1 ) ) | ( (lv_div_3_0= rulediv_1 ) ) | ( (lv_mod_4_0= rulemod_1 ) ) ) )
            // InternalDomainModel.g:4041:2: ( ( (lv_plus_0_0= ruleplus_1 ) ) | ( (lv_minus_1_0= ruleminus_1 ) ) | ( (lv_multiplication_2_0= rulemultiplication_1 ) ) | ( (lv_div_3_0= rulediv_1 ) ) | ( (lv_mod_4_0= rulemod_1 ) ) )
            {
            // InternalDomainModel.g:4041:2: ( ( (lv_plus_0_0= ruleplus_1 ) ) | ( (lv_minus_1_0= ruleminus_1 ) ) | ( (lv_multiplication_2_0= rulemultiplication_1 ) ) | ( (lv_div_3_0= rulediv_1 ) ) | ( (lv_mod_4_0= rulemod_1 ) ) )
            int alt53=5;
            switch ( input.LA(1) ) {
            case 44:
                {
                alt53=1;
                }
                break;
            case 45:
                {
                alt53=2;
                }
                break;
            case 46:
                {
                alt53=3;
                }
                break;
            case 47:
                {
                alt53=4;
                }
                break;
            case 48:
                {
                alt53=5;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 53, 0, input);

                throw nvae;
            }

            switch (alt53) {
                case 1 :
                    // InternalDomainModel.g:4042:3: ( (lv_plus_0_0= ruleplus_1 ) )
                    {
                    // InternalDomainModel.g:4042:3: ( (lv_plus_0_0= ruleplus_1 ) )
                    // InternalDomainModel.g:4043:4: (lv_plus_0_0= ruleplus_1 )
                    {
                    // InternalDomainModel.g:4043:4: (lv_plus_0_0= ruleplus_1 )
                    // InternalDomainModel.g:4044:5: lv_plus_0_0= ruleplus_1
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getOperationAccess().getPlusPlus_1ParserRuleCall_0_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_plus_0_0=ruleplus_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getOperationRule());
                      					}
                      					set(
                      						current,
                      						"plus",
                      						lv_plus_0_0,
                      						"org.xtext.example.mydsl.DomainModel.plus_1");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalDomainModel.g:4062:3: ( (lv_minus_1_0= ruleminus_1 ) )
                    {
                    // InternalDomainModel.g:4062:3: ( (lv_minus_1_0= ruleminus_1 ) )
                    // InternalDomainModel.g:4063:4: (lv_minus_1_0= ruleminus_1 )
                    {
                    // InternalDomainModel.g:4063:4: (lv_minus_1_0= ruleminus_1 )
                    // InternalDomainModel.g:4064:5: lv_minus_1_0= ruleminus_1
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getOperationAccess().getMinusMinus_1ParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_minus_1_0=ruleminus_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getOperationRule());
                      					}
                      					set(
                      						current,
                      						"minus",
                      						lv_minus_1_0,
                      						"org.xtext.example.mydsl.DomainModel.minus_1");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalDomainModel.g:4082:3: ( (lv_multiplication_2_0= rulemultiplication_1 ) )
                    {
                    // InternalDomainModel.g:4082:3: ( (lv_multiplication_2_0= rulemultiplication_1 ) )
                    // InternalDomainModel.g:4083:4: (lv_multiplication_2_0= rulemultiplication_1 )
                    {
                    // InternalDomainModel.g:4083:4: (lv_multiplication_2_0= rulemultiplication_1 )
                    // InternalDomainModel.g:4084:5: lv_multiplication_2_0= rulemultiplication_1
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getOperationAccess().getMultiplicationMultiplication_1ParserRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_multiplication_2_0=rulemultiplication_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getOperationRule());
                      					}
                      					set(
                      						current,
                      						"multiplication",
                      						lv_multiplication_2_0,
                      						"org.xtext.example.mydsl.DomainModel.multiplication_1");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;
                case 4 :
                    // InternalDomainModel.g:4102:3: ( (lv_div_3_0= rulediv_1 ) )
                    {
                    // InternalDomainModel.g:4102:3: ( (lv_div_3_0= rulediv_1 ) )
                    // InternalDomainModel.g:4103:4: (lv_div_3_0= rulediv_1 )
                    {
                    // InternalDomainModel.g:4103:4: (lv_div_3_0= rulediv_1 )
                    // InternalDomainModel.g:4104:5: lv_div_3_0= rulediv_1
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getOperationAccess().getDivDiv_1ParserRuleCall_3_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_div_3_0=rulediv_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getOperationRule());
                      					}
                      					set(
                      						current,
                      						"div",
                      						lv_div_3_0,
                      						"org.xtext.example.mydsl.DomainModel.div_1");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;
                case 5 :
                    // InternalDomainModel.g:4122:3: ( (lv_mod_4_0= rulemod_1 ) )
                    {
                    // InternalDomainModel.g:4122:3: ( (lv_mod_4_0= rulemod_1 ) )
                    // InternalDomainModel.g:4123:4: (lv_mod_4_0= rulemod_1 )
                    {
                    // InternalDomainModel.g:4123:4: (lv_mod_4_0= rulemod_1 )
                    // InternalDomainModel.g:4124:5: lv_mod_4_0= rulemod_1
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getOperationAccess().getModMod_1ParserRuleCall_4_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_mod_4_0=rulemod_1();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getOperationRule());
                      					}
                      					set(
                      						current,
                      						"mod",
                      						lv_mod_4_0,
                      						"org.xtext.example.mydsl.DomainModel.mod_1");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleoperation"


    // $ANTLR start "entryRuleint_value_1"
    // InternalDomainModel.g:4145:1: entryRuleint_value_1 returns [String current=null] : iv_ruleint_value_1= ruleint_value_1 EOF ;
    public final String entryRuleint_value_1() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleint_value_1 = null;


        try {
            // InternalDomainModel.g:4145:51: (iv_ruleint_value_1= ruleint_value_1 EOF )
            // InternalDomainModel.g:4146:2: iv_ruleint_value_1= ruleint_value_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getInt_value_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleint_value_1=ruleint_value_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleint_value_1.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleint_value_1"


    // $ANTLR start "ruleint_value_1"
    // InternalDomainModel.g:4152:1: ruleint_value_1 returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : this_INT_0= RULE_INT ;
    public final AntlrDatatypeRuleToken ruleint_value_1() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_INT_0=null;


        	enterRule();

        try {
            // InternalDomainModel.g:4158:2: (this_INT_0= RULE_INT )
            // InternalDomainModel.g:4159:2: this_INT_0= RULE_INT
            {
            this_INT_0=(Token)match(input,RULE_INT,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current.merge(this_INT_0);
              	
            }
            if ( state.backtracking==0 ) {

              		newLeafNode(this_INT_0, grammarAccess.getInt_value_1Access().getINTTerminalRuleCall());
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleint_value_1"


    // $ANTLR start "entryRuledouble_value_1"
    // InternalDomainModel.g:4169:1: entryRuledouble_value_1 returns [String current=null] : iv_ruledouble_value_1= ruledouble_value_1 EOF ;
    public final String entryRuledouble_value_1() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruledouble_value_1 = null;


        try {
            // InternalDomainModel.g:4169:54: (iv_ruledouble_value_1= ruledouble_value_1 EOF )
            // InternalDomainModel.g:4170:2: iv_ruledouble_value_1= ruledouble_value_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getDouble_value_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruledouble_value_1=ruledouble_value_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruledouble_value_1.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuledouble_value_1"


    // $ANTLR start "ruledouble_value_1"
    // InternalDomainModel.g:4176:1: ruledouble_value_1 returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : this_DOUBLE_0= RULE_DOUBLE ;
    public final AntlrDatatypeRuleToken ruledouble_value_1() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_DOUBLE_0=null;


        	enterRule();

        try {
            // InternalDomainModel.g:4182:2: (this_DOUBLE_0= RULE_DOUBLE )
            // InternalDomainModel.g:4183:2: this_DOUBLE_0= RULE_DOUBLE
            {
            this_DOUBLE_0=(Token)match(input,RULE_DOUBLE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current.merge(this_DOUBLE_0);
              	
            }
            if ( state.backtracking==0 ) {

              		newLeafNode(this_DOUBLE_0, grammarAccess.getDouble_value_1Access().getDOUBLETerminalRuleCall());
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruledouble_value_1"


    // $ANTLR start "entryRuleid_1"
    // InternalDomainModel.g:4193:1: entryRuleid_1 returns [String current=null] : iv_ruleid_1= ruleid_1 EOF ;
    public final String entryRuleid_1() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleid_1 = null;


        try {
            // InternalDomainModel.g:4193:44: (iv_ruleid_1= ruleid_1 EOF )
            // InternalDomainModel.g:4194:2: iv_ruleid_1= ruleid_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getId_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleid_1=ruleid_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleid_1.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleid_1"


    // $ANTLR start "ruleid_1"
    // InternalDomainModel.g:4200:1: ruleid_1 returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : this_ID_0= RULE_ID ;
    public final AntlrDatatypeRuleToken ruleid_1() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_ID_0=null;


        	enterRule();

        try {
            // InternalDomainModel.g:4206:2: (this_ID_0= RULE_ID )
            // InternalDomainModel.g:4207:2: this_ID_0= RULE_ID
            {
            this_ID_0=(Token)match(input,RULE_ID,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current.merge(this_ID_0);
              	
            }
            if ( state.backtracking==0 ) {

              		newLeafNode(this_ID_0, grammarAccess.getId_1Access().getIDTerminalRuleCall());
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleid_1"


    // $ANTLR start "entryRulepoint_1"
    // InternalDomainModel.g:4217:1: entryRulepoint_1 returns [String current=null] : iv_rulepoint_1= rulepoint_1 EOF ;
    public final String entryRulepoint_1() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_rulepoint_1 = null;


        try {
            // InternalDomainModel.g:4217:47: (iv_rulepoint_1= rulepoint_1 EOF )
            // InternalDomainModel.g:4218:2: iv_rulepoint_1= rulepoint_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPoint_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulepoint_1=rulepoint_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulepoint_1.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulepoint_1"


    // $ANTLR start "rulepoint_1"
    // InternalDomainModel.g:4224:1: rulepoint_1 returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= '.' ;
    public final AntlrDatatypeRuleToken rulepoint_1() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalDomainModel.g:4230:2: (kw= '.' )
            // InternalDomainModel.g:4231:2: kw= '.'
            {
            kw=(Token)match(input,42,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current.merge(kw);
              		newLeafNode(kw, grammarAccess.getPoint_1Access().getFullStopKeyword());
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulepoint_1"


    // $ANTLR start "entryRulesize_1"
    // InternalDomainModel.g:4239:1: entryRulesize_1 returns [String current=null] : iv_rulesize_1= rulesize_1 EOF ;
    public final String entryRulesize_1() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_rulesize_1 = null;


        try {
            // InternalDomainModel.g:4239:46: (iv_rulesize_1= rulesize_1 EOF )
            // InternalDomainModel.g:4240:2: iv_rulesize_1= rulesize_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getSize_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulesize_1=rulesize_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulesize_1.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulesize_1"


    // $ANTLR start "rulesize_1"
    // InternalDomainModel.g:4246:1: rulesize_1 returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= 'size' ;
    public final AntlrDatatypeRuleToken rulesize_1() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalDomainModel.g:4252:2: (kw= 'size' )
            // InternalDomainModel.g:4253:2: kw= 'size'
            {
            kw=(Token)match(input,43,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current.merge(kw);
              		newLeafNode(kw, grammarAccess.getSize_1Access().getSizeKeyword());
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulesize_1"


    // $ANTLR start "entryRuleopen_bra_1"
    // InternalDomainModel.g:4261:1: entryRuleopen_bra_1 returns [String current=null] : iv_ruleopen_bra_1= ruleopen_bra_1 EOF ;
    public final String entryRuleopen_bra_1() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleopen_bra_1 = null;


        try {
            // InternalDomainModel.g:4261:50: (iv_ruleopen_bra_1= ruleopen_bra_1 EOF )
            // InternalDomainModel.g:4262:2: iv_ruleopen_bra_1= ruleopen_bra_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getOpen_bra_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleopen_bra_1=ruleopen_bra_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleopen_bra_1.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleopen_bra_1"


    // $ANTLR start "ruleopen_bra_1"
    // InternalDomainModel.g:4268:1: ruleopen_bra_1 returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= '[' ;
    public final AntlrDatatypeRuleToken ruleopen_bra_1() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalDomainModel.g:4274:2: (kw= '[' )
            // InternalDomainModel.g:4275:2: kw= '['
            {
            kw=(Token)match(input,30,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current.merge(kw);
              		newLeafNode(kw, grammarAccess.getOpen_bra_1Access().getLeftSquareBracketKeyword());
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleopen_bra_1"


    // $ANTLR start "entryRuleclose_bra_1"
    // InternalDomainModel.g:4283:1: entryRuleclose_bra_1 returns [String current=null] : iv_ruleclose_bra_1= ruleclose_bra_1 EOF ;
    public final String entryRuleclose_bra_1() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleclose_bra_1 = null;


        try {
            // InternalDomainModel.g:4283:51: (iv_ruleclose_bra_1= ruleclose_bra_1 EOF )
            // InternalDomainModel.g:4284:2: iv_ruleclose_bra_1= ruleclose_bra_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getClose_bra_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleclose_bra_1=ruleclose_bra_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleclose_bra_1.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleclose_bra_1"


    // $ANTLR start "ruleclose_bra_1"
    // InternalDomainModel.g:4290:1: ruleclose_bra_1 returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= ']' ;
    public final AntlrDatatypeRuleToken ruleclose_bra_1() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalDomainModel.g:4296:2: (kw= ']' )
            // InternalDomainModel.g:4297:2: kw= ']'
            {
            kw=(Token)match(input,32,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current.merge(kw);
              		newLeafNode(kw, grammarAccess.getClose_bra_1Access().getRightSquareBracketKeyword());
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleclose_bra_1"


    // $ANTLR start "entryRuleplus_1"
    // InternalDomainModel.g:4305:1: entryRuleplus_1 returns [String current=null] : iv_ruleplus_1= ruleplus_1 EOF ;
    public final String entryRuleplus_1() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleplus_1 = null;


        try {
            // InternalDomainModel.g:4305:46: (iv_ruleplus_1= ruleplus_1 EOF )
            // InternalDomainModel.g:4306:2: iv_ruleplus_1= ruleplus_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPlus_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleplus_1=ruleplus_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleplus_1.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleplus_1"


    // $ANTLR start "ruleplus_1"
    // InternalDomainModel.g:4312:1: ruleplus_1 returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= '+' ;
    public final AntlrDatatypeRuleToken ruleplus_1() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalDomainModel.g:4318:2: (kw= '+' )
            // InternalDomainModel.g:4319:2: kw= '+'
            {
            kw=(Token)match(input,44,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current.merge(kw);
              		newLeafNode(kw, grammarAccess.getPlus_1Access().getPlusSignKeyword());
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleplus_1"


    // $ANTLR start "entryRuleminus_1"
    // InternalDomainModel.g:4327:1: entryRuleminus_1 returns [String current=null] : iv_ruleminus_1= ruleminus_1 EOF ;
    public final String entryRuleminus_1() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleminus_1 = null;


        try {
            // InternalDomainModel.g:4327:47: (iv_ruleminus_1= ruleminus_1 EOF )
            // InternalDomainModel.g:4328:2: iv_ruleminus_1= ruleminus_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getMinus_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleminus_1=ruleminus_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleminus_1.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleminus_1"


    // $ANTLR start "ruleminus_1"
    // InternalDomainModel.g:4334:1: ruleminus_1 returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= '-' ;
    public final AntlrDatatypeRuleToken ruleminus_1() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalDomainModel.g:4340:2: (kw= '-' )
            // InternalDomainModel.g:4341:2: kw= '-'
            {
            kw=(Token)match(input,45,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current.merge(kw);
              		newLeafNode(kw, grammarAccess.getMinus_1Access().getHyphenMinusKeyword());
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleminus_1"


    // $ANTLR start "entryRulemultiplication_1"
    // InternalDomainModel.g:4349:1: entryRulemultiplication_1 returns [String current=null] : iv_rulemultiplication_1= rulemultiplication_1 EOF ;
    public final String entryRulemultiplication_1() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_rulemultiplication_1 = null;


        try {
            // InternalDomainModel.g:4349:56: (iv_rulemultiplication_1= rulemultiplication_1 EOF )
            // InternalDomainModel.g:4350:2: iv_rulemultiplication_1= rulemultiplication_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getMultiplication_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulemultiplication_1=rulemultiplication_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulemultiplication_1.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulemultiplication_1"


    // $ANTLR start "rulemultiplication_1"
    // InternalDomainModel.g:4356:1: rulemultiplication_1 returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= '*' ;
    public final AntlrDatatypeRuleToken rulemultiplication_1() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalDomainModel.g:4362:2: (kw= '*' )
            // InternalDomainModel.g:4363:2: kw= '*'
            {
            kw=(Token)match(input,46,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current.merge(kw);
              		newLeafNode(kw, grammarAccess.getMultiplication_1Access().getAsteriskKeyword());
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulemultiplication_1"


    // $ANTLR start "entryRulediv_1"
    // InternalDomainModel.g:4371:1: entryRulediv_1 returns [String current=null] : iv_rulediv_1= rulediv_1 EOF ;
    public final String entryRulediv_1() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_rulediv_1 = null;


        try {
            // InternalDomainModel.g:4371:45: (iv_rulediv_1= rulediv_1 EOF )
            // InternalDomainModel.g:4372:2: iv_rulediv_1= rulediv_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getDiv_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulediv_1=rulediv_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulediv_1.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulediv_1"


    // $ANTLR start "rulediv_1"
    // InternalDomainModel.g:4378:1: rulediv_1 returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= '/' ;
    public final AntlrDatatypeRuleToken rulediv_1() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalDomainModel.g:4384:2: (kw= '/' )
            // InternalDomainModel.g:4385:2: kw= '/'
            {
            kw=(Token)match(input,47,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current.merge(kw);
              		newLeafNode(kw, grammarAccess.getDiv_1Access().getSolidusKeyword());
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulediv_1"


    // $ANTLR start "entryRulemod_1"
    // InternalDomainModel.g:4393:1: entryRulemod_1 returns [String current=null] : iv_rulemod_1= rulemod_1 EOF ;
    public final String entryRulemod_1() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_rulemod_1 = null;


        try {
            // InternalDomainModel.g:4393:45: (iv_rulemod_1= rulemod_1 EOF )
            // InternalDomainModel.g:4394:2: iv_rulemod_1= rulemod_1 EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getMod_1Rule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulemod_1=rulemod_1();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulemod_1.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulemod_1"


    // $ANTLR start "rulemod_1"
    // InternalDomainModel.g:4400:1: rulemod_1 returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= '%' ;
    public final AntlrDatatypeRuleToken rulemod_1() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalDomainModel.g:4406:2: (kw= '%' )
            // InternalDomainModel.g:4407:2: kw= '%'
            {
            kw=(Token)match(input,48,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current.merge(kw);
              		newLeafNode(kw, grammarAccess.getMod_1Access().getPercentSignKeyword());
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulemod_1"

    // $ANTLR start synpred50_InternalDomainModel
    public final void synpred50_InternalDomainModel_fragment() throws RecognitionException {   
        EObject lv_statement_conditional_4_0 = null;


        // InternalDomainModel.g:2432:5: ( (lv_statement_conditional_4_0= ruleconditional ) )
        // InternalDomainModel.g:2432:5: (lv_statement_conditional_4_0= ruleconditional )
        {
        // InternalDomainModel.g:2432:5: (lv_statement_conditional_4_0= ruleconditional )
        // InternalDomainModel.g:2433:6: lv_statement_conditional_4_0= ruleconditional
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getCondexprAccess().getStatement_conditionalConditionalParserRuleCall_0_4_0());
          					
        }
        pushFollow(FOLLOW_2);
        lv_statement_conditional_4_0=ruleconditional();

        state._fsp--;
        if (state.failed) return ;

        }


        }
    }
    // $ANTLR end synpred50_InternalDomainModel

    // $ANTLR start synpred52_InternalDomainModel
    public final void synpred52_InternalDomainModel_fragment() throws RecognitionException {   
        AntlrDatatypeRuleToken lv_open_5_0 = null;

        EObject lv_statement_aux_condexpr_6_0 = null;


        // InternalDomainModel.g:2452:3: ( ( ( (lv_open_5_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) ) ) )
        // InternalDomainModel.g:2452:3: ( ( (lv_open_5_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) ) )
        {
        // InternalDomainModel.g:2452:3: ( ( (lv_open_5_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) ) )
        // InternalDomainModel.g:2453:4: ( (lv_open_5_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) )
        {
        // InternalDomainModel.g:2453:4: ( (lv_open_5_0= ruleopen_1 ) )
        // InternalDomainModel.g:2454:5: (lv_open_5_0= ruleopen_1 )
        {
        // InternalDomainModel.g:2454:5: (lv_open_5_0= ruleopen_1 )
        // InternalDomainModel.g:2455:6: lv_open_5_0= ruleopen_1
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getCondexprAccess().getOpenOpen_1ParserRuleCall_1_0_0());
          					
        }
        pushFollow(FOLLOW_24);
        lv_open_5_0=ruleopen_1();

        state._fsp--;
        if (state.failed) return ;

        }


        }

        // InternalDomainModel.g:2472:4: ( (lv_statement_aux_condexpr_6_0= ruleaux_condexpr ) )
        // InternalDomainModel.g:2473:5: (lv_statement_aux_condexpr_6_0= ruleaux_condexpr )
        {
        // InternalDomainModel.g:2473:5: (lv_statement_aux_condexpr_6_0= ruleaux_condexpr )
        // InternalDomainModel.g:2474:6: lv_statement_aux_condexpr_6_0= ruleaux_condexpr
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getCondexprAccess().getStatement_aux_condexprAux_condexprParserRuleCall_1_1_0());
          					
        }
        pushFollow(FOLLOW_2);
        lv_statement_aux_condexpr_6_0=ruleaux_condexpr();

        state._fsp--;
        if (state.failed) return ;

        }


        }


        }


        }
    }
    // $ANTLR end synpred52_InternalDomainModel

    // $ANTLR start synpred53_InternalDomainModel
    public final void synpred53_InternalDomainModel_fragment() throws RecognitionException {   
        AntlrDatatypeRuleToken lv_open_0_0 = null;

        EObject lv_statement_aux_condexpr_1_0 = null;


        // InternalDomainModel.g:2552:3: ( ( ( (lv_open_0_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ) )
        // InternalDomainModel.g:2552:3: ( ( (lv_open_0_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) )
        {
        // InternalDomainModel.g:2552:3: ( ( (lv_open_0_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) )
        // InternalDomainModel.g:2553:4: ( (lv_open_0_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) )
        {
        // InternalDomainModel.g:2553:4: ( (lv_open_0_0= ruleopen_1 ) )
        // InternalDomainModel.g:2554:5: (lv_open_0_0= ruleopen_1 )
        {
        // InternalDomainModel.g:2554:5: (lv_open_0_0= ruleopen_1 )
        // InternalDomainModel.g:2555:6: lv_open_0_0= ruleopen_1
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getConditionals_1Access().getOpenOpen_1ParserRuleCall_0_0_0());
          					
        }
        pushFollow(FOLLOW_24);
        lv_open_0_0=ruleopen_1();

        state._fsp--;
        if (state.failed) return ;

        }


        }

        // InternalDomainModel.g:2572:4: ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) )
        // InternalDomainModel.g:2573:5: (lv_statement_aux_condexpr_1_0= ruleaux_condexpr )
        {
        // InternalDomainModel.g:2573:5: (lv_statement_aux_condexpr_1_0= ruleaux_condexpr )
        // InternalDomainModel.g:2574:6: lv_statement_aux_condexpr_1_0= ruleaux_condexpr
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getConditionals_1Access().getStatement_aux_condexprAux_condexprParserRuleCall_0_1_0());
          					
        }
        pushFollow(FOLLOW_2);
        lv_statement_aux_condexpr_1_0=ruleaux_condexpr();

        state._fsp--;
        if (state.failed) return ;

        }


        }


        }


        }
    }
    // $ANTLR end synpred53_InternalDomainModel

    // $ANTLR start synpred54_InternalDomainModel
    public final void synpred54_InternalDomainModel_fragment() throws RecognitionException {   
        EObject lv_statement_conditional_3_0 = null;


        // InternalDomainModel.g:2614:5: ( (lv_statement_conditional_3_0= ruleconditional ) )
        // InternalDomainModel.g:2614:5: (lv_statement_conditional_3_0= ruleconditional )
        {
        // InternalDomainModel.g:2614:5: (lv_statement_conditional_3_0= ruleconditional )
        // InternalDomainModel.g:2615:6: lv_statement_conditional_3_0= ruleconditional
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getConditionals_1Access().getStatement_conditionalConditionalParserRuleCall_1_1_0());
          					
        }
        pushFollow(FOLLOW_2);
        lv_statement_conditional_3_0=ruleconditional();

        state._fsp--;
        if (state.failed) return ;

        }


        }
    }
    // $ANTLR end synpred54_InternalDomainModel

    // $ANTLR start synpred55_InternalDomainModel
    public final void synpred55_InternalDomainModel_fragment() throws RecognitionException {   
        EObject lv_statement_arith_2_0 = null;

        EObject lv_statement_conditional_3_0 = null;


        // InternalDomainModel.g:2593:3: ( ( ( (lv_statement_arith_2_0= rulearith ) ) ( (lv_statement_conditional_3_0= ruleconditional ) )? ) )
        // InternalDomainModel.g:2593:3: ( ( (lv_statement_arith_2_0= rulearith ) ) ( (lv_statement_conditional_3_0= ruleconditional ) )? )
        {
        // InternalDomainModel.g:2593:3: ( ( (lv_statement_arith_2_0= rulearith ) ) ( (lv_statement_conditional_3_0= ruleconditional ) )? )
        // InternalDomainModel.g:2594:4: ( (lv_statement_arith_2_0= rulearith ) ) ( (lv_statement_conditional_3_0= ruleconditional ) )?
        {
        // InternalDomainModel.g:2594:4: ( (lv_statement_arith_2_0= rulearith ) )
        // InternalDomainModel.g:2595:5: (lv_statement_arith_2_0= rulearith )
        {
        // InternalDomainModel.g:2595:5: (lv_statement_arith_2_0= rulearith )
        // InternalDomainModel.g:2596:6: lv_statement_arith_2_0= rulearith
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getConditionals_1Access().getStatement_arithArithParserRuleCall_1_0_0());
          					
        }
        pushFollow(FOLLOW_25);
        lv_statement_arith_2_0=rulearith();

        state._fsp--;
        if (state.failed) return ;

        }


        }

        // InternalDomainModel.g:2613:4: ( (lv_statement_conditional_3_0= ruleconditional ) )?
        int alt75=2;
        int LA75_0 = input.LA(1);

        if ( ((LA75_0>=33 && LA75_0<=38)||(LA75_0>=40 && LA75_0<=41)) ) {
            alt75=1;
        }
        switch (alt75) {
            case 1 :
                // InternalDomainModel.g:2614:5: (lv_statement_conditional_3_0= ruleconditional )
                {
                // InternalDomainModel.g:2614:5: (lv_statement_conditional_3_0= ruleconditional )
                // InternalDomainModel.g:2615:6: lv_statement_conditional_3_0= ruleconditional
                {
                if ( state.backtracking==0 ) {

                  						newCompositeNode(grammarAccess.getConditionals_1Access().getStatement_conditionalConditionalParserRuleCall_1_1_0());
                  					
                }
                pushFollow(FOLLOW_2);
                lv_statement_conditional_3_0=ruleconditional();

                state._fsp--;
                if (state.failed) return ;

                }


                }
                break;

        }


        }


        }
    }
    // $ANTLR end synpred55_InternalDomainModel

    // $ANTLR start synpred56_InternalDomainModel
    public final void synpred56_InternalDomainModel_fragment() throws RecognitionException {   
        AntlrDatatypeRuleToken lv_open_0_0 = null;

        EObject lv_statement_aux_condexpr_1_0 = null;

        EObject lv_statement_optional_parentesis_2_0 = null;


        // InternalDomainModel.g:2731:3: ( ( ( (lv_open_0_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) ) ) )
        // InternalDomainModel.g:2731:3: ( ( (lv_open_0_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) ) )
        {
        // InternalDomainModel.g:2731:3: ( ( (lv_open_0_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) ) )
        // InternalDomainModel.g:2732:4: ( (lv_open_0_0= ruleopen_1 ) ) ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) ) ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) )
        {
        // InternalDomainModel.g:2732:4: ( (lv_open_0_0= ruleopen_1 ) )
        // InternalDomainModel.g:2733:5: (lv_open_0_0= ruleopen_1 )
        {
        // InternalDomainModel.g:2733:5: (lv_open_0_0= ruleopen_1 )
        // InternalDomainModel.g:2734:6: lv_open_0_0= ruleopen_1
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getAux_condexprAccess().getOpenOpen_1ParserRuleCall_0_0_0());
          					
        }
        pushFollow(FOLLOW_24);
        lv_open_0_0=ruleopen_1();

        state._fsp--;
        if (state.failed) return ;

        }


        }

        // InternalDomainModel.g:2751:4: ( (lv_statement_aux_condexpr_1_0= ruleaux_condexpr ) )
        // InternalDomainModel.g:2752:5: (lv_statement_aux_condexpr_1_0= ruleaux_condexpr )
        {
        // InternalDomainModel.g:2752:5: (lv_statement_aux_condexpr_1_0= ruleaux_condexpr )
        // InternalDomainModel.g:2753:6: lv_statement_aux_condexpr_1_0= ruleaux_condexpr
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getAux_condexprAccess().getStatement_aux_condexprAux_condexprParserRuleCall_0_1_0());
          					
        }
        pushFollow(FOLLOW_27);
        lv_statement_aux_condexpr_1_0=ruleaux_condexpr();

        state._fsp--;
        if (state.failed) return ;

        }


        }

        // InternalDomainModel.g:2770:4: ( (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis ) )
        // InternalDomainModel.g:2771:5: (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis )
        {
        // InternalDomainModel.g:2771:5: (lv_statement_optional_parentesis_2_0= ruleoptional_parentesis )
        // InternalDomainModel.g:2772:6: lv_statement_optional_parentesis_2_0= ruleoptional_parentesis
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getAux_condexprAccess().getStatement_optional_parentesisOptional_parentesisParserRuleCall_0_2_0());
          					
        }
        pushFollow(FOLLOW_2);
        lv_statement_optional_parentesis_2_0=ruleoptional_parentesis();

        state._fsp--;
        if (state.failed) return ;

        }


        }


        }


        }
    }
    // $ANTLR end synpred56_InternalDomainModel

    // $ANTLR start synpred57_InternalDomainModel
    public final void synpred57_InternalDomainModel_fragment() throws RecognitionException {   
        EObject lv_statement_arith_3_0 = null;

        EObject lv_statement_optional_parentesis_4_0 = null;


        // InternalDomainModel.g:2791:3: ( ( ( (lv_statement_arith_3_0= rulearith ) ) ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) ) ) )
        // InternalDomainModel.g:2791:3: ( ( (lv_statement_arith_3_0= rulearith ) ) ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) ) )
        {
        // InternalDomainModel.g:2791:3: ( ( (lv_statement_arith_3_0= rulearith ) ) ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) ) )
        // InternalDomainModel.g:2792:4: ( (lv_statement_arith_3_0= rulearith ) ) ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) )
        {
        // InternalDomainModel.g:2792:4: ( (lv_statement_arith_3_0= rulearith ) )
        // InternalDomainModel.g:2793:5: (lv_statement_arith_3_0= rulearith )
        {
        // InternalDomainModel.g:2793:5: (lv_statement_arith_3_0= rulearith )
        // InternalDomainModel.g:2794:6: lv_statement_arith_3_0= rulearith
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getAux_condexprAccess().getStatement_arithArithParserRuleCall_1_0_0());
          					
        }
        pushFollow(FOLLOW_27);
        lv_statement_arith_3_0=rulearith();

        state._fsp--;
        if (state.failed) return ;

        }


        }

        // InternalDomainModel.g:2811:4: ( (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis ) )
        // InternalDomainModel.g:2812:5: (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis )
        {
        // InternalDomainModel.g:2812:5: (lv_statement_optional_parentesis_4_0= ruleoptional_parentesis )
        // InternalDomainModel.g:2813:6: lv_statement_optional_parentesis_4_0= ruleoptional_parentesis
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getAux_condexprAccess().getStatement_optional_parentesisOptional_parentesisParserRuleCall_1_1_0());
          					
        }
        pushFollow(FOLLOW_2);
        lv_statement_optional_parentesis_4_0=ruleoptional_parentesis();

        state._fsp--;
        if (state.failed) return ;

        }


        }


        }


        }
    }
    // $ANTLR end synpred57_InternalDomainModel

    // $ANTLR start synpred58_InternalDomainModel
    public final void synpred58_InternalDomainModel_fragment() throws RecognitionException {   
        AntlrDatatypeRuleToken lv_close_0_0 = null;

        EObject lv_statement_optional_parentesis_1_1_0 = null;


        // InternalDomainModel.g:2970:3: ( ( ( (lv_close_0_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 ) ) ) )
        // InternalDomainModel.g:2970:3: ( ( (lv_close_0_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 ) ) )
        {
        // InternalDomainModel.g:2970:3: ( ( (lv_close_0_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 ) ) )
        // InternalDomainModel.g:2971:4: ( (lv_close_0_0= ruleclose_1 ) ) ( (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 ) )
        {
        // InternalDomainModel.g:2971:4: ( (lv_close_0_0= ruleclose_1 ) )
        // InternalDomainModel.g:2972:5: (lv_close_0_0= ruleclose_1 )
        {
        // InternalDomainModel.g:2972:5: (lv_close_0_0= ruleclose_1 )
        // InternalDomainModel.g:2973:6: lv_close_0_0= ruleclose_1
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getOptional_parentesisAccess().getCloseClose_1ParserRuleCall_0_0_0());
          					
        }
        pushFollow(FOLLOW_28);
        lv_close_0_0=ruleclose_1();

        state._fsp--;
        if (state.failed) return ;

        }


        }

        // InternalDomainModel.g:2990:4: ( (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 ) )
        // InternalDomainModel.g:2991:5: (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 )
        {
        // InternalDomainModel.g:2991:5: (lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1 )
        // InternalDomainModel.g:2992:6: lv_statement_optional_parentesis_1_1_0= ruleoptional_parentesis_1
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getOptional_parentesisAccess().getStatement_optional_parentesis_1Optional_parentesis_1ParserRuleCall_0_1_0());
          					
        }
        pushFollow(FOLLOW_2);
        lv_statement_optional_parentesis_1_1_0=ruleoptional_parentesis_1();

        state._fsp--;
        if (state.failed) return ;

        }


        }


        }


        }
    }
    // $ANTLR end synpred58_InternalDomainModel

    // $ANTLR start synpred60_InternalDomainModel
    public final void synpred60_InternalDomainModel_fragment() throws RecognitionException {   
        EObject lv_statement_conditional_1_0 = null;


        // InternalDomainModel.g:3110:5: ( (lv_statement_conditional_1_0= ruleconditional ) )
        // InternalDomainModel.g:3110:5: (lv_statement_conditional_1_0= ruleconditional )
        {
        // InternalDomainModel.g:3110:5: (lv_statement_conditional_1_0= ruleconditional )
        // InternalDomainModel.g:3111:6: lv_statement_conditional_1_0= ruleconditional
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getOptional_parentesis_notAccess().getStatement_conditionalConditionalParserRuleCall_0_1_0());
          					
        }
        pushFollow(FOLLOW_2);
        lv_statement_conditional_1_0=ruleconditional();

        state._fsp--;
        if (state.failed) return ;

        }


        }
    }
    // $ANTLR end synpred60_InternalDomainModel

    // $ANTLR start synpred61_InternalDomainModel
    public final void synpred61_InternalDomainModel_fragment() throws RecognitionException {   
        AntlrDatatypeRuleToken lv_close_0_0 = null;

        EObject lv_statement_conditional_1_0 = null;


        // InternalDomainModel.g:3089:3: ( ( ( (lv_close_0_0= ruleclose_1 ) ) ( (lv_statement_conditional_1_0= ruleconditional ) )? ) )
        // InternalDomainModel.g:3089:3: ( ( (lv_close_0_0= ruleclose_1 ) ) ( (lv_statement_conditional_1_0= ruleconditional ) )? )
        {
        // InternalDomainModel.g:3089:3: ( ( (lv_close_0_0= ruleclose_1 ) ) ( (lv_statement_conditional_1_0= ruleconditional ) )? )
        // InternalDomainModel.g:3090:4: ( (lv_close_0_0= ruleclose_1 ) ) ( (lv_statement_conditional_1_0= ruleconditional ) )?
        {
        // InternalDomainModel.g:3090:4: ( (lv_close_0_0= ruleclose_1 ) )
        // InternalDomainModel.g:3091:5: (lv_close_0_0= ruleclose_1 )
        {
        // InternalDomainModel.g:3091:5: (lv_close_0_0= ruleclose_1 )
        // InternalDomainModel.g:3092:6: lv_close_0_0= ruleclose_1
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getOptional_parentesis_notAccess().getCloseClose_1ParserRuleCall_0_0_0());
          					
        }
        pushFollow(FOLLOW_25);
        lv_close_0_0=ruleclose_1();

        state._fsp--;
        if (state.failed) return ;

        }


        }

        // InternalDomainModel.g:3109:4: ( (lv_statement_conditional_1_0= ruleconditional ) )?
        int alt76=2;
        int LA76_0 = input.LA(1);

        if ( ((LA76_0>=33 && LA76_0<=38)||(LA76_0>=40 && LA76_0<=41)) ) {
            alt76=1;
        }
        switch (alt76) {
            case 1 :
                // InternalDomainModel.g:3110:5: (lv_statement_conditional_1_0= ruleconditional )
                {
                // InternalDomainModel.g:3110:5: (lv_statement_conditional_1_0= ruleconditional )
                // InternalDomainModel.g:3111:6: lv_statement_conditional_1_0= ruleconditional
                {
                if ( state.backtracking==0 ) {

                  						newCompositeNode(grammarAccess.getOptional_parentesis_notAccess().getStatement_conditionalConditionalParserRuleCall_0_1_0());
                  					
                }
                pushFollow(FOLLOW_2);
                lv_statement_conditional_1_0=ruleconditional();

                state._fsp--;
                if (state.failed) return ;

                }


                }
                break;

        }


        }


        }
    }
    // $ANTLR end synpred61_InternalDomainModel

    // $ANTLR start synpred63_InternalDomainModel
    public final void synpred63_InternalDomainModel_fragment() throws RecognitionException {   
        EObject lv_statement_prueba_conditional_4_0 = null;


        // InternalDomainModel.g:3170:5: ( (lv_statement_prueba_conditional_4_0= ruleprueba_conditional ) )
        // InternalDomainModel.g:3170:5: (lv_statement_prueba_conditional_4_0= ruleprueba_conditional )
        {
        // InternalDomainModel.g:3170:5: (lv_statement_prueba_conditional_4_0= ruleprueba_conditional )
        // InternalDomainModel.g:3171:6: lv_statement_prueba_conditional_4_0= ruleprueba_conditional
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getOptional_parentesis_notAccess().getStatement_prueba_conditionalPrueba_conditionalParserRuleCall_1_2_0());
          					
        }
        pushFollow(FOLLOW_2);
        lv_statement_prueba_conditional_4_0=ruleprueba_conditional();

        state._fsp--;
        if (state.failed) return ;

        }


        }
    }
    // $ANTLR end synpred63_InternalDomainModel

    // $ANTLR start synpred65_InternalDomainModel
    public final void synpred65_InternalDomainModel_fragment() throws RecognitionException {   
        EObject lv_statement_conditional_2_0 = null;


        // InternalDomainModel.g:3250:4: ( (lv_statement_conditional_2_0= ruleconditional ) )
        // InternalDomainModel.g:3250:4: (lv_statement_conditional_2_0= ruleconditional )
        {
        // InternalDomainModel.g:3250:4: (lv_statement_conditional_2_0= ruleconditional )
        // InternalDomainModel.g:3251:5: lv_statement_conditional_2_0= ruleconditional
        {
        if ( state.backtracking==0 ) {

          					newCompositeNode(grammarAccess.getOptional_parentesis_1Access().getStatement_conditionalConditionalParserRuleCall_1_0());
          				
        }
        pushFollow(FOLLOW_2);
        lv_statement_conditional_2_0=ruleconditional();

        state._fsp--;
        if (state.failed) return ;

        }


        }
    }
    // $ANTLR end synpred65_InternalDomainModel

    // Delegated rules

    public final boolean synpred60_InternalDomainModel() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred60_InternalDomainModel_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred52_InternalDomainModel() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred52_InternalDomainModel_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred53_InternalDomainModel() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred53_InternalDomainModel_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred55_InternalDomainModel() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred55_InternalDomainModel_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred58_InternalDomainModel() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred58_InternalDomainModel_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred63_InternalDomainModel() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred63_InternalDomainModel_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred61_InternalDomainModel() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred61_InternalDomainModel_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred50_InternalDomainModel() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred50_InternalDomainModel_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred54_InternalDomainModel() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred54_InternalDomainModel_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred56_InternalDomainModel() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred56_InternalDomainModel_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred57_InternalDomainModel() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred57_InternalDomainModel_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred65_InternalDomainModel() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred65_InternalDomainModel_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }


    protected DFA34 dfa34 = new DFA34(this);
    protected DFA36 dfa36 = new DFA36(this);
    protected DFA41 dfa41 = new DFA41(this);
    protected DFA43 dfa43 = new DFA43(this);
    protected DFA45 dfa45 = new DFA45(this);
    static final String dfa_1s = "\14\uffff";
    static final String dfa_2s = "\1\11\13\uffff";
    static final String dfa_3s = "\1\16\10\0\3\uffff";
    static final String dfa_4s = "\1\51\10\0\3\uffff";
    static final String dfa_5s = "\11\uffff\1\2\1\uffff\1\1";
    static final String dfa_6s = "\1\uffff\1\0\1\1\1\2\1\3\1\4\1\5\1\6\1\7\3\uffff}>";
    static final String[] dfa_7s = {
            "\1\11\22\uffff\1\1\1\2\1\3\1\4\1\5\1\6\1\uffff\1\7\1\10",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            ""
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final short[] dfa_2 = DFA.unpackEncodedString(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final char[] dfa_4 = DFA.unpackEncodedStringToUnsignedChars(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[] dfa_6 = DFA.unpackEncodedString(dfa_6s);
    static final short[][] dfa_7 = unpackEncodedStringArray(dfa_7s);

    class DFA34 extends DFA {

        public DFA34(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 34;
            this.eot = dfa_1;
            this.eof = dfa_2;
            this.min = dfa_3;
            this.max = dfa_4;
            this.accept = dfa_5;
            this.special = dfa_6;
            this.transition = dfa_7;
        }
        public String getDescription() {
            return "2431:4: ( (lv_statement_conditional_4_0= ruleconditional ) )?";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA34_1 = input.LA(1);

                         
                        int index34_1 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred50_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index34_1);
                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA34_2 = input.LA(1);

                         
                        int index34_2 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred50_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index34_2);
                        if ( s>=0 ) return s;
                        break;
                    case 2 : 
                        int LA34_3 = input.LA(1);

                         
                        int index34_3 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred50_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index34_3);
                        if ( s>=0 ) return s;
                        break;
                    case 3 : 
                        int LA34_4 = input.LA(1);

                         
                        int index34_4 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred50_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index34_4);
                        if ( s>=0 ) return s;
                        break;
                    case 4 : 
                        int LA34_5 = input.LA(1);

                         
                        int index34_5 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred50_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index34_5);
                        if ( s>=0 ) return s;
                        break;
                    case 5 : 
                        int LA34_6 = input.LA(1);

                         
                        int index34_6 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred50_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index34_6);
                        if ( s>=0 ) return s;
                        break;
                    case 6 : 
                        int LA34_7 = input.LA(1);

                         
                        int index34_7 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred50_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index34_7);
                        if ( s>=0 ) return s;
                        break;
                    case 7 : 
                        int LA34_8 = input.LA(1);

                         
                        int index34_8 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred50_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index34_8);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 34, _s, input);
            error(nvae);
            throw nvae;
        }
    }

    class DFA36 extends DFA {

        public DFA36(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 36;
            this.eot = dfa_1;
            this.eof = dfa_2;
            this.min = dfa_3;
            this.max = dfa_4;
            this.accept = dfa_5;
            this.special = dfa_6;
            this.transition = dfa_7;
        }
        public String getDescription() {
            return "2613:4: ( (lv_statement_conditional_3_0= ruleconditional ) )?";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA36_1 = input.LA(1);

                         
                        int index36_1 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred54_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index36_1);
                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA36_2 = input.LA(1);

                         
                        int index36_2 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred54_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index36_2);
                        if ( s>=0 ) return s;
                        break;
                    case 2 : 
                        int LA36_3 = input.LA(1);

                         
                        int index36_3 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred54_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index36_3);
                        if ( s>=0 ) return s;
                        break;
                    case 3 : 
                        int LA36_4 = input.LA(1);

                         
                        int index36_4 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred54_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index36_4);
                        if ( s>=0 ) return s;
                        break;
                    case 4 : 
                        int LA36_5 = input.LA(1);

                         
                        int index36_5 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred54_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index36_5);
                        if ( s>=0 ) return s;
                        break;
                    case 5 : 
                        int LA36_6 = input.LA(1);

                         
                        int index36_6 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred54_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index36_6);
                        if ( s>=0 ) return s;
                        break;
                    case 6 : 
                        int LA36_7 = input.LA(1);

                         
                        int index36_7 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred54_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index36_7);
                        if ( s>=0 ) return s;
                        break;
                    case 7 : 
                        int LA36_8 = input.LA(1);

                         
                        int index36_8 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred54_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index36_8);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 36, _s, input);
            error(nvae);
            throw nvae;
        }
    }

    class DFA41 extends DFA {

        public DFA41(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 41;
            this.eot = dfa_1;
            this.eof = dfa_2;
            this.min = dfa_3;
            this.max = dfa_4;
            this.accept = dfa_5;
            this.special = dfa_6;
            this.transition = dfa_7;
        }
        public String getDescription() {
            return "3109:4: ( (lv_statement_conditional_1_0= ruleconditional ) )?";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA41_1 = input.LA(1);

                         
                        int index41_1 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred60_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index41_1);
                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA41_2 = input.LA(1);

                         
                        int index41_2 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred60_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index41_2);
                        if ( s>=0 ) return s;
                        break;
                    case 2 : 
                        int LA41_3 = input.LA(1);

                         
                        int index41_3 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred60_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index41_3);
                        if ( s>=0 ) return s;
                        break;
                    case 3 : 
                        int LA41_4 = input.LA(1);

                         
                        int index41_4 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred60_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index41_4);
                        if ( s>=0 ) return s;
                        break;
                    case 4 : 
                        int LA41_5 = input.LA(1);

                         
                        int index41_5 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred60_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index41_5);
                        if ( s>=0 ) return s;
                        break;
                    case 5 : 
                        int LA41_6 = input.LA(1);

                         
                        int index41_6 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred60_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index41_6);
                        if ( s>=0 ) return s;
                        break;
                    case 6 : 
                        int LA41_7 = input.LA(1);

                         
                        int index41_7 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred60_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index41_7);
                        if ( s>=0 ) return s;
                        break;
                    case 7 : 
                        int LA41_8 = input.LA(1);

                         
                        int index41_8 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred60_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index41_8);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 41, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String dfa_8s = "\1\3\13\uffff";
    static final String dfa_9s = "\1\16\2\0\11\uffff";
    static final String dfa_10s = "\1\51\2\0\11\uffff";
    static final String dfa_11s = "\3\uffff\1\2\7\uffff\1\1";
    static final String dfa_12s = "\1\uffff\1\0\1\1\11\uffff}>";
    static final String[] dfa_13s = {
            "\1\3\22\uffff\6\3\1\uffff\1\1\1\2",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };
    static final short[] dfa_8 = DFA.unpackEncodedString(dfa_8s);
    static final char[] dfa_9 = DFA.unpackEncodedStringToUnsignedChars(dfa_9s);
    static final char[] dfa_10 = DFA.unpackEncodedStringToUnsignedChars(dfa_10s);
    static final short[] dfa_11 = DFA.unpackEncodedString(dfa_11s);
    static final short[] dfa_12 = DFA.unpackEncodedString(dfa_12s);
    static final short[][] dfa_13 = unpackEncodedStringArray(dfa_13s);

    class DFA43 extends DFA {

        public DFA43(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 43;
            this.eot = dfa_1;
            this.eof = dfa_8;
            this.min = dfa_9;
            this.max = dfa_10;
            this.accept = dfa_11;
            this.special = dfa_12;
            this.transition = dfa_13;
        }
        public String getDescription() {
            return "3169:4: ( (lv_statement_prueba_conditional_4_0= ruleprueba_conditional ) )?";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA43_1 = input.LA(1);

                         
                        int index43_1 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred63_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 3;}

                         
                        input.seek(index43_1);
                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA43_2 = input.LA(1);

                         
                        int index43_2 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred63_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 3;}

                         
                        input.seek(index43_2);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 43, _s, input);
            error(nvae);
            throw nvae;
        }
    }

    class DFA45 extends DFA {

        public DFA45(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 45;
            this.eot = dfa_1;
            this.eof = dfa_2;
            this.min = dfa_3;
            this.max = dfa_4;
            this.accept = dfa_5;
            this.special = dfa_6;
            this.transition = dfa_7;
        }
        public String getDescription() {
            return "3249:3: ( (lv_statement_conditional_2_0= ruleconditional ) )?";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA45_1 = input.LA(1);

                         
                        int index45_1 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred65_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index45_1);
                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA45_2 = input.LA(1);

                         
                        int index45_2 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred65_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index45_2);
                        if ( s>=0 ) return s;
                        break;
                    case 2 : 
                        int LA45_3 = input.LA(1);

                         
                        int index45_3 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred65_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index45_3);
                        if ( s>=0 ) return s;
                        break;
                    case 3 : 
                        int LA45_4 = input.LA(1);

                         
                        int index45_4 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred65_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index45_4);
                        if ( s>=0 ) return s;
                        break;
                    case 4 : 
                        int LA45_5 = input.LA(1);

                         
                        int index45_5 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred65_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index45_5);
                        if ( s>=0 ) return s;
                        break;
                    case 5 : 
                        int LA45_6 = input.LA(1);

                         
                        int index45_6 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred65_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index45_6);
                        if ( s>=0 ) return s;
                        break;
                    case 6 : 
                        int LA45_7 = input.LA(1);

                         
                        int index45_7 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred65_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index45_7);
                        if ( s>=0 ) return s;
                        break;
                    case 7 : 
                        int LA45_8 = input.LA(1);

                         
                        int index45_8 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred65_InternalDomainModel()) ) {s = 11;}

                        else if ( (true) ) {s = 9;}

                         
                        input.seek(index45_8);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 45, _s, input);
            error(nvae);
            throw nvae;
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x00000000001F9002L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x000000003C800000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000001004000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x000000001E004000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000180000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000080000002L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x00003080000020D0L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000037E00000002L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000037E00000000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000037E00004000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0001F37E00000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0001F00000000002L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x00003000000020D0L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0001F00000000000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000040040000002L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000000100000000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000080000000000L});

}